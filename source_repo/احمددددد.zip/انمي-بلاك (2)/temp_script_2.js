
  import { initializeApp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js";
  import { initializeFirestore, getFirestore, doc, setDoc, updateDoc, addDoc, serverTimestamp, getDoc, getDocFromServer, collection, query, where, getDocs, onSnapshot, deleteDoc, enableIndexedDbPersistence, setLogLevel } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";
  import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile, sendPasswordResetEmail, RecaptchaVerifier, signInWithPhoneNumber, deleteUser, sendEmailVerification } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-auth.js";
  import { getStorage, ref, uploadBytes, uploadBytesResumable, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-storage.js";

  try { setLogLevel('silent'); } catch (_) {}
  window.getStorage = getStorage;
  window.ref = ref;
  window.uploadBytes = uploadBytes;
  window.uploadBytesResumable = uploadBytesResumable;
  window.getDownloadURL = getDownloadURL;
  window.deleteObject = deleteObject;
  
    function sanitizeFirestoreData(data) {
    if (data === undefined) return null;
    if (data === null || typeof data !== "object") return data;
    if (data instanceof Date || (data.constructor && data.constructor.name === "FieldValue") || data._methodName || (typeof data.toMillis === "function")) {
      return data;
    }
    if (Array.isArray(data)) {
      return data.filter(x => x !== undefined).map(x => sanitizeFirestoreData(x));
    }
    const clean = {};
    for (const [k, v] of Object.entries(data)) {
      if (v !== undefined) {
        clean[k] = sanitizeFirestoreData(v);
      }
    }
    return clean;
  }
  window.sanitizeFirestoreData = sanitizeFirestoreData;

  window.initializeFirestore = initializeFirestore;
  window.getFirestore = getFirestore;
  window.doc = doc;
  window.setDoc = function(docRef, data, options) {
    const clean = sanitizeFirestoreData(data);
    return options !== undefined ? setDoc(docRef, clean, options) : setDoc(docRef, clean);
  };
  window.updateDoc = function(docRef, ...args) {
    if (args.length === 1 && typeof args[0] === "object") {
      return updateDoc(docRef, sanitizeFirestoreData(args[0]));
    }
    return updateDoc(docRef, ...args);
  };
  window.addDoc = function(collRef, data) {
    return addDoc(collRef, sanitizeFirestoreData(data));
  };
  window.serverTimestamp = serverTimestamp;
  window.getDoc = getDoc;
  window.collection = collection;
  window.query = query;
  window.where = where;
  window.getDocs = getDocs;
  window.onSnapshot = onSnapshot;
  window.deleteDoc = deleteDoc;
  window.GoogleAuthProvider = GoogleAuthProvider;
  window.signInWithPopup = signInWithPopup;
  window.signInWithEmailAndPassword = signInWithEmailAndPassword;
  window.createUserWithEmailAndPassword = createUserWithEmailAndPassword;
  window.updateProfile = updateProfile;
  window.signOut = signOut;
  window.onAuthStateChanged = onAuthStateChanged;
  window.sendPasswordResetEmail = sendPasswordResetEmail;
  window.RecaptchaVerifier = RecaptchaVerifier;
  window.signInWithPhoneNumber = signInWithPhoneNumber;
  window.deleteUser = deleteUser;
  window.sendEmailVerification = sendEmailVerification;


  const firebaseConfig = {
    projectId: "booming-rigging-gn50x",
    appId: "1:914243738562:web:a37e6e84561648b9e4945b",
    apiKey: "AIzaSyA-ogGsp39UsQ72M_PwDx4n89ETlROqqGc",
    authDomain: "booming-rigging-gn50x.firebaseapp.com",
    storageBucket: "booming-rigging-gn50x.firebasestorage.app",
    messagingSenderId: "914243738562"
  };

  const app = initializeApp(firebaseConfig);
  const dbId = "ai-studio-51245802-6d4e-4feb-bd11-43162af66618";
  try {
    window.db = initializeFirestore(app, {
      ignoreUndefinedProperties: true
    }, dbId);
  } catch (_) {
    try {
      window.db = initializeFirestore(app, {
        ignoreUndefinedProperties: true
      });
    } catch (e2) {
      window.db = getFirestore(app, dbId);
    }
  }
  try { enableIndexedDbPersistence(window.db).catch(() => {}); } catch (_) {}
  window.auth = getAuth(app);
  try { window.storage = getStorage(app); } catch (e) { console.warn('Storage init fallback:', e); }
  
  // Standardized Firestore error handler adhering to skill specification
  function handleFirestoreError(error, operationType, path) {
    const errMessage = error instanceof Error ? error.message : String(error || '');
    const errInfo = {
      error: errMessage,
      authInfo: {
        userId: window.auth?.currentUser?.uid || null,
        email: window.auth?.currentUser?.email || null,
        emailVerified: window.auth?.currentUser?.emailVerified || null,
        isAnonymous: window.auth?.currentUser?.isAnonymous || null,
        tenantId: window.auth?.currentUser?.tenantId || null,
        providerInfo: window.auth?.currentUser?.providerData?.map(p => ({
          providerId: p.providerId,
          email: p.email
        })) || []
      },
      operationType: operationType,
      path: path
    };
    console.error('Firestore Error: ', JSON.stringify(errInfo));
    if (errMessage.includes('Missing or insufficient permissions') || errMessage.includes('permission-denied')) {
      throw new Error(JSON.stringify(errInfo));
    }
  }
  window.handleFirestoreError = handleFirestoreError;

  // Gentle connection health check using cached getDoc to avoid forced 10s server blocking
  async function testConnection() {
    try {
      await getDoc(doc(window.db, 'test', 'connection')).catch(() => {});
      console.log("🔥 Firestore initialized and ready");
    } catch (error) {
      console.warn("Firestore: Operating in fast local/cache mode with background auto-sync.");
    }
  }
  testConnection();

  console.log("🔥 Firebase initialized and connected successfully");

  
  // Real-time Cloud Sync for Posts (Accessible to everyone!)
  window._cloudPosts = [];
  const postsQuery = window.query(window.collection(window.db, 'posts'));
  window.onSnapshot(postsQuery, (snap) => {
    const livePosts = snap.docs.map(d => {
      const data = d.data();
      if(!data || !data.id) return null;
      const isLiked = data.likedUsers && Array.isArray(data.likedUsers) && data.likedUsers.some(u => isMe(u.id || u.uid || u));
      const existing = (S.posts || []).find(x => x.id === data.id);
      return Object.assign({}, existing || {}, data, {
        pending: d.metadata.hasPendingWrites,
        liked: (isLiked !== undefined) ? isLiked : (existing ? !!existing.liked : false)
      });
    }).filter(Boolean);

    
    const postMap = {};
    (S.posts || []).forEach(p => { 
      if (p && p.id && (p.pending || p.uploading || p.failed)) {
        postMap[p.id] = p; 
      }
    });
    livePosts.forEach(p => { postMap[p.id] = Object.assign(postMap[p.id] || {}, p); });
    const merged = Object.values(postMap);
    merged.sort((a, b) => (b.createdAt || b.at || 0) - (a.createdAt || a.at || 0));
    S.posts = merged;
    window._cloudPosts = livePosts;
    saveLocalOnly();


      // Surgical DOM updates for like count and states without page flickering
      snap.docChanges().forEach(change => {
        const d = change.doc.data();
        if(!d || !d.id) return;
        const pid = d.id;
        const cntBtn = document.getElementById("likes_cnt_" + pid);
        if (cntBtn && d.likes !== undefined) {
          cntBtn.textContent = nfmt(d.likes) + " إعجاب";
        }
        const likeBtn = document.getElementById("like_" + pid);
        if (likeBtn && d.likedUsers) {
          const isLiked = d.likedUsers.some(u => isMe(u.id || u.uid || u));
          if (isLiked) {
            likeBtn.classList.add("on", "liked");
            likeBtn.style.color = "var(--rose)";
            likeBtn.innerHTML = `${IF("heart","i s")} <span>${T("أعجبني")}</span>`;
          } else {
            likeBtn.classList.remove("on", "liked");
            likeBtn.style.color = "";
            likeBtn.innerHTML = `${I("heart","i s")} <span>${T("إعجاب")}</span>`;
          }
        }
      });

      // If remote new post was added and we are idling at the top of feed, update cleanly
      const hasRemoteAdds = snap.docChanges().some(c => c.type === "added" && !c.doc.metadata.hasPendingWrites);
      const hasRemoteMods = snap.docChanges().some(c => (c.type === "modified" || c.type === "removed") && !c.doc.metadata.hasPendingWrites);
      if (hasRemoteAdds || hasRemoteMods) {
        const pageEl = document.getElementById("page");
        if (pageEl && pageEl.scrollTop < 60 && S.page === "home") {
          debounceRender({ keepScroll: true });
        } else if (hasRemoteMods && ['postDetail', 'profile'].includes(S.page)) {
          debounceRender({ keepScroll: true });
        } else if (hasRemoteAdds) {
          S.hasNewPosts = true;
          const homeNavBtn = document.querySelector("#nav button");
          if (homeNavBtn && !homeNavBtn.querySelector(".ping")) {
            const sp = document.createElement("span");
            sp.className = "ping";
            homeNavBtn.insertBefore(sp, homeNavBtn.firstChild);
          }
        }
      }
    }
  }, (e) => console.error("Firestore posts sync:", e));

  // Real-time Cloud Sync for Stories (Live Firestore + Archive + Deletion)
  const storiesQuery = window.query(window.collection(window.db, 'stories'));
  window.onSnapshot(storiesQuery, (snap) => {
    const liveStories = snap.docs.map(d => Object.assign(d.data(), { pending: d.metadata.hasPendingWrites })).filter(s => s && s.id);
    const cutoff = Date.now() - 86400000;
    S.storyArchive = S.storyArchive || [];

    const storyMap = {};
    liveStories.forEach(s => {
      const latestTime = Math.max(...(s.items || []).map(it => it.createdAt || 0), s.createdAt || 0);
      if (latestTime && latestTime < cutoff) {
        if (!S.storyArchive.some(a => a.id === s.id)) {
          S.storyArchive.unshift(Object.assign({}, s, { archivedAt: Date.now() }));
        }
      } else {
        storyMap[s.id] = s;
      }
    });

    // Preserve any local optimistic pending stories
    (S.stories || []).forEach(s => {
      if (s && s.id && s.pending && !storyMap[s.id]) {
        storyMap[s.id] = s;
      }
    });

    const merged = Object.values(storyMap);
    merged.sort((a, b) => (b.createdAt || b.at || 0) - (a.createdAt || a.at || 0));
    S.stories = merged;
    saveLocalOnly();
    if (!document.activeElement || (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA')) {
      if (['home', 'myStories', 'storyArchive'].includes(S.page)) render();
    }
  }, (e) => console.error("Firestore stories sync:", e));

  // Real-time Cloud Sync for Reels
  const reelsQuery = window.query(window.collection(window.db, 'reels'));
  window.onSnapshot(reelsQuery, (snap) => {
    const liveReels = snap.docs.map(d => d.data()).filter(r => r && r.id);
    if (liveReels.length > 0) {
      const reelMap = {};
      (S.reels || []).forEach(r => { if (r && r.id) reelMap[r.id] = r; });
      liveReels.forEach(r => { reelMap[r.id] = Object.assign(reelMap[r.id] || {}, r); });
      const merged = Object.values(reelMap);
      merged.sort((a, b) => (b.createdAt || b.at || 0) - (a.createdAt || a.at || 0));
      S.reels = merged;
      saveLocalOnly();
      if (!document.activeElement || (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA')) {
        if (S.page === 'reels' || S.page === 'home') render();
      }
    }
  }, (e) => console.error("Firestore reels sync:", e));

  // Real-time Cloud Sync for Direct & Group Chats
  const chatsQuery = window.query(window.collection(window.db, 'chats'));
  window.onSnapshot(chatsQuery, (snap) => {
    const myUid = getMyUid();
    let changed = false;
    snap.docChanges().forEach(change => {
      const cd = change.doc.data();
      if(!cd || !cd.id) return;
      const isParticipant = !cd.participants || (cd.participants||[]).length === 0 || cd.participants.includes(myUid) || cd.participants.includes(S.me.id) || cd.participants.includes("me") || cd.id.includes(myUid);
      if(!isParticipant) return;
      
      if (change.type === "removed") {
        S.chats = (S.chats || []).filter(c => c.id !== cd.id);
        changed = true;
        return;
      }
      let localChat = (S.chats||[]).find(c => c.id === cd.id);
      if(!localChat){
        let otherUid = (cd.participants || []).find(p => p !== myUid) || cd.userId || "user_friend";
        localChat = {
          id: cd.id,
          userId: otherUid,
          type: cd.type || "private",
          unread: (cd.lastSenderId && cd.lastSenderId !== myUid) ? 1 : 0,
          last: cd.last || "محادثة جديدة",
          lastAt: cd.lastAt || cd.updatedAt || now(),
          pinned: false,
          muted: false,
          messages: []
        };
        S.chats.unshift(localChat);
        changed = true;
      } else {
        if(cd.typing) {
          const isOtherTyping = Object.keys(cd.typing).some(k => {
            if (!k || k === myUid || (S.me && (k === S.me.id || k === S.me.uid))) return false;
            const ts = Number(cd.typing[k]);
            return ts > 0 && (now() - ts < 6000);
          });
          if (isOtherTyping) {
            S.typingIn = S.typingIn || {};
            if (!S.typingIn[localChat.id]) {
              S.typingIn[localChat.id] = true;
              changed = true;
            }
          } else if (S.typingIn && S.typingIn[localChat.id]) {
            S.typingIn[localChat.id] = false;
            changed = true;
          }
        }
        
        if(cd.wallpaper !== undefined) {
           if(JSON.stringify(localChat.wallpaper) !== JSON.stringify(cd.wallpaper)) {
              localChat.wallpaper = cd.wallpaper;
              changed = true;
           }
        }
        if(cd.wallpaperImg !== undefined && localChat.wallpaperImg !== cd.wallpaperImg) {
           localChat.wallpaperImg = cd.wallpaperImg;
           changed = true;
        }
if(localChat.last !== cd.last || localChat.lastAt !== cd.lastAt){
          localChat.last = cd.last || localChat.last;
          localChat.lastAt = cd.lastAt || localChat.lastAt;
          if(cd.lastSenderId && cd.lastSenderId !== myUid && S.activeChat !== localChat.id){
            if(change.type === "modified"){
              localChat.unread = (localChat.unread || 0) + 1;
              snd("notif");
              toast("رسالة جديدة من " + (u(localChat.userId).name || "صديق") + ": " + localChat.last, "info");
            }
          }
          changed = true;
        }
      }
    });
    if(changed){
      saveLocalOnly();
      if(S.page === 'chatRoom' && S.params.id) {
         const msgBox = document.getElementById("msgs");
         if(msgBox){
           const c = (S.chats||[]).find(x=>x.id===S.params.id);
           if(c) {
             const uu = u(c.userId);
             const typingEl = document.getElementById("chat_typing_indicator");
             const isTyping = S.typingIn && S.typingIn[c.id];
             if (typingEl) {
               typingEl.style.display = isTyping ? "flex" : "none";
             }
             const hdrSt = document.getElementById("chat_hdr_st");
             if (hdrSt) {
                hdrSt.textContent = isTyping ? "يكتب الآن…" : uu.online ? "متصل الآن" : "آخر ظهور " + ago(uu.lastSeen||uu.joined);
                hdrSt.style.color = isTyping ? "var(--accent)" : uu.online ? "var(--emerald)" : "var(--faint)";
                hdrSt.className = isTyping ? "tiny" : "tiny fnt";
             }
             const msgBox = document.getElementById("msgs");
             if (msgBox) {
                // Call updateChatDom safely without forced scrolling
                window.updateChatDom(msgBox, c, uu, false);
             }
           }
         }
      }
      if(!document.activeElement || (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA')) {
        if(S.page === 'chat') debounceRender({keepScroll:true});
      }
    }
  }, (e) => console.error("Firestore chats sync:", e));

  // Real-time Cloud Sync for Communities & Guilds
  const communitiesQuery = window.query(window.collection(window.db, 'communities'));
  window.onSnapshot(communitiesQuery, (snap) => {
    const liveComms = snap.docs.map(d => d.data()).filter(c => c && c.id);
    const commMap = {};
      (S.communities || []).forEach(c => { if(c && c.id && c.pending) commMap[c.id] = c; });
      liveComms.forEach(c => { commMap[c.id] = Object.assign(commMap[c.id] || {}, c); });
      const merged = Object.values(commMap);
      merged.sort((a,b)=>(b.createdAt||b.at||0)-(a.createdAt||a.at||0));
      S.communities = merged;
      saveLocalOnly();
      if(['communities','explore','home'].includes(S.page)) debounceRender();
    }
  }, (e) => console.error("Firestore communities sync:", e));

  // Real-time Cloud Sync for Groups
  try {
    const groupsQuery = window.query(window.collection(window.db, 'groups'));
    window.onSnapshot(groupsQuery, (snap) => {
      const liveGroups = snap.docs.map(d => d.data()).filter(g => g && g.id);
      const grpMap = {};
        (S.groups || []).forEach(g => { if(g && g.id && g.pending) grpMap[g.id] = g; });
        liveGroups.forEach(g => { grpMap[g.id] = Object.assign(grpMap[g.id] || {}, g); });
        const merged = Object.values(grpMap);
        merged.sort((a,b)=>(b.createdAt||b.at||0)-(a.createdAt||a.at||0));
        S.groups = merged;
        saveLocalOnly();
        if(['groups','explore','home'].includes(S.page)) debounceRender();
      }
    }, (e) => console.error("Firestore groups sync:", e));
  } catch(e) {
    console.warn("Groups sync error:", e);
  }

  // Real-time Cloud Sync for Worlds
  try {
    const worldsQuery = window.query(window.collection(window.db, 'worlds'));
    window.onSnapshot(worldsQuery, (snap) => {
      const liveWorlds = snap.docs.map(d => d.data()).filter(w => w && w.id);
      const wrldMap = {};
        (S.worlds || []).forEach(w => { if(w && w.id && w.pending) wrldMap[w.id] = w; });
        liveWorlds.forEach(w => { wrldMap[w.id] = Object.assign(wrldMap[w.id] || {}, w); });
        const merged = Object.values(wrldMap);
        merged.sort((a,b)=>(b.createdAt||b.at||0)-(a.createdAt||a.at||0));
        S.worlds = merged;
        saveLocalOnly();
        if(['worlds','explore','home'].includes(S.page)) debounceRender();
      }
    }, (e) => console.error("Firestore worlds sync:", e));
  } catch(e) {
    console.warn("Worlds sync error:", e);
  }

  // Real-time Cloud Sync for Users (All registered users!)
  const usersQuery = window.query(window.collection(window.db, 'users'));
  window.onSnapshot(usersQuery, (snap) => {
    snap.docs.forEach(d => {
      const ud = d.data();
      if(ud && ud.id){
        window._cloudUsers[ud.id] = ud;
      }
    });
    const userMap = {};
    (S.users || []).forEach(u => { if(u && u.id) userMap[u.id] = u; });
    Object.values(window._cloudUsers).forEach(cu => {
      if(cu && cu.id) userMap[cu.id] = Object.assign(userMap[cu.id] || {}, cu);
    });
    S.users = Object.values(userMap);
    if (window.auth && window.auth.currentUser && window._cloudUsers[window.auth.currentUser.uid]) {
      const freshMe = window._cloudUsers[window.auth.currentUser.uid];
      S.me = Object.assign(S.me || {}, freshMe);
      S.user = S.me;
      ensureAccounts();
    }
    saveLocalOnly();
    if(!document.activeElement || (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA')) {
      if(['profile', 'publicProfile', 'followers', 'communityDetail', 'chat', 'home', 'postDetail'].includes(S.page)) render();
    }
  }, (e) => console.error("Firestore users sync:", e));

  // Real-time Cloud Sync for Official Broadcasts
  const bcQuery = window.query(window.collection(window.db, 'broadcasts'));
  window.onSnapshot(bcQuery, (snap) => {
    const liveBc = snap.docs.map(d => d.data());
    liveBc.sort((a, b) => (b.at || 0) - (a.at || 0));
    S.broadcasts = liveBc;
    saveLocalOnly();
    if (S.page === 'admin') debounceRender();
  }, (e) => console.error("Firestore broadcasts sync:", e));

  // Real-time Cloud Sync for Custom Level Badges
  try {
    const levelBadgesQuery = window.query(window.collection(window.db, 'level_badges'));
    window.onSnapshot(levelBadgesQuery, (snap) => {
      const liveBadges = snap.docs.map(d => d.data()).filter(b => b && b.id);
      if (liveBadges.length > 0) {
        ensureLevelBadgesSystem();
        const badgeMap = {};
        (S.levelBadges || []).forEach(b => { if (b && b.id) badgeMap[b.id] = b; });
        liveBadges.forEach(b => { badgeMap[b.id] = Object.assign(badgeMap[b.id] || {}, b); });
        S.levelBadges = Object.values(badgeMap);
        saveLocalOnly();
        if (!document.activeElement || (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA')) {
          if (['profile', 'publicProfile', 'levels', 'admin'].includes(S.page)) {
            debounceRender();
          }
        }
      }
    }, (e) => console.error("Firestore level_badges sync:", e));

    // Real-time Cloud Sync for Level Mappings
    const levelMappingsDoc = window.doc(window.db, 'level_mappings', 'active');
    window.onSnapshot(levelMappingsDoc, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        if (data && data.mappings) {
          ensureLevelBadgesSystem();
          S.levelMappings = Object.assign({}, S.levelMappings || {}, data.mappings);
          saveLocalOnly();
          if (!document.activeElement || (document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA')) {
            if (['profile', 'publicProfile', 'levels', 'admin'].includes(S.page)) {
              debounceRender();
            }
          }
        }
      }
    }, (e) => console.error("Firestore level_mappings sync:", e));
  } catch(e) {
    console.warn("Level badges sync listeners init error:", e);
  }

  // Global auth state listener
  window._cloudUsers = window._cloudUsers || {};
  window.onAuthStateChanged(window.auth, (user) => {
    if (user) {
      if (!window._notifSub) {
        const notifQuery = window.query(window.collection(window.db, 'notifications'), window.where('userId', '==', user.uid));
        window._notifSub = window.onSnapshot(notifQuery, (snap) => {
          const liveNotifs = snap.docs.map(d => d.data());
          liveNotifs.sort((a,b) => (b.at||0) - (a.at||0));
          S.notifs = liveNotifs;
          saveLocalOnly();
          if (['notifications', 'home'].includes(S.page)) debounceRender({ keepScroll: true });
          
          // Show toast for newly added unread notification if it's recent
          snap.docChanges().forEach(change => {
            if (change.type === "added" && !change.doc.metadata.hasPendingWrites) {
               const nd = change.doc.data();
               if (!nd.read && (Date.now() - (nd.at || 0) < 60000)) {
                  toast("إشعار جديد: " + (nd.title || "تنبيه"), "info");
                  snd("notif");
               }
            }
          });
        }, e => console.warn("Notif sync:", e));
      }

      // 1. If currently in a different account session, switch cleanly without destroying anything
      const userKey = getUserStorageKey(user.uid);
      if (KEY !== userKey) {
        KEY = userKey;
        try {
          const raw = localStorage.getItem(KEY);
          if (raw) {
             const parsed = JSON.parse(raw);
             // Merge with current volatile state (like page, but overwrite data)
             Object.assign(S, parsed);
          } else {
             // Complete reset if no local state for this new user exists yet
             const tempPage = S.page;
             const tempSaved = S.savedAccounts;
             for (let prop in S) { delete S[prop]; }
             S.page = tempPage;
             S.savedAccounts = tempSaved;
          }
          localStorage.setItem("animeblack_last_active_uid", user.uid);
        } catch(e) {}
      }

      // 2. Fetch or Create user profile + User state
      const userRef = window.doc(window.db, "users", user.uid);
      window.getDoc(userRef).then(async (docSnap) => {
        let userData;
        let existingLocal = (S.savedAccounts || []).find(a => a.id === user.uid || a.uid === user.uid || (user.email && a.email && a.email.toLowerCase() === user.email.toLowerCase()));
        if (!existingLocal && S.me && (S.me.id === user.uid || S.me.uid === user.uid || (user.email && S.me.email === user.email))) {
          existingLocal = S.me;
        }

        if (docSnap.exists()) {
          userData = docSnap.data();
          userData.id = user.uid;
          userData.uid = user.uid;

          // Preserve customized username/name if local record has it and cloud doc has generic default
          if (existingLocal) {
            if (existingLocal.username && (!userData.username || userData.username.startsWith('user_') || userData.username === 'guest' || userData.username === 'otaku')) {
              userData.username = existingLocal.username;
            }
            if (existingLocal.name && (!userData.name || userData.name === 'أوتاكو جديد' || userData.name === 'زائر')) {
              userData.name = existingLocal.name;
            }
            if (existingLocal.avatar && (!userData.avatar || userData.avatar === AV[0])) {
              userData.avatar = existingLocal.avatar;
            }
          }

          // Fallback username from email if still missing
          if (!userData.username || userData.username === 'guest' || userData.username === 'otaku') {
            userData.username = (user.email ? user.email.split('@')[0] : 'user_' + user.uid.slice(0, 6)).replace(/[^a-zA-Z0-9_.]/g, '').toLowerCase() || ('otaku_' + user.uid.slice(0, 5));
          }

          if (userData.profileCompleted === undefined || userData.profileCompleted === null) {
            userData.profileCompleted = true;
          }
        } else {
          const defaultUsername = (user.email ? user.email.split('@')[0] : 'user_' + ((user&&user.uid)||"otaku").slice(0,6)).replace(/[^a-zA-Z0-9_.]/g, '').toLowerCase() || ('otaku_' + ((user&&user.uid)||"otaku").slice(0,5));
          const isReturningUser = !!(existingLocal || (user.displayName && user.email) || user.metadata?.creationTime !== user.metadata?.lastSignInTime);
          
          userData = {
            id: user.uid,
            uid: user.uid,
            name: (existingLocal && existingLocal.name) || user.displayName || 'أوتاكو أنمي بلاك',
            username: (existingLocal && existingLocal.username) || defaultUsername,
            email: user.email || '',
            avatar: (existingLocal && existingLocal.avatar) || user.photoURL || AV[0],
            bio: (existingLocal && existingLocal.bio) || 'عضو في مجتمع أنمي بلاك',
            role: user.email === 'm774545471@gmail.com' ? "admin" : ((existingLocal && existingLocal.role) || "Member"),
            level: (existingLocal && existingLocal.level) || 1,
            followers: (existingLocal && existingLocal.followers) || 0,
            following: (existingLocal && existingLocal.following) || 0,
            reputation: (existingLocal && existingLocal.reputation) || 15,
            coins: (existingLocal && existingLocal.coins) || 150,
            stars: (existingLocal && existingLocal.stars) || 10,
            joined: (existingLocal && existingLocal.joined) || Date.now(),
            badges: (existingLocal && existingLocal.badges) || ["badge_rookie"],
            titles: [],
            equippedTitle: null,
            ownedCards: [],
            avatarFrame: null,
            profileEffect: null,
            history: [],
            saved: [],
            following_list: [],
            profileCompleted: isReturningUser || !!(existingLocal && existingLocal.profileCompleted)
          };
          window.setDoc(userRef, userData, {merge: true}).catch(e => console.error("Create user doc error:", e));
        }
        
        S.user = userData;
        S.me = Object.assign(S.me || {}, userData);
        S.me.id = user.uid;
        S.me.uid = user.uid;
        S.me.username = userData.username;
        S.me.name = userData.name || S.me.name;

        // Sync complete record to cloud
        window.setDoc(userRef, {
          id: user.uid,
          uid: user.uid,
          name: S.me.name,
          username: S.me.username,
          email: S.me.email || user.email || "",
          avatar: S.me.avatar || AV[0],
          bio: S.me.bio || "",
          role: S.me.role || "Member",
          level: S.me.level || 1,
          profileCompleted: S.me.profileCompleted !== false
        }, {merge: true}).catch(e => console.error("Update user doc error:", e));
        
        // Fetch detailed user state (stickers, reviews, favorites, history)
        await fetchAndHydrateUserState(user.uid).catch(()=>{});

        ensureAccounts();
        saveSync(false);
        
        // Only redirect to completeProfile if explicitly false and completely brand new without name/email
        if (userData.profileCompleted === false && !user.displayName && !user.email) {
          go('completeProfile', {}, false);
        } else if (S.page === 'login' || S.page === 'signup' || S.page === 'completeProfile' || S.page === 'splash') {
          toast("أهلاً بعودتك يا " + (userData.name || 'أوتاكو'), "ok");
          go('home', {}, false);
        } else {
          render();
        }
      }).catch(e => {
        console.error("Fetch user error:", e);
        // Fallback for offline mode
        let localUser = window._cloudUsers[user.uid] || (S.users || []).find(u => u.id === user.uid);
        if(!localUser && S.me && S.me.id === user.uid) localUser = S.me;
        if(!localUser && S.savedAccounts) localUser = S.savedAccounts.find(a => a.id === user.uid);
        
        if (localUser) {
          S.user = localUser;
          S.me = Object.assign(S.me || {}, localUser);
          S.me.id = user.uid;
          S.me.uid = user.uid;
        } else {
          S.user = { id: user.uid, uid: user.uid, name: user.displayName || 'أوتاكو (أوفلاين)', username: 'offline', email: user.email || '' };
          S.me = Object.assign(S.me || {}, S.user);
        }
        ensureAccounts();
        saveSync(false);
        
        if (S.page === 'login' || S.page === 'signup' || S.page === 'completeProfile' || S.page === 'splash') {
          toast("أنت تتصفح بدون إنترنت (أوفلاين)", "info");
          go('home', {}, false);
        } else {
          render();
        }
      });

      if (!window._usersSub) {
        const uq = window.query(window.collection(window.db, 'users'));
        window._usersSub = window.onSnapshot(uq, (snap) => {
          snap.docs.forEach(d => {
            window._cloudUsers[d.id] = d.data();
          });
          S.users = Object.values(window._cloudUsers);
          /* Silent sync - do not reload page on background user presence */
        }, (e) => console.error(e));
      }

    } else {
      if (window._notifSub) {
        window._notifSub();
        window._notifSub = null;
      }
      S.user = null;
      if (['workspace', 'create', 'editProfile', 'completeProfile'].includes(S.page)) {
        go('login', {}, false);
      }
      if (window._usersSub) {
        window._usersSub();
        window._usersSub = null;
      }
      render();
    }
  });


// Modern Chat Room Module for Anime Black (UNIFIED SYSTEM - SPEC COMPLIANT)
// Centralized Message Engine, Multi-Attachment Pipeline, Real Voice, Real GIF, Stickers,
// Scheduled Messages, Smart Scroll, Wallpaper Sync, Image Viewer, Presence & Typing.

console.log("Anime Black Unified Chat System Initialized!");
window.chatModuleInitialized = true;

// Inject keyframe animations and utility styles
(function() {
  if (!document.getElementById("chat_fx_styles")) {
    const st = document.createElement("style");
    st.id = "chat_fx_styles";
    st.textContent = `
      @keyframes heartBurst {
        0% { transform: translate(-50%, -50%) scale(0.6); opacity: 0; }
        50% { transform: translate(-50%, -50%) scale(1.6); opacity: 1; }
        100% { transform: translate(-50%, -80%) scale(1.2); opacity: 0; }
      }
      @keyframes pulseRed {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.3); opacity: 0.5; }
      }
      .pulse-red { animation: pulseRed 1s infinite ease-in-out; }
      .msgflash { animation: mflash 1.5s ease; }
      @keyframes mflash {
        0%, 100% { background: inherit; }
        50% { background: rgba(0, 163, 255, 0.28) !important; }
      }
      .chatbody {
        scroll-behavior: smooth;
        overscroll-behavior: contain;
        -webkit-overflow-scrolling: touch;
      }
      .msg {
        max-width: 82%;
        word-break: break-word;
        box-shadow: 0 1px 3px rgba(0,0,0,0.18);
        direction: auto;
        unicode-bidi: plaintext;
      }
      .msg.msg-mine, .msg.me {
        align-self: flex-start !important;
        margin-right: auto !important;
        margin-left: 0 !important;
      }
      .msg.msg-them, .msg.them {
        align-self: flex-end !important;
        margin-left: auto !important;
        margin-right: 0 !important;
      }
    `;
    document.head.appendChild(st);
  }
})();

// ============================================================================
// 1. GLOBAL STATE & ATTACHMENT CACHE
// ============================================================================
window.ATTACH_CACHE = window.ATTACH_CACHE || {}; // { [cid]: [ { type, src, name, size, file } ] }
window.ACTIVE_AUDIO = window.ACTIVE_AUDIO || null;
window.ACTIVE_AUDIO_MID = window.ACTIVE_AUDIO_MID || null;
window.VOICE_STATE = window.VOICE_STATE || { recording: false, mediaRecorder: null, stream: null, chunks: [], interval: null, sec: 0 };

// Helper Aliases for forward, copy, and selection
window.copyText = window.copyText || function(txt) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(txt).then(() => toast("تم نسخ النص", "ok"));
  }
};
window.toggleSelMsg = window.toggleSelMsg || function(mid) {
  if (typeof toggleSel === "function") toggleSel(mid);
};
window.sendFwdSheet = window.sendFwdSheet || function(mid) {
  openSheet('fwdSheet', mid);
};

// Helper: Ensure valid current user ID
function getChatMyUid() {
  if (typeof getMyUid === "function") return getMyUid();
  if (window.auth && window.auth.currentUser && window.auth.currentUser.uid) return window.auth.currentUser.uid;
  if (window.S && window.S.me && window.S.me.id) return window.S.me.id;
  return "me";
}

// Helper: Determine message ownership strictly from senderId
function isMsgMine(m) {
  if (!m) return false;
  const myUid = getChatMyUid();
  return (
    m.senderId === myUid ||
    m.fromId === myUid ||
    (typeof isMe === "function" && isMe(m.senderId)) ||
    m.from === "me" ||
    (window.S && window.S.me && (m.senderId === window.S.me.id || m.senderId === window.S.me.uid))
  );
}

// ============================================================================

// Global Linkify with @username Recognition
window.linkify = function(t) {
  if (!t) return "";
  let s = esc(t);
  s = s.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener" style="color:var(--cyan);text-decoration:underline" onclick="event.stopPropagation()">$1</a>');
  s = s.replace(/@([a-zA-Z0-9_\u0600-\u06FF]+)/g, '<span class="mention-tag" style="color:var(--accent);font-weight:700;cursor:pointer" onclick="event.stopPropagation();openProfileByUsername(\'$1\')">@$1</span>');
  return s;
};

window.openProfileByUsername = function(uname) {
  if (!uname) return;
  const clean = uname.replace(/^@/, '').toLowerCase();
  const uObj = (S.users || []).find(x => (x.username && x.username.toLowerCase() === clean) || (x.name && x.name.toLowerCase() === clean)) ||
               (S.chats || []).map(c => u(c.userId)).find(x => (x.username && x.username.toLowerCase() === clean) || (x.name && x.name.toLowerCase() === clean));
  if (uObj && uObj.id) {
    openProfile(uObj.id);
  } else {
    toast(`المستخدم @${clean} غير موجود`, "info");
  }
};

// Screenshot System Event Detection
if (!window._screenshotListenerAttached) {
  window._screenshotListenerAttached = true;
  window.addEventListener("keyup", function(e) {
    if (e.key === "PrintScreen" || (e.ctrlKey && e.key === "p") || (e.metaKey && e.shiftKey && (e.key === "3" || e.key === "4" || e.key === "s"))) {
      if (S.page === "chatRoom" && S.activeChat) {
        const cid = S.activeChat;
        const c = (S.chats || []).find(x => x.id === cid);
        if (c) {
          const mid = uid();
          const myUid = getChatMyUid();
          const eventMsg = {
            id: mid,
            clientMessageId: mid,
            conversationId: cid,
            senderId: myUid,
            senderName: S.me.name || "أنا",
            from: "system",
            type: "system_event",
            text: `التقط ${S.me.name || 'أحد المشاركين'} لقطة شاشة للدردشة 📸`,
            at: now(),
            createdAt: now()
          };
          c.messages = c.messages || [];
          c.messages.push(eventMsg);
          save();
          const msgBox = document.getElementById("msgs");
          if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), true);
          syncChatMessage(cid, eventMsg);
        }
      }
    }
  });
}


// 2. ATTACHMENT PIPELINE (Up to 5 items in ONE message)
// ============================================================================
window.removeAttachment = function(cid, index) {
  if (window.ATTACH_CACHE[cid]) {
    window.ATTACH_CACHE[cid].splice(index, 1);
  }
  const preview = document.getElementById("composer_attach_area");
  if (preview) {
    preview.innerHTML = renderAttachPreviewHTML(cid);
  }
  if (typeof updateComposerActionBtn === "function") {
    updateComposerActionBtn(cid);
  }
};

window.moveAttachment = function(cid, index, dir) {
  const arr = window.ATTACH_CACHE[cid];
  if (!arr) return;
  const target = index + dir;
  if (target < 0 || target >= arr.length) return;
  const temp = arr[index];
  arr[index] = arr[target];
  arr[target] = temp;
  const preview = document.getElementById("composer_attach_area");
  if (preview) preview.innerHTML = renderAttachPreviewHTML(cid);
  if (typeof updateComposerActionBtn === "function") {
    updateComposerActionBtn(cid);
  }
};

window.clearAttachments = function(cid) {
  window.ATTACH_CACHE[cid] = [];
  const preview = document.getElementById("composer_attach_area");
  if (preview) preview.innerHTML = "";
  if (typeof updateComposerActionBtn === "function") {
    updateComposerActionBtn(cid);
  }
};

function renderAttachPreviewHTML(cid) {
  const attachments = window.ATTACH_CACHE[cid] || [];
  if (!attachments.length) return "";
  return `
    <div id="attach_preview" style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--surface2);border-top:1px solid var(--line);overflow-x:auto;-webkit-overflow-scrolling:touch" class="no-sb">
      ${attachments.map((a, i) => `
        <div style="position:relative;width:64px;height:64px;border-radius:10px;background:var(--surface3);flex-shrink:0;overflow:hidden;border:1px solid var(--line2);box-shadow:0 2px 6px rgba(0,0,0,0.2)">
          ${a.type === 'image' || a.type === 'gif' ? `
            <img src="${a.src}" style="width:100%;height:100%;object-fit:cover" alt="">
          ` : a.type === 'video' ? `
            <video src="${a.src}" style="width:100%;height:100%;object-fit:cover"></video>
            <div style="position:absolute;inset:0;background:rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:#fff;pointer-events:none">
              ${I("play","i s")}
            </div>
          ` : `
            <div class="center" style="height:100%;color:var(--accent);flex-direction:column;gap:2px;padding:4px">
              ${I("file","i s")}
              <span style="font-size:8px;max-width:54px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(a.name||"ملف")}</span>
            </div>
          `}
          <button style="position:absolute;top:2px;left:2px;background:rgba(0,0,0,0.75);color:#fff;border:none;border-radius:50%;width:20px;height:20px;display:flex;align-items:center;justify-content:center;cursor:pointer;line-height:0;z-index:3" onclick="removeAttachment('${cid}', ${i})" aria-label="حذف">
            ${I("x","i s")}
          </button>
          ${i > 0 ? `<button style="position:absolute;bottom:2px;right:2px;background:rgba(0,0,0,0.75);color:#fff;border:none;border-radius:4px;width:18px;height:18px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:9px;z-index:3" onclick="moveAttachment('${cid}', ${i}, -1)" title="تقديم">◀</button>` : ''}
          ${i < attachments.length - 1 ? `<button style="position:absolute;bottom:2px;left:2px;background:rgba(0,0,0,0.75);color:#fff;border:none;border-radius:4px;width:18px;height:18px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:9px;z-index:3" onclick="moveAttachment('${cid}', ${i}, 1)" title="تأخير">▶</button>` : ''}
          <span style="position:absolute;top:2px;right:2px;background:rgba(0,0,0,0.65);color:#fff;font-size:8.5px;padding:1px 4px;border-radius:4px;font-family:monospace">${i+1}</span>
        </div>
      `).join('')}
      ${attachments.length < 5 ? `
        <button class="center" style="width:64px;height:64px;border-radius:10px;border:2px dashed var(--line2);background:transparent;color:var(--emerald);cursor:pointer;flex-shrink:0;flex-direction:column;gap:2px" onclick="openSheet('attachSheet')" title="إضافة مرفق آخر">
          <span style="font-size:18px;line-height:1;color:var(--emerald)">+</span>
          <span style="font-size:8.5px;color:var(--muted)">إضافة</span>
        </button>
      ` : ''}
      <button onclick="clearAttachments('${cid}')" style="margin-inline-start:auto;background:none;border:none;color:var(--rose);font-size:11px;font-weight:bold;cursor:pointer;flex-shrink:0;padding:4px 8px;white-space:nowrap">إلغاء الكل</button>
    </div>
  `;
}

// Client-Side Image Compression to ensure fast uploads & avoid Firestore limits
window.compressImageFile = function(file, maxW = 1280, maxH = 1280, quality = 0.82) {
  return new Promise((resolve) => {
    if (!file || !file.type.startsWith('image/') || file.type.includes('gif')) {
      const rd = new FileReader();
      rd.onload = () => resolve(rd.result);
      rd.onerror = () => resolve("");
      rd.readAsDataURL(file);
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let w = img.width;
        let h = img.height;
        if (w > maxW || h > maxH) {
          if (w > h) {
            h = Math.round((h * maxW) / w);
            w = maxW;
          } else {
            w = Math.round((w * maxH) / h);
            h = maxH;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = () => resolve(e.target.result);
      img.src = e.target.result;
    };
    reader.onerror = () => resolve("");
    reader.readAsDataURL(file);
  });
};

window.handleMediaSelection = async function(inp, type, cid) {
  if (!inp.files || !inp.files.length) return;
  window.ATTACH_CACHE[cid] = window.ATTACH_CACHE[cid] || [];
  const existingCount = window.ATTACH_CACHE[cid].length;
  const files = Array.from(inp.files);

  if (existingCount + files.length > 5) {
    toast("الحد الأقصى 5 مرفقات في الرسالة الواحدة", "info");
  }
  const allowed = files.slice(0, Math.max(0, 5 - existingCount));

  for (const f of allowed) {
    let srcData = "";
    if (type === "image" || (f.type && f.type.startsWith("image/"))) {
      srcData = await window.compressImageFile(f, 1280, 1280, 0.82);
    } else {
      srcData = await new Promise((res) => {
        const rd = new FileReader();
        rd.onload = () => res(rd.result);
        rd.onerror = () => res("");
        rd.readAsDataURL(f);
      });
    }

    window.ATTACH_CACHE[cid].push({
      type: type,
      src: srcData,
      name: f.name || (type === "video" ? "فيديو" : "صورة"),
      size: f.size || 0,
      mimeType: f.type || "",
      file: f
    });
  }

  const preview = document.getElementById("composer_attach_area");
  if (preview) {
    preview.innerHTML = renderAttachPreviewHTML(cid);
  } else {
    render();
  }
  if (typeof updateComposerActionBtn === "function") {
    updateComposerActionBtn(cid);
  }
};

// attachToChat: Supports Direct Chat, Group Rooms, World Rooms, and Community Channels
window.attachToChat = function(k) {
  closeOvl();

  // Check if inside group, world, or community channel room
  const room = S.page === "groupRoom" ? { kind: "group", o: (S.groups||[]).find(x => x.id === S.params.id) } :
               S.page === "worldRoom" ? { kind: "world", o: (S.worlds||[]).find(x => x.id === S.params.id) } : null;

  const cid = S.activeChat || (S.params && S.params.id);
  const c = cid ? (S.chats || []).find(x => x.id === cid) : null;

  if (!c && !room) {
    toast("افتح محادثة أو غرفة أولاً", "err");
    return;
  }

  // If in Group / World room, delegate to room attachment helper
  if (room) {
    const pushRoom = (m => {
      const mid = uid();
      const myUid = getChatMyUid();
      const item = Object.assign({ id: mid, uid: myUid, from: "me", at: now() }, m);
      room.o.messages = room.o.messages || [];
      room.o.messages.push(item);
      room.o.lastAt = now();
      save();
      render();
    });

    if (k === 'image' || k === 'video' || k === 'camera') {
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.accept = (k === 'video') ? 'video/*' : 'image/*';
      if (k === 'camera') inp.capture = 'environment';
      inp.onchange = () => {
        const f = inp.files && inp.files[0];
        if (!f) return;
        const rd = new FileReader();
        rd.onload = () => pushRoom({ type: (k === 'video' ? 'video' : 'image'), src: rd.result });
        rd.readAsDataURL(f);
      };
      inp.click();
    } else if (k === 'mic') {
      pushRoom({ type: 'voice', dur: 12 });
    } else if (k === 'file') {
      const inp = document.createElement('input');
      inp.type = 'file';
      inp.onchange = () => {
        const f = inp.files && inp.files[0];
        if (!f) return;
        const rd = new FileReader();
        rd.onload = () => pushRoom({ type: 'file', src: rd.result, name: f.name });
        rd.readAsDataURL(f);
      };
      inp.click();
    } else if (k === 'map') {
      pushRoom({ type: 'map', lat: 35.6983, lng: 139.7731, label: 'أكيهابارا، طوكيو' });
    } else if (k === 'user') {
      openSheet('contactSheet', room.o.id);
    } else if (k === 'poll') {
      openSheet('pollSheet', `${room.kind}:${room.o.id}`);
    }
    return;
  }

  // Direct 1-on-1 Chat
  if (k === 'image' || k === 'video' || k === 'camera') {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.multiple = (k !== 'camera');
    inp.accept = (k === 'video') ? 'video/*' : 'image/*';
    if (k === 'camera') inp.capture = 'environment';
    inp.onchange = () => handleMediaSelection(inp, k === 'video' ? 'video' : 'image', c.id);
    inp.click();
  } else if (k === 'file') {
    const inp = document.createElement('input');
    inp.type = 'file';
    inp.multiple = true;
    inp.onchange = () => handleMediaSelection(inp, 'file', c.id);
    inp.click();
  } else if (k === 'mic') {
    startVoiceRecord();
  } else if (k === 'map') {
    if (navigator.geolocation) {
      toast("جارٍ تحديد الموقع الجغرافي...", "info");
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          sendLocationMsg(c.id, lat, lng, "موقعي المباشر", `إحداثيات: ${lat.toFixed(4)}, ${lng.toFixed(4)}`);
        },
        (err) => {
          console.warn("Geolocation fallback:", err);
          sendLocationMsg(c.id, 35.6983, 139.7731, "أكيهابارا، طوكيو (اليابان)", "حي الأنمي والإلكترونيات الشهير");
        },
        { timeout: 8000 }
      );
    } else {
      sendLocationMsg(c.id, 35.6983, 139.7731, "أكيهابارا، طوكيو (اليابان)", "حي الأنمي والإلكترونيات الشهير");
    }
  } else if (k === 'user') {
    openSheet('contactSheet', c.id);
  } else if (k === 'poll') {
    openSheet('pollSheet', c.id);
  }
};

function sendLocationMsg(cid, lat, lng, label, address) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  const myUid = getChatMyUid();
  const mid = uid();
  const msg = {
    id: mid,
    clientMessageId: mid,
    conversationId: cid,
    from: "me",
    senderId: myUid,
    senderName: S.me.name || "أنا",
    type: "location",
    lat: lat,
    lng: lng,
    label: label,
    address: address || "",
    text: `📍 ${label}`,
    at: now(),
    createdAt: now(),
    st: 1,
    pending: true
  };
  c.messages.push(msg);
  c.last = `📍 ${label}`;
  c.lastAt = now();
  save();
  snd("send");
  window.updateChatDom(document.getElementById("msgs"), c, u(c.userId), true);
  syncChatMessage(cid, msg);
  toast("تمت مشاركة الموقع بنجاح", "ok");
}

// ============================================================================
// 3. UNIFIED MESSAGE SENDING PIPELINE (Instant Optimistic UI & Upload Progress)
// ============================================================================
window.updateMsgProgressDOM = function(msgId, pct, isUploading) {
  const pEl = document.getElementById("m_progress_" + msgId);
  if (!pEl) {
    const c = (S.chats || []).find(x => (x.messages || []).some(m => m.id === msgId));
    if (c) {
      const msgBox = document.getElementById("msgs");
      if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), false);
    }
    return;
  }
  if (!isUploading || pct >= 100) {
    pEl.style.transition = "all 0.3s ease";
    pEl.style.opacity = "0";
    pEl.style.transform = "scaleY(0.5)";
    setTimeout(() => { 
      if (pEl && pEl.parentNode) pEl.remove(); 
      const mEl = document.getElementById("m_" + msgId);
      if (mEl) {
        const tmEl = mEl.querySelector(".tm");
        const msg = msgById(msgId);
        if (tmEl && msg) tmEl.innerHTML = metaHTML(msg);
      }
    }, 320);
    return;
  }
  const fill = pEl.querySelector(".pfill");
  const txt = pEl.querySelector(".ptxt");
  const pctNum = pEl.querySelector(".pnum");
  if (fill) fill.style.width = pct + "%";
  if (txt) txt.textContent = pct + "% جارٍ التحميل والرفع...";
  if (pctNum) pctNum.textContent = pct + "%";
};


window.uploadChatAttachmentsWithProgress = async function(cid, msg, rawAttachments) {
  const c = (S.chats || []).find(x => x.id === cid);
  const filesToUpload = (rawAttachments || []).filter(a => a && a.file);
  const totalCount = Math.max(1, filesToUpload.length);

  msg.uploading = true;
  msg.uploadProgress = 10;
  window.updateMsgProgressDOM(msg.id, 10, true);

  let progressMap = {};
  const updateAggregateProgress = (forceVal) => {
    if (forceVal !== undefined) {
      msg.uploadProgress = forceVal;
      window.updateMsgProgressDOM(msg.id, forceVal, true);
      return;
    }
    let sum = 0;
    Object.values(progressMap).forEach(p => { sum += p; });
    const avg = Math.min(95, Math.max(15, Math.round(sum / totalCount)));
    msg.uploadProgress = avg;
    window.updateMsgProgressDOM(msg.id, avg, true);
  };

  let hasErrors = false;

  for (let i = 0; i < filesToUpload.length; i++) {
    const item = filesToUpload[i];
    const file = item.file;
    const fileExt = (file.name && file.name.includes('.')) ? file.name.split('.').pop() : (file.type ? file.type.split('/').pop() : 'dat');
    const fileName = `media_${Date.now()}_${Math.random().toString(36).substring(2, 7)}.${fileExt}`;
    const storagePath = `chats/${cid}/media/${fileName}`;

    let uploadedUrl = null;
    if (window.storage && window.ref && window.uploadBytesResumable && window.getDownloadURL) {
      try {
        const storageRef = window.ref(window.storage, storagePath);
        const uploadTask = window.uploadBytesResumable(storageRef, file);

        await new Promise((resolve, reject) => {
          uploadTask.on('state_changed',
            (snapshot) => {
              const pct = (snapshot.bytesTransferred / (snapshot.totalBytes || 1)) * 100;
              progressMap[i] = Math.min(95, Math.round(pct));
              updateAggregateProgress();
            },
            (err) => {
              console.warn("Storage upload error fallback:", err);
              reject(err);
            },
            async () => {
              try {
                const url = await window.getDownloadURL(uploadTask.snapshot.ref);
                if (url) {
                  uploadedUrl = url;
                  resolve();
                } else {
                  reject(new Error("No URL"));
                }
              } catch(e) {
                reject(e);
              }
            }
          );
        });
      } catch(e) {
        console.warn("Storage upload exception:", e);
        hasErrors = true;
      }
    } else {
       hasErrors = true;
    }

    if (uploadedUrl) {
      item.src = uploadedUrl;
      item.file = null; // Free memory
      if (msg.attachments && msg.attachments[i]) {
        msg.attachments[i].src = uploadedUrl;
        msg.attachments[i].file = null;
      }
      if (i === 0) msg.src = uploadedUrl;
    }

    progressMap[i] = 100;
  }

  if (hasErrors) {
    msg.uploading = false;
    msg.st = 4; // Failed
    msg.pending = true;
    toast('فشل رفع بعض الملفات', 'err');
    saveDebounced();
    window.updateMsgProgressDOM(msg.id, 0, false);
    return;
  }

  // All files uploaded & processed successfully!
  msg.uploadProgress = 100;
  msg.uploading = false;
  msg.st = 2; // Sent ✓
  msg.pending = false;
  saveDebounced();
  window.updateMsgProgressDOM(msg.id, 100, false);
  
  // Actually sync the message to cloud now that media is real
  syncChatMessage(cid, msg);
};

window._unifiedSendMsg = function(cid) {
  if (typeof cid === "object" && cid !== null) {
    cid = cid.id || cid.cid;
  }
  cid = cid || S.activeChat || (S.params && S.params.id);
  const inp = document.getElementById("minp");
  if (!inp) return;
  let text = (inp.value || "").trim();
  window.ATTACH_CACHE = window.ATTACH_CACHE || {};
  const rawAttachments = (window.ATTACH_CACHE[cid]) ? [...window.ATTACH_CACHE[cid]] : [];

  if (!text && rawAttachments.length === 0) return;

  let c = (S.chats || []).find(x => x.id === cid);
  if (!c && cid) {
    c = { id: cid, userId: (S.params && S.params.uid) || "user_friend", messages: [], last: "", lastAt: now(), unread: 0 };
    S.chats = S.chats || [];
    S.chats.unshift(c);
  }
  if (!c) return;
  c.messages = c.messages || [];

  // Handle message edit mode
  if (S.editMid) {
    const m = msgById(S.editMid);
    if (m) {
      m.text = text;
      m.isEdited = true;
      m.edited = true;
      m.updatedAt = now();
      saveDebounced();
      syncChatMessage(cid, m);
      toast("تم تعديل الرسالة", "ok");
    }
    S.editMid = null;
    inp.value = "";
    inp.style.height = "auto";
    const eb = document.getElementById("edit_bar");
    if (eb) eb.remove();
    const msgBox = document.getElementById("msgs");
    if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), false);
    return;
  }

  const myUid = getChatMyUid();
  const mid = uid();

  // Determine primary type
  let primaryType = "text";
  if (rawAttachments.length > 1) {
    primaryType = "media";
  } else if (rawAttachments.length === 1) {
    primaryType = rawAttachments[0].type || "media";
  }

  const hasFilesToUpload = rawAttachments.some(a => a && a.file);

  // Build ONE unified message with immediate optimistic sent status (st: 2) for text
  const msg = {
    id: mid,
    clientMessageId: mid,
    conversationId: cid,
    from: "me",
    senderId: myUid,
    senderName: S.me.name || "أنا",
    type: primaryType,
    text: text, // Caption or text body
    attachments: rawAttachments.map(a => ({
      type: a.type,
      src: a.src,
      name: a.name || "",
      size: a.size || 0
    })),
    // Backward compatibility for single attachment
    src: rawAttachments.length ? rawAttachments[0].src : null,
    name: rawAttachments.length ? rawAttachments[0].name : null,
    size: rawAttachments.length ? rawAttachments[0].size : null,
    at: now(),
    createdAt: now(),
    updatedAt: now(),
    // Instant delivery checkmark (st: 2) for text; media shows uploading progress bar first
    st: hasFilesToUpload ? 1 : 2,
    pending: hasFilesToUpload ? true : false,
    uploadProgress: hasFilesToUpload ? 0 : 100,
    uploading: hasFilesToUpload ? true : false,
    reacts: [],
    isEdited: false,
    isDeleted: false,
    isScheduled: false
  };

  if (text) {
    const mentionMatches = text.match(/@([a-zA-Z0-9_\u0600-\u06FF]+)/g);
    if (mentionMatches && mentionMatches.length > 0) {
      msg.mentions = mentionMatches.map(m => m.slice(1));
    }
  }

  // Reply reference
  if (S.replyTo) {
    const qm = msgById(S.replyTo);
    if (qm) {
      msg.replyToMessageId = qm.id;
      msg.quote = {
        id: qm.id,
        t: (qm.text || (qm.attachments && qm.attachments.length ? "مرفقات" : "رسالة")).slice(0, 60),
        n: qm.senderName || (isMsgMine(qm) ? "أنت" : "المستخدم"),
        type: qm.type || "text"
      };
    }
    S.replyTo = null;
    const rb = document.getElementById("reply_bar");
    if (rb) rb.remove();
  }

  // Push to local conversation immediately
  c.messages.push(msg);

  // Update conversation last-message preview
  if (rawAttachments.length > 1) {
    c.last = `📷 ${rawAttachments.length} وسائط` + (text ? `: ${text}` : "");
  } else if (rawAttachments.length === 1) {
    const atype = rawAttachments[0].type;
    c.last = (atype === "image" ? "صورة" : atype === "video" ? "فيديو" : "ملف") + (text ? `: ${text}` : "");
  } else {
    c.last = text;
  }
  c.lastAt = now();

  // Clear composer & attachments cache immediately (0ms UI latency)
  if (typeof stopTyping === "function") stopTyping(cid);
  window.ATTACH_CACHE[cid] = [];
  inp.value = "";
  inp.style.height = "auto";
  const attachArea = document.getElementById("composer_attach_area");
  if (attachArea) attachArea.innerHTML = "";

  if (S.chatDrafts && S.chatDrafts[cid]) {
    delete S.chatDrafts[cid];
  }

  saveDebounced();
  snd("send");

  // Smooth DOM update with forced scroll to bottom (immediate feedback)
  const msgBox = document.getElementById("msgs");
  if (msgBox) {
    window.updateChatDom(msgBox, c, u(c.userId), true);
  }

  setTimeout(() => { try { inp.focus(); } catch(e){} }, 40);

  // Background sync: Media uploads with real progress bar, or direct sync for text
  if (hasFilesToUpload) {
    window.uploadChatAttachmentsWithProgress(cid, msg, rawAttachments);
  } else {
    syncChatMessage(cid, msg);
  }
};

window.updateComposerActionBtn = function(cid) {
  const minp = document.getElementById("minp");
  const sendBtn = document.getElementById("chat_send_btn");
  if (!sendBtn) return;
  const targetCid = cid || sendBtn.getAttribute("data-cid") || (typeof S !== "undefined" && S.params && S.params.id) || (typeof S !== "undefined" && S.activeChat);
  const val = (minp && minp.value) ? minp.value.trim() : "";
  const hasAttachments = (window.ATTACH_CACHE && window.ATTACH_CACHE[targetCid] && window.ATTACH_CACHE[targetCid].length > 0);

  if (val.length > 0 || hasAttachments || (typeof S !== "undefined" && S.editMid)) {
    sendBtn.innerHTML = typeof I === "function" ? I("send", "i s") : "➤";
    sendBtn.setAttribute("aria-label", "إرسال");
    sendBtn.title = "إرسال الرسالة";
    sendBtn.style.background = "linear-gradient(135deg, #00A3FF, #8B5CF6)";
    sendBtn.style.color = "#ffffff";
    sendBtn.style.border = "none";
    sendBtn.style.borderRadius = "50%";
    sendBtn.style.boxShadow = "0 4px 14px rgba(0, 163, 255, 0.4)";
  } else {
    sendBtn.innerHTML = typeof I === "function" ? I("mic", "i s") : "🎤";
    sendBtn.setAttribute("aria-label", "تسجيل صوتي");
    sendBtn.title = "تسجيل صوتي (اضغط للتسجيل)";
    sendBtn.style.background = "rgba(0, 163, 255, 0.15)";
    sendBtn.style.color = "var(--accent)";
    sendBtn.style.border = "1px solid rgba(0, 163, 255, 0.3)";
    sendBtn.style.borderRadius = "50%";
    sendBtn.style.boxShadow = "none";
  }
};

window.handleComposerActionBtn = function(cid) {
  const minp = document.getElementById("minp");
  const targetCid = cid || (typeof S !== "undefined" && S.params && S.params.id) || S.activeChat;
  const val = (minp && minp.value) ? minp.value.trim() : "";
  const hasAttachments = (window.ATTACH_CACHE && window.ATTACH_CACHE[targetCid] && window.ATTACH_CACHE[targetCid].length > 0);

  if (val.length > 0 || hasAttachments || (typeof S !== "undefined" && S.editMid)) {
    if (window.sendMsg) window.sendMsg(targetCid);
  } else {
    if (window.startVoiceRecord) window.startVoiceRecord();
  }
};

window.sendMsg = window._unifiedSendMsg;

// ============================================================================
// 4. REAL VOICE RECORDING & PLAYBACK ENGINE (MediaRecorder API)
// ============================================================================
window.startVoiceRecord = async function() {
  const main = document.getElementById('main_composer');
  const voice = document.getElementById('voice_record_area');
  const previewArea = document.getElementById('voice_preview_area');
  const timer = document.getElementById('voice_timer');
  const waves = document.getElementById('voice_waves');
  const pauseBtn = document.getElementById('voice_pause_btn');
  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      toast("تسجيل الصوت غير مدعوم في هذا المتصفح", "err");
      return;
    }
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    window.VOICE_STATE.stream = stream;
    window.VOICE_STATE.chunks = [];
    const mediaRecorder = new MediaRecorder(stream);
    window.VOICE_STATE.mediaRecorder = mediaRecorder;
    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        window.VOICE_STATE.chunks.push(e.data);
      }
    };
    mediaRecorder.start(100);
    window.VOICE_STATE.recording = true;
    window.VOICE_STATE.paused = false;
    window.VOICE_STATE.sec = 0;
    if (main && voice) {
      main.style.display = 'none';
      voice.style.display = 'flex';
      if (previewArea) previewArea.style.display = 'none';
    }
    if (pauseBtn) pauseBtn.innerHTML = I("pause","i s");
    if (waves) waves.innerHTML = '';
    if (timer) timer.innerText = '0:00';
    
    // Attach swipe-to-cancel touch gestures
    if (voice) {
      let touchStartX = 0;
      voice.ontouchstart = (e) => {
        if (e.touches && e.touches[0]) touchStartX = e.touches[0].clientX;
      };
      voice.ontouchmove = (e) => {
        if (!window.VOICE_STATE.recording || !e.touches || !e.touches[0]) return;
        const diffX = e.touches[0].clientX - touchStartX;
        const hint = document.getElementById("voice_swipe_hint");
        if (diffX < -15 && hint) {
          hint.style.transform = `translateX(${diffX}px)`;
          hint.style.color = "var(--rose)";
        }
        if (diffX < -80) {
          toast("تم إلغاء التسجيل الصوتي بالسحب ⟵", "info");
          cancelVoice();
        }
      };
      voice.ontouchend = () => {
        const hint = document.getElementById("voice_swipe_hint");
        if (hint) { hint.style.transform = ""; hint.style.color = ""; }
      };
    }

    clearInterval(window.VOICE_STATE.interval);
    window.VOICE_STATE.interval = setInterval(() => {
      if (window.VOICE_STATE.paused) return;
      window.VOICE_STATE.sec++;
      const s = window.VOICE_STATE.sec;
      if (timer) {
        timer.innerText = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
      }
      if (waves) {
        const h = Math.min(22, 5 + Math.floor(Math.random() * 16));
        waves.insertAdjacentHTML('beforeend', `<i style="width:2.5px;height:${h}px;background:var(--accent);border-radius:99px;flex-shrink:0;margin:0 1px"></i>`);
        waves.scrollLeft = waves.scrollWidth;
      }
    }, 1000);
  } catch (err) {
    console.warn("Microphone access error:", err);
    toast("يرجى تفعيل إذن الميكروفون للتسجيل الصوتي", "err");
    cancelVoice();
  }
};

window.togglePauseVoice = function() {
  const rec = window.VOICE_STATE.mediaRecorder;
  const btn = document.getElementById("voice_pause_btn");
  if (!rec) return;
  if (rec.state === "recording") {
    try { rec.pause(); } catch(e){}
    window.VOICE_STATE.paused = true;
    if (btn) btn.innerHTML = I("play","i s");
    toast("تم إيقاف التسجيل مؤقتاً", "info");
  } else if (rec.state === "paused") {
    try { rec.resume(); } catch(e){}
    window.VOICE_STATE.paused = false;
    if (btn) btn.innerHTML = I("pause","i s");
    toast("تم استئناف التسجيل", "info");
  }
};

window.cancelVoice = function() {
  clearInterval(window.VOICE_STATE.interval);
  if (window.VOICE_STATE.mediaRecorder && window.VOICE_STATE.mediaRecorder.state !== 'inactive') {
    try { window.VOICE_STATE.mediaRecorder.stop(); } catch(e){}
  }
  if (window.VOICE_STATE.stream) {
    window.VOICE_STATE.stream.getTracks().forEach(t => t.stop());
    window.VOICE_STATE.stream = null;
  }
  if (window.VOICE_STATE.previewAudio) {
    try { window.VOICE_STATE.previewAudio.pause(); } catch(e){}
    window.VOICE_STATE.previewAudio = null;
  }
  window.VOICE_STATE.recording = false;
  window.VOICE_STATE.chunks = [];
  window.VOICE_STATE.previewBlob = null;
  const main = document.getElementById('main_composer');
  const voice = document.getElementById('voice_record_area');
  const prevArea = document.getElementById('voice_preview_area');
  if (main && voice) {
    main.style.display = 'flex';
    voice.style.display = 'none';
    if (prevArea) prevArea.style.display = 'none';
  }
};

window.stopAndPreviewVoice = function(cid) {
  clearInterval(window.VOICE_STATE.interval);
  const rec = window.VOICE_STATE.mediaRecorder;
  if (!rec) { cancelVoice(); return; }
  rec.onstop = () => {
    const blob = new Blob(window.VOICE_STATE.chunks, { type: 'audio/webm' });
    if (window.VOICE_STATE.stream) {
      window.VOICE_STATE.stream.getTracks().forEach(t => t.stop());
      window.VOICE_STATE.stream = null;
    }
    window.VOICE_STATE.recording = false;
    window.VOICE_STATE.previewBlob = blob;
    window.VOICE_STATE.previewDur = Math.max(1, window.VOICE_STATE.sec || 1);
    
    // Switch to preview UI
    const voiceArea = document.getElementById('voice_record_area');
    const previewArea = document.getElementById('voice_preview_area');
    if (voiceArea) voiceArea.style.display = 'none';
    if (previewArea) {
      const dur = window.VOICE_STATE.previewDur;
      previewArea.style.display = 'flex';
      previewArea.innerHTML = `
        <button class="iconbtn" id="voice_prev_play" onclick="togglePlayVoicePreview()" style="color:var(--cyan)">${I("play","i s")}</button>
        <span class="tiny mono b" id="voice_prev_timer" style="color:var(--cyan)">0:00 / ${Math.floor(dur/60)}:${String(dur%60).padStart(2,'0')}</span>
        <div class="g1" style="height:4px;background:var(--surface3);border-radius:99px;position:relative;overflow:hidden">
          <div id="voice_prev_prog" style="width:0%;height:100%;background:var(--cyan);transition:width .1s"></div>
        </div>
        <button class="iconbtn" onclick="cancelVoice()" style="color:var(--rose)" title="حذف التسجيل">${I("trash","i s")}</button>
        <button class="iconbtn" onclick="sendPreviewVoice('${cid}')" style="background:var(--emerald);color:#fff;border-radius:50%;box-shadow:0 4px 12px rgba(16,185,129,0.3)" title="إرسال">${I("send","i s")}</button>
      `;
    }
  };
  try { rec.stop(); } catch(e) { cancelVoice(); }
};

window.togglePlayVoicePreview = function() {
  if (!window.VOICE_STATE.previewBlob) return;
  if (!window.VOICE_STATE.previewAudio) {
    window.VOICE_STATE.previewAudio = new Audio(URL.createObjectURL(window.VOICE_STATE.previewBlob));
    window.VOICE_STATE.previewAudio.ontimeupdate = () => {
      const a = window.VOICE_STATE.previewAudio;
      const cur = Math.floor(a.currentTime);
      const tot = window.VOICE_STATE.previewDur;
      const tEl = document.getElementById("voice_prev_timer");
      const pEl = document.getElementById("voice_prev_prog");
      if (tEl) tEl.innerText = `${Math.floor(cur/60)}:${String(cur%60).padStart(2,'0')} / ${Math.floor(tot/60)}:${String(tot%60).padStart(2,'0')}`;
      if (pEl && a.duration) pEl.style.width = `${(a.currentTime / a.duration) * 100}%`;
    };
    window.VOICE_STATE.previewAudio.onended = () => {
      const btn = document.getElementById("voice_prev_play");
      if (btn) btn.innerHTML = I("play","i s");
      const pEl = document.getElementById("voice_prev_prog");
      if (pEl) pEl.style.width = "0%";
    };
  }
  const a = window.VOICE_STATE.previewAudio;
  const btn = document.getElementById("voice_prev_play");
  if (a.paused) {
    a.play();
    if (btn) btn.innerHTML = I("pause","i s");
  } else {
    a.pause();
    if (btn) btn.innerHTML = I("play","i s");
  }
};

window.sendPreviewVoice = function(cid) {
  if (!window.VOICE_STATE.previewBlob) { cancelVoice(); return; }
  const blob = window.VOICE_STATE.previewBlob;
  const dur = window.VOICE_STATE.previewDur || 1;
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) { cancelVoice(); return; }
  const reader = new FileReader();
  reader.onload = () => {
    const dataUrl = reader.result;
    const mid = uid();
    const myUid = getChatMyUid();
    const msg = {
      id: mid,
      clientMessageId: mid,
      conversationId: cid,
      from: "me",
      senderId: myUid,
      senderName: S.me.name || "أنا",
      type: "voice",
      src: dataUrl,
      dur: dur,
      text: "رسالة صوتية",
      at: now(),
      createdAt: now(),
      st: 2,
      pending: false
    };
    c.messages.push(msg);
    c.last = "🎤 رسالة صوتية";
    c.lastAt = now();
    saveDebounced();
    snd("send");
    const msgBox = document.getElementById("msgs");
    if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), true);
    syncChatMessage(cid, msg);
    cancelVoice();
  };
  reader.readAsDataURL(blob);
};

window.finishVoice = function(cid) {
  clearInterval(window.VOICE_STATE.interval);
  const dur = Math.max(1, window.VOICE_STATE.sec || 1);
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c || !window.VOICE_STATE.mediaRecorder) {
    cancelVoice();
    return;
  }
  const rec = window.VOICE_STATE.mediaRecorder;
  rec.onstop = () => {
    const blob = new Blob(window.VOICE_STATE.chunks, { type: 'audio/webm' });
    if (window.VOICE_STATE.stream) {
      window.VOICE_STATE.stream.getTracks().forEach(t => t.stop());
      window.VOICE_STATE.stream = null;
    }
    window.VOICE_STATE.recording = false;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      const mid = uid();
      const myUid = getChatMyUid();
      const msg = {
        id: mid,
        clientMessageId: mid,
        conversationId: cid,
        from: "me",
        senderId: myUid,
        senderName: S.me.name || "أنا",
        type: "voice",
        src: dataUrl,
        dur: dur,
        text: "رسالة صوتية",
        at: now(),
        createdAt: now(),
        st: 2,
        pending: false
      };
      c.messages.push(msg);
      c.last = "🎤 رسالة صوتية";
      c.lastAt = now();
      saveDebounced();
      snd("send");
      const msgBox = document.getElementById("msgs");
      if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), true);
      syncChatMessage(cid, msg);
    };
    reader.readAsDataURL(blob);
  };
  try {
    rec.stop();
  } catch(e) {
    cancelVoice();
  }
  const main = document.getElementById('main_composer');
  const voice = document.getElementById('voice_record_area');
  if (main && voice) {
    main.style.display = 'flex';
    voice.style.display = 'none';
  }
};

// Real Voice Playback
window.playVoice = function(btn, mid) {
  const m = msgById(mid);
  if (!m || !m.src) {
    toast("ملف الصوت غير متوفر", "err");
    return;
  }
  if (window.ACTIVE_AUDIO && window.ACTIVE_AUDIO_MID === mid) {
    if (window.ACTIVE_AUDIO.paused) {
      window.ACTIVE_AUDIO.play();
      if (btn) btn.innerHTML = I("pause", "i s");
    } else {
      window.ACTIVE_AUDIO.pause();
      if (btn) btn.innerHTML = I("play", "i s");
    }
    return;
  }
  if (window.ACTIVE_AUDIO) {
    window.ACTIVE_AUDIO.pause();
    const prevBtn = document.getElementById("vbtn_" + window.ACTIVE_AUDIO_MID);
    if (prevBtn) prevBtn.innerHTML = I("play", "i s");
  }
  const audio = new Audio(m.src);
  window.ACTIVE_AUDIO = audio;
  window.ACTIVE_AUDIO_MID = mid;
  if (btn) btn.innerHTML = I("pause", "i s");
  const timeEl = document.getElementById("vtime_" + mid);
  const barsEl = document.getElementById("vbars_" + mid);
  audio.ontimeupdate = () => {
    const cur = Math.floor(audio.currentTime);
    const tot = Math.floor(audio.duration || m.dur || 14);
    if (timeEl) {
      timeEl.innerText = Math.floor(cur / 60) + ":" + String(cur % 60).padStart(2, "0") + " / " + Math.floor(tot / 60) + ":" + String(tot % 60).padStart(2, "0");
    }
    if (barsEl && audio.duration) {
      const progress = audio.currentTime / audio.duration;
      const bars = barsEl.querySelectorAll("i");
      const activeCount = Math.floor(progress * bars.length);
      bars.forEach((b, i) => {
        b.style.background = i <= activeCount ? "var(--cyan)" : "";
      });
    }
  };
  audio.onended = () => {
    if (btn) btn.innerHTML = I("play", "i s");
    if (timeEl) timeEl.innerText = "0:" + String(m.dur || 14).padStart(2, "0");
    if (barsEl) {
      barsEl.querySelectorAll("i").forEach(b => b.style.background = "");
    }
    window.ACTIVE_AUDIO = null;
    window.ACTIVE_AUDIO_MID = null;
  };
  audio.play().catch(e => {
    console.warn("Audio playback error:", e);
    if (btn) btn.innerHTML = I("play", "i s");
  });
};

window.seekVoice = function(e, mid) {
  if (!window.ACTIVE_AUDIO || window.ACTIVE_AUDIO_MID !== mid) return;
  const barsEl = document.getElementById("vbars_" + mid);
  if (!barsEl || !window.ACTIVE_AUDIO.duration) return;
  const rect = barsEl.getBoundingClientRect();
  const clickX = e.clientX - rect.left;
  const pct = Math.max(0, Math.min(1, clickX / rect.width));
  window.ACTIVE_AUDIO.currentTime = pct * window.ACTIVE_AUDIO.duration;
};


// 5. IMAGE LIGHTBOX VIEWER (Multi-media swipe, zoom, counter, download)
// ============================================================================
window.openImgViewer = function(items, initialIndex) {
  let mediaList = [];
  const activeCid = S.activeChat || (S.params && S.params.id);
  const activeChat = (S.chats || []).find(x => x.id === activeCid);

  if (Array.isArray(items) && items.length > 1) {
    mediaList = items.map(x => typeof x === 'string' ? { src: x, type: 'image' } : x);
  } else {
    let targetSrc = "";
    if (Array.isArray(items) && items.length === 1) {
      targetSrc = typeof items[0] === 'string' ? items[0] : (items[0].src || "");
    } else if (typeof items === 'string') {
      targetSrc = items;
    } else if (items && items.src) {
      targetSrc = items.src;
    }

    if (activeChat && activeChat.messages) {
      activeChat.messages.forEach(m => {
        if (!m.gone && !m.isDeleted) {
          if (m.attachments && m.attachments.length) {
            m.attachments.forEach(a => {
              if (a.type === 'image' || a.type === 'video' || a.type === 'gif') {
                mediaList.push({ src: a.src, type: a.type, name: a.name || 'وسائط' });
              }
            });
          } else if ((m.type === 'image' || m.type === 'video' || m.type === 'gif') && m.src) {
            mediaList.push({ src: m.src, type: m.type, name: m.text || 'وسائط' });
          }
        }
      });
    }

    if (!mediaList.length && targetSrc) {
      mediaList = [{ src: targetSrc, type: 'image' }];
    }

    if (targetSrc && mediaList.length > 0) {
      const foundIdx = mediaList.findIndex(x => x.src === targetSrc);
      if (foundIdx !== -1) {
        initialIndex = foundIdx;
      }
    }
  }

  if (!mediaList.length) return;

  let curIdx = Math.max(0, Math.min(mediaList.length - 1, initialIndex || 0));

  let ovl = document.getElementById("img_viewer_overlay");
  if (!ovl) {
    ovl = document.createElement("div");
    ovl.id = "img_viewer_overlay";
    ovl.style.cssText = "position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.96);backdrop-filter:blur(12px);display:flex;flex-direction:column;align-items:center;justify-content:center;user-select:none;touch-action:none";
    document.body.appendChild(ovl);
  }

  let startX = 0, deltaX = 0;
  ovl.ontouchstart = (e) => {
    if (e.touches.length === 1) startX = e.touches[0].clientX;
  };
  ovl.ontouchmove = (e) => {
    if (e.touches.length === 1) deltaX = e.touches[0].clientX - startX;
  };
  ovl.ontouchend = () => {
    if (deltaX > 40) window._ivPrev();
    else if (deltaX < -40) window._ivNext();
    startX = 0; deltaX = 0;
  };

  const keyHandler = (e) => {
    if (e.key === "ArrowRight" || e.key === "ArrowUp") window._ivPrev();
    else if (e.key === "ArrowLeft" || e.key === "ArrowDown") window._ivNext();
    else if (e.key === "Escape") window.closeImgViewer();
  };
  window.addEventListener("keydown", keyHandler);

  window.closeImgViewer = () => {
    window.removeEventListener("keydown", keyHandler);
    if (ovl) ovl.remove();
  };

  function renderViewer() {
    const cur = mediaList[curIdx] || {};
    const isVid = cur.type === "video" || (cur.src && (cur.src.startsWith("data:video") || cur.src.includes(".mp4")));
    ovl.innerHTML = `
      <div style="position:absolute;top:0;left:0;right:0;padding:14px 20px;display:flex;align-items:center;justify-content:space-between;color:#fff;z-index:10;background:linear-gradient(180deg,rgba(0,0,0,0.85),transparent)">
        <span class="mono b sm" style="opacity:0.9;direction:ltr">${curIdx + 1} / ${mediaList.length}</span>
        <div style="display:flex;gap:12px;align-items:center">
          <a href="${cur.src}" download="${cur.name || 'anime_black_media'}" class="iconbtn" style="background:rgba(255,255,255,0.18);color:#fff" title="تحميل">
            ${I("download","i s")}
          </a>
          <button class="iconbtn" onclick="closeImgViewer()" style="background:rgba(255,255,255,0.18);color:#fff" title="إغلاق">
            ${I("x","i s")}
          </button>
        </div>
      </div>

      <div style="flex:1;width:100%;display:flex;align-items:center;justify-content:center;padding:16px;box-sizing:border-box">
        ${isVid ? `
          <video src="${cur.src}" controls autoplay style="max-width:100%;max-height:85vh;border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,0.8)"></video>
        ` : `
          <img src="${cur.src}" style="max-width:100%;max-height:85vh;object-fit:contain;border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,0.8);transition:transform 0.2s" id="iv_main_img" alt="">
        `}
      </div>

      ${mediaList.length > 1 ? `
        <button style="position:absolute;right:14px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.5);color:#fff;border:1px solid rgba(255,255,255,0.25);border-radius:50%;width:48px;height:48px;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:10;backdrop-filter:blur(6px)" onclick="window._ivPrev()" aria-label="السابق">
          ${I("chevron-right","l")}
        </button>
        <button style="position:absolute;left:14px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,0.5);color:#fff;border:1px solid rgba(255,255,255,0.25);border-radius:50%;width:48px;height:48px;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:10;backdrop-filter:blur(6px)" onclick="window._ivNext()" aria-label="التالي">
          ${I("chevron-left","l")}
        </button>
      ` : ''}
    `;
  }

  window._ivNext = () => {
    if (curIdx < mediaList.length - 1) {
      curIdx++;
      renderViewer();
    }
  };
  window._ivPrev = () => {
    if (curIdx > 0) {
      curIdx--;
      renderViewer();
    }
  };

  renderViewer();
};

// ============================================================================
// 6. REAL GIF INTEGRATION (Curated Real Anime Characters GIFs & Tenor Search)
// ============================================================================
const CURATED_ANIME_GIFS = {
  real_anime: [
    { title: "غوجو ساتورو - العين المضيئة", url: "https://media.tenor.com/3e459b7201c107bf457d7dd59c049d5a/tenor.gif" },
    { title: "غوجو ساتورو - توسيع المجال", url: "https://media.giphy.com/media/UgV8Y7bDoxzdg40PMU/giphy.gif" },
    { title: "لوفي - جير 5 الأسطوري", url: "https://media.giphy.com/media/WmkqburJqXziM/giphy.gif" },
    { title: "زورو - قاطع السيوف والهاكي", url: "https://media.giphy.com/media/4OV1bHavuPPtm/giphy.gif" },
    { title: "ناروتو أوزوماكي - نمط الناسك", url: "https://media.giphy.com/media/JRlqKEzTDKci5JPcaL/giphy.gif" },
    { title: "ساسكي أوتشيها - الشارينغان والتشيدوري", url: "https://media.giphy.com/media/11TzKk84rRjXlm/giphy.gif" },
    { title: "إيتاشي أوتشيها - الغراب والمانغيكيو", url: "https://media.giphy.com/media/CchzkJJ6UrQmQ/giphy.gif" },
    { title: "ليفاي أكرمان - قتال العمالقة", url: "https://media.giphy.com/media/3o7btQ8jDTPGDpgc6I/giphy.gif" },
    { title: "إيرين ييغر - تاتاكاي المهاجم", url: "https://media.giphy.com/media/kgo9KtvX2dCVudr645/giphy.gif" },
    { title: "سوكونا - ملك اللعنات والضريح", url: "https://media.giphy.com/media/4lu5FuhtrbaOQgKN57/giphy.gif" },
    { title: "كيلوا زولديك - سرعة البرق", url: "https://media.giphy.com/media/8DTnuPhxv0m4w/giphy.gif" },
    { title: "غوكو - الغريزة الفائقة", url: "https://media.giphy.com/media/97HzebmSgpaHC/giphy.gif" },
    { title: "سايتاما - الرجل ذو اللكمة الواحدة", url: "https://media.giphy.com/media/yo3TC0yeHd53G/giphy.gif" },
    { title: "تانجيرو كامادو - رقصة إله النار", url: "https://media.giphy.com/media/jh7F73wOtnKliQXbRT/giphy.gif" },
    { title: "سونغ جين ووا - أرايز ملك الظلال", url: "https://media.tenor.com/154df6bb51e04a57f12e8b6ee3aa2d86/tenor.gif" },
    { title: "مادارا أوتشيها - أسطورة الشينوبي", url: "https://media.giphy.com/media/b7Uq708fc78M8/giphy.gif" }
  ],
  reactions: [
    { title: "حماس أوتاكو", url: "https://media.giphy.com/media/4N5vB4aErlVtVsywBw/giphy.gif" },
    { title: "ضحك هستيري", url: "https://media.giphy.com/media/mguPrVJyR853C0cG5W/giphy.gif" },
    { title: "صدمة وذهول", url: "https://media.giphy.com/media/xT9IgG50Fb7Mi0prBC/giphy.gif" },
    { title: "كاواي كيوت", url: "https://media.giphy.com/media/13CoXDiaCcCoyk/giphy.gif" },
    { title: "حزن ودموع", url: "https://media.giphy.com/media/3o7TKMt1VVNkHV2PaE/giphy.gif" },
    { title: "غضب ونيران", url: "https://media.giphy.com/media/l41lFw057lAJQMwg0/giphy.gif" },
    { title: "إعجاب وحب", url: "https://media.giphy.com/media/3o6Zt481isNVuQI1l6/giphy.gif" },
    { title: "رقص واحتفال", url: "https://media.giphy.com/media/26AHONQ79FdWZhAI0/giphy.gif" },
    { title: "ثقة وفخر", url: "https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif" },
    { title: "أكل وشراهة", url: "https://media.giphy.com/media/11zTEl7fbxPTK8/giphy.gif" }
  ],
  onepiece: [
    { title: "لوفي جير 5", url: "https://media.giphy.com/media/WmkqburJqXziM/giphy.gif" },
    { title: "لوفي يضحك", url: "https://media.giphy.com/media/9wPdkThJtbAwo/giphy.gif" },
    { title: "زورو قاطع السيوف", url: "https://media.giphy.com/media/4OV1bHavuPPtm/giphy.gif" },
    { title: "زورو تائه", url: "https://media.giphy.com/media/9az09tlYyYNfq/giphy.gif" },
    { title: "سانجي ديابل جامب", url: "https://media.giphy.com/media/DMvXFFMFH252w/giphy.gif" },
    { title: "شانكس الهاكي", url: "https://media.giphy.com/media/blas9RgQBAl1K/giphy.gif" },
    { title: "تشوبر خجول", url: "https://media.giphy.com/media/13Uqp5IGFpmDle/giphy.gif" }
  ],
  naruto: [
    { title: "ناروتو راسينجان", url: "https://media.giphy.com/media/Do5GRTYRIhSFy/giphy.gif" },
    { title: "ناروتو بطور الناسك", url: "https://media.giphy.com/media/JRlqKEzTDKci5JPcaL/giphy.gif" },
    { title: "ساسكي تشيدوري", url: "https://media.giphy.com/media/11TzKk84rRjXlm/giphy.gif" },
    { title: "إيتاشي الشارينغان", url: "https://media.giphy.com/media/CchzkJJ6UrQmQ/giphy.gif" },
    { title: "مادارا أوتشيها", url: "https://media.giphy.com/media/b7Uq708fc78M8/giphy.gif" },
    { title: "كاكاشي شيدوري", url: "https://media.giphy.com/media/kHYWTCigdEKK4/giphy.gif" },
    { title: "بين شينرا تينسي", url: "https://media.giphy.com/media/Tz9DN5ftHBeQ8/giphy.gif" }
  ],
  jujutsu: [
    { title: "غوجو توسيع المجال", url: "https://media.giphy.com/media/UgV8Y7bDoxzdg40PMU/giphy.gif" },
    { title: "غوجو البنفسجي الأجوف", url: "https://media.giphy.com/media/DGsDLr9nyz2LkVgKFs/giphy.gif" },
    { title: "سوكونا الضريح الخبيث", url: "https://media.giphy.com/media/4lu5FuhtrbaOQgKN57/giphy.gif" },
    { title: "يوجي الضربة السوداء", url: "https://media.giphy.com/media/fGGV7FeScq2s/giphy.gif" },
    { title: "ميغومي الظلال العشرة", url: "https://media.giphy.com/media/vnoZnuh4Vsosa9Bsnp/giphy.gif" }
  ],
  aot: [
    { title: "ليفاي أكرمان هجوم", url: "https://media.giphy.com/media/3o7btQ8jDTPGDpgc6I/giphy.gif" },
    { title: "إيرين تاتاكاي", url: "https://media.giphy.com/media/kgo9KtvX2dCVudr645/giphy.gif" },
    { title: "إيرين العملاق المهاجم", url: "https://media.giphy.com/media/tliTHRY616x7u/giphy.gif" },
    { title: "ميكاسا الحماية", url: "https://media.giphy.com/media/12m3hw90ermjy6/giphy.gif" }
  ],
  demonslayer: [
    { title: "تانجيرو تنفس الماء", url: "https://media.giphy.com/media/dyjrpqaUVqCELGuQVr/giphy.gif" },
    { title: "تانجيرو رقصة إله النار", url: "https://media.giphy.com/media/jh7F73wOtnKliQXbRT/giphy.gif" },
    { title: "نيزوكو تركض", url: "https://media.giphy.com/media/W3a0zO282s57jEg5I5/giphy.gif" },
    { title: "رينغوكو أشعل قلبك", url: "https://media.giphy.com/media/2ya7xLyEytO4uK0pnW/giphy.gif" },
    { title: "زينيتسو تنفس الرعد", url: "https://media.giphy.com/media/fTN0SCqoTH5AOYZ29W/giphy.gif" }
  ],
  anya_cute: [
    { title: "آنيا ابتسامة هيه", url: "https://media.giphy.com/media/FWAcpJsFT9mVRv0e7a/giphy.gif" },
    { title: "آنيا واكو واكو", url: "https://media.giphy.com/media/zZC2AqB84z7xe/giphy.gif" },
    { title: "آنيا تبكي صدمة", url: "https://media.giphy.com/media/NuiEoMDmstN0J2VMSo/giphy.gif" },
    { title: "قطة أنمي كاوائي", url: "https://media.giphy.com/media/uw0KqTWZSm8gg/giphy.gif" }
  ],
  dbz_hunter: [
    { title: "غوكو الغريزة الفائقة", url: "https://media.giphy.com/media/97HzebmSgpaHC/giphy.gif" },
    { title: "فيجيتا كبرياء السايان", url: "https://media.giphy.com/media/thZQWK50oFOCY/giphy.gif" },
    { title: "كيلوا سرعة البرق", url: "https://media.giphy.com/media/8DTnuPhxv0m4w/giphy.gif" },
    { title: "غون الحجر ورقة مقص", url: "https://media.giphy.com/media/Y4gtaaRlLXjLg6MUEg/giphy.gif" },
    { title: "سايتاما لكمة جادة", url: "https://media.giphy.com/media/yo3TC0yeHd53G/giphy.gif" }
  ]
};

window.GIF_ACTIVE_CATEGORY = "real_anime";
window.GIF_SEARCH_QUERY = "";

const ANIME_GIF_CATEGORIES = [
  ["real_anime", "🌟 شخصيات حقيقية"],
  ["reactions", "⚡ ردود حية"],
  ["jujutsu", "🤞 جوجوتسو كايسن"],
  ["onepiece", "🏴‍☠️ ون بيس"],
  ["naruto", "🍥 ناروتو"],
  ["aot", "⚔️ هجوم العمالقة"],
  ["demonslayer", "🗡️ قاتل الشياطين"],
  ["anya_cute", "🌸 كاوائي وآنيا"],
  ["dbz_hunter", "🔥 سايان وهنتر"]
];

SHEETS.gifSheet = (cid) => {
  return sheet(
    `GIFs الأنمي والتفاعلات`,
    `
    <div class="col" style="gap:10px">
      <div style="position:relative">
        <input type="text" id="gif_search_input" class="input" placeholder="ابحث في GIFs الأنمي وشخصياتك المفضلة..." value="${esc(window.GIF_SEARCH_QUERY)}" oninput="searchGifsLive(this.value, '${cid}')" style="padding-inline-end:36px">
        <span style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--muted);pointer-events:none">${I("search","i s")}</span>
      </div>

      <div style="display:flex;gap:6px;overflow-x:auto;padding-bottom:4px" class="no-sb">
        ${ANIME_GIF_CATEGORIES.map(([catKey, catLabel]) => `
          <button class="btn btn-xs ${window.GIF_ACTIVE_CATEGORY === catKey ? 'btn-pri' : 'btn-sec'}" onclick="switchGifCategory('${catKey}', '${cid}')" style="white-space:nowrap;border-radius:99px">
            ${catLabel}
          </button>
        `).join('')}
      </div>

      <div id="gif_results" style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;max-height:340px;overflow-y:auto;-webkit-overflow-scrolling:touch" class="no-sb">
        ${renderGifsGridHTML(cid)}
      </div>
    </div>
    `
  );
};

window.switchGifCategory = function(catKey, cid) {
  window.GIF_ACTIVE_CATEGORY = catKey;
  window.GIF_SEARCH_QUERY = "";
  const box = document.getElementById("gif_results");
  if (box) box.innerHTML = renderGifsGridHTML(cid);
};

window.searchGifsLive = async function(q, cid) {
  window.GIF_SEARCH_QUERY = q.trim();
  const box = document.getElementById("gif_results");
  if (!box) return;

  if (!window.GIF_SEARCH_QUERY) {
    box.innerHTML = renderGifsGridHTML(cid);
    return;
  }

  try {
    const res = await fetch(`https://g.tenor.com/v1/search?q=${encodeURIComponent(window.GIF_SEARCH_QUERY + " anime")}&key=LIVDSRZULELA&limit=16`);
    const data = await res.json();
    if (data && data.results && data.results.length) {
      const gifs = data.results.map(r => ({
        title: r.content_description || "GIF أنمي",
        url: (r.media && r.media[0] && r.media[0].gif && r.media[0].gif.url) || ""
      })).filter(g => g.url);

      box.innerHTML = gifs.map(g => `
        <div style="border-radius:12px;overflow:hidden;background:var(--surface3);cursor:pointer;position:relative;height:120px;border:1px solid var(--line2)" onclick="sendGif('${g.url}', '${cid}')">
          <img src="${g.url}" style="width:100%;height:100%;object-fit:cover;display:block" loading="lazy" alt="${esc(g.title)}">
          <div style="position:absolute;inset:auto 0 0 0;background:linear-gradient(transparent,rgba(0,0,0,0.85));padding:12px 6px 4px;display:flex;align-items:center;justify-content:space-between">
            <span class="tiny b" style="color:#fff;font-size:10px;text-shadow:0 1px 3px rgba(0,0,0,0.9);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(g.title)}</span>
            <span style="background:var(--accent);color:#fff;font-size:8px;padding:1px 5px;border-radius:4px;font-weight:900;flex-shrink:0">GIF</span>
          </div>
        </div>
      `).join('');
      return;
    }
  } catch (e) {
    console.warn("Live GIF search fallback", e);
  }

  box.innerHTML = renderGifsGridHTML(cid);
};

function renderGifsGridHTML(cid) {
  const list = CURATED_ANIME_GIFS[window.GIF_ACTIVE_CATEGORY] || CURATED_ANIME_GIFS.real_anime;
  return list.map(g => `
    <div style="border-radius:12px;overflow:hidden;background:var(--surface3);cursor:pointer;position:relative;height:120px;border:1px solid var(--line2);transition:transform 0.18s" onclick="sendGif('${g.url}', '${cid}')">
      <img src="${g.url}" style="width:100%;height:100%;object-fit:cover;display:block" loading="lazy" alt="${esc(g.title||'')}">
      <div style="position:absolute;inset:auto 0 0 0;background:linear-gradient(transparent,rgba(0,0,0,0.85));padding:12px 6px 4px;display:flex;align-items:center;justify-content:space-between">
        <span class="tiny b" style="color:#fff;font-size:10px;text-shadow:0 1px 3px rgba(0,0,0,0.9);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(g.title||'GIF أنمي')}</span>
        <span style="background:var(--accent);color:#fff;font-size:8px;padding:1px 5px;border-radius:4px;font-weight:900;flex-shrink:0">GIF</span>
      </div>
    </div>
  `).join('');
}

window.sendGif = function(url, cid) {
  closeOvl();
  const c = (S.chats || []).find(x => x.id === cid) || ((S.chats || []).find(x => x.id === S.activeChat));
  if (!c) return;

  const mid = uid();
  const myUid = getChatMyUid();
  const msg = {
    id: mid,
    clientMessageId: mid,
    conversationId: c.id,
    from: "me",
    senderId: myUid,
    senderName: S.me.name || "أنا",
    type: "gif",
    src: url,
    text: "GIF",
    attachments: [{ type: "gif", src: url }],
    at: now(),
    createdAt: now(),
    st: 1,
    pending: true
  };

  c.messages.push(msg);
  c.last = "👾 GIF";
  c.lastAt = now();
  save();
  snd("send");
  const msgBox = document.getElementById("msgs");
  if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), true);
  syncChatMessage(c.id, msg);
};

// ============================================================================
// 7. STICKERS SYSTEM (Packs, Favorites, Recents)
// ============================================================================

window.makeAnimeStickerSVG = function(id, text, color1, color2, icon, meme, charName, outlineStyle) {
  const strokeColor = outlineStyle === 'neon' ? '#00f0ff' : outlineStyle === 'gold' ? '#fbbf24' : '#ffffff';
  const strokeWidth = outlineStyle === 'none' ? 0 : 5;
  const shadowFilter = outlineStyle === 'neon' ? 'drop-shadow(0 0 8px rgba(0,240,255,0.8))' : 'drop-shadow(0 4px 10px rgba(0,0,0,0.45))';
  const cleanId = (id || 'stk').replace(/[^a-zA-Z0-9]/g, '');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160" width="160" height="160">
    <defs>
      <linearGradient id="grad_${cleanId}" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${color1}"/>
        <stop offset="100%" stop-color="${color2}"/>
      </linearGradient>
    </defs>
    <g style="filter: ${shadowFilter};">
      <rect x="8" y="8" width="144" height="144" rx="28" fill="#ffffff" stroke="${strokeColor}" stroke-width="${strokeWidth}"/>
      <rect x="13" y="13" width="134" height="134" rx="24" fill="url(#grad_${cleanId})"/>
      <circle cx="80" cy="64" r="35" fill="#ffffff" fill-opacity="0.22"/>
      <text x="80" y="77" font-size="42" text-anchor="middle" font-family="system-ui, -apple-system, sans-serif">${icon}</text>
      <rect x="18" y="112" width="124" height="26" rx="8" fill="#0f172a" fill-opacity="0.94"/>
      <text x="80" y="129" font-size="11.5" font-weight="900" fill="#ffffff" text-anchor="middle" font-family="system-ui, -apple-system, sans-serif">${meme}</text>
      <text x="80" y="30" font-size="10" font-weight="bold" fill="#ffffff" fill-opacity="0.95" text-anchor="middle" font-family="system-ui, -apple-system, sans-serif">${charName}</text>
    </g>
  </svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
};

const STICKER_PACKS = {
  legends: {
    name: "أساطير الأنمي",
    icon: "crown",
    items: [
      { id: "stk_luffy_g5", name: "لوفي جير 5", icon: "⚡", c1: "#F59E0B", c2: "#EF4444", meme: "نيكا! ههههه", char: "لوفي إله الشمس", img: makeAnimeStickerSVG("stk_luffy_g5","لوفي جير 5","#F59E0B","#EF4444","⚡","نيكا! ههههه","لوفي إله الشمس","gold") },
      { id: "stk_gojo_inf", name: "غوجو اللانهائي", icon: "👁️", c1: "#312E81", c2: "#818CF8", meme: "المجال اللانهائي!", char: "غوجو ساتورو", img: makeAnimeStickerSVG("stk_gojo_inf","غوجو اللانهائي","#312E81","#818CF8","👁️","المجال اللانهائي!","غوجو ساتورو","neon") },
      { id: "stk_levi_clean", name: "ليفاي تنظيف", icon: "⚔️", c1: "#1F2937", c2: "#6B7280", meme: "نظّف المكان فوراً!", char: "ليفاي أكرمان", img: makeAnimeStickerSVG("stk_levi_clean","ليفاي تنظيف","#1F2937","#6B7280","⚔️","نظّف المكان فوراً!","ليفاي أكرمان","white") },
      { id: "stk_naruto_rasen", name: "ناروتو داتيبايو", icon: "🍥", c1: "#EA580C", c2: "#FACC15", meme: "داتيبايو!", char: "ناروتو أوزوماكي", img: makeAnimeStickerSVG("stk_naruto_rasen","ناروتو داتيبايو","#EA580C","#FACC15","🍥","داتيبايو!","ناروتو أوزوماكي","gold") },
      { id: "stk_eren_tatakae", name: "إرين تاتاكاي", icon: "🔥", c1: "#7F1D1D", c2: "#B91C1C", meme: "تاتاكاي! قاتل", char: "إرين ييغر", img: makeAnimeStickerSVG("stk_eren_tatakae","إرين تاتاكاي","#7F1D1D","#B91C1C","🔥","تاتاكاي! قاتل","إرين ييغر","neon") },
      { id: "stk_jinwoo_arise", name: "جين وو أرايز", icon: "👑", c1: "#1E1B4B", c2: "#4F46E5", meme: "أرايز! (نهوض)", char: "سيد الظلال", img: makeAnimeStickerSVG("stk_jinwoo_arise","جين وو أرايز","#1E1B4B","#4F46E5","👑","أرايز! (نهوض)","سيد الظلال","neon") },
      { id: "stk_zoro_ashura", name: "زورو عاشوراء", icon: "🗡️", c1: "#14532D", c2: "#22C55E", meme: "عاشوراء ضائع!", char: "رورونوا زورو", img: makeAnimeStickerSVG("stk_zoro_ashura","زورو عاشوراء","#14532D","#22C55E","🗡️","عاشوراء ضائع!","رورونوا زورو","white") },
      { id: "stk_itachi_tsuk", name: "إيتاتشي تسوكيومي", icon: "🌙", c1: "#450A0A", c2: "#DC2626", meme: "تسوكيومي الخالد!", char: "إيتاتشي أوتشيها", img: makeAnimeStickerSVG("stk_itachi_tsuk","إيتاتشي تسوكيومي","#450A0A","#DC2626","🌙","تسوكيومي الخالد!","إيتاتشي أوتشيها","neon") },
      { id: "stk_tanjiro_sun", name: "تانجيرو شمس", icon: "☀️", c1: "#134E4A", c2: "#14B8A6", meme: "تنفس الشمس!", char: "تانجيرو كامادو", img: makeAnimeStickerSVG("stk_tanjiro_sun","تانجيرو شمس","#134E4A","#14B8A6","☀️","تنفس الشمس!","تانجيرو كامادو","gold") },
      { id: "stk_rengoku_umai", name: "رينغوكو أوماي", icon: "🍱", c1: "#7C2D12", c2: "#F59E0B", meme: "أوماي! حارق!", char: "كوجورو رينغوكو", img: makeAnimeStickerSVG("stk_rengoku_umai","رينغوكو أوماي","#7C2D12","#F59E0B","🍱","أوماي! حارق!","كوجورو رينغوكو","gold") },
      { id: "stk_ichigo_bankai", name: "إيتشيغو بانكاي", icon: "⚡", c1: "#C2410C", c2: "#EA580C", meme: "بانكاي!", char: "إيتشيغو كوروساكي", img: makeAnimeStickerSVG("stk_ichigo_bankai","إيتشيغو بانكاي","#C2410C","#EA580C","⚡","بانكاي!","إيتشيغو كوروساكي","white") },
      { id: "stk_saitama_ok", name: "سايتاما أوكي", icon: "😐", c1: "#78350F", c2: "#F59E0B", meme: "أوكي~ (OK)", char: "سايتاما", img: makeAnimeStickerSVG("stk_saitama_ok","سايتاما أوكي","#78350F","#F59E0B","😐","أوكي~ (OK)","سايتاما","white") }
    ]
  },
  reactions: {
    name: "ردود أفعال وميمز",
    icon: "sparkles",
    items: [
      { id: "stk_anya_heh", name: "آنيا ههه", icon: "😏", c1: "#065F46", c2: "#F472B6", meme: "ههه... سخرية", char: "آنيا فورجر", img: makeAnimeStickerSVG("stk_anya_heh","آنيا ههه","#065F46","#F472B6","😏","ههه... سخرية","آنيا فورجر","white") },
      { id: "stk_anya_waku", name: "آنيا واكو واكو", icon: "🥜", c1: "#BE185D", c2: "#FBCFE8", meme: "واكو واكو!!", char: "آنيا فورجر", img: makeAnimeStickerSVG("stk_anya_waku","آنيا واكو واكو","#BE185D","#FBCFE8","🥜","واكو واكو!!","آنيا فورجر","gold") },
      { id: "stk_tanjiro_gross", name: "تانجيرو مشمئز", icon: "🤢", c1: "#064E3B", c2: "#34D399", meme: "اشمئزاز تام!", char: "تانجيرو كامادو", img: makeAnimeStickerSVG("stk_tanjiro_gross","تانجيرو مشمئز","#064E3B","#34D399","🤢","اشمئزاز تام!","تانجيرو كامادو","white") },
      { id: "stk_zenitsu_cry", name: "زينيتسو صراخ", icon: "😱", c1: "#A16207", c2: "#FACC15", meme: "مستحيييل!", char: "زينيتسو", img: makeAnimeStickerSVG("stk_zenitsu_cry","زينيتسو صراخ","#A16207","#FACC15","😱","مستحيييل!","زينيتسو","white") },
      { id: "stk_sukuna_laugh", name: "سوكونا غامباري", icon: "😈", c1: "#450A0A", c2: "#DC2626", meme: "غامباري غامباري", char: "ريو مين سوكونا", img: makeAnimeStickerSVG("stk_sukuna_laugh","سوكونا غامباري","#450A0A","#DC2626","😈","غامباري غامباري","ريو مين سوكونا","neon") },
      { id: "stk_luffy_shock", name: "لوفي مصدوم", icon: "👀", c1: "#DC2626", c2: "#FBBF24", meme: "عيون طالعة!", char: "مونكي دي لوفي", img: makeAnimeStickerSVG("stk_luffy_shock","لوفي مصدوم","#DC2626","#FBBF24","👀","عيون طالعة!","مونكي دي لوفي","white") },
      { id: "stk_zoro_lost", name: "زورو ضائع", icon: "🧭", c1: "#14532D", c2: "#86EFAC", meme: "أين أنا؟! بوصلة", char: "رورونوا زورو", img: makeAnimeStickerSVG("stk_zoro_lost","زورو ضائع","#14532D","#86EFAC","🧭","أين أنا؟! بوصلة","رورونوا زورو","white") },
      { id: "stk_dio_kono", name: "ديو كونو ديو دا", icon: "🧛", c1: "#854D0E", c2: "#FBBF24", meme: "كونو ديو دا!", char: "ديو براندو", img: makeAnimeStickerSVG("stk_dio_kono","ديو كونو ديو دا","#854D0E","#FBBF24","🧛","كونو ديو دا!","ديو براندو","gold") },
      { id: "stk_denji_toast", name: "دنجي توست", icon: "🍞", c1: "#7F1D1D", c2: "#EF4444", meme: "أريد توست ومربى", char: "دنجي", img: makeAnimeStickerSVG("stk_denji_toast","دنجي توست","#7F1D1D","#EF4444","🍞","أريد توست ومربى","دنجي","white") },
      { id: "stk_killua_cat", name: "كيلوا قطة", icon: "😼", c1: "#0284C7", c2: "#93C5FD", meme: "وجه القطة الساخر", char: "كيلوا زولديك", img: makeAnimeStickerSVG("stk_killua_cat","كيلوا قطة","#0284C7","#93C5FD","😼","وجه القطة الساخر","كيلوا زولديك","white") },
      { id: "stk_guts_pain", name: "غاتس ألم الثيم", icon: "🗡️", c1: "#1C1917", c2: "#78716C", meme: "ألم وصمت...", char: "غاتس", img: makeAnimeStickerSVG("stk_guts_pain","غاتس ألم الثيم","#1C1917","#78716C","🗡️","ألم وصمت...","غاتس","white") },
      { id: "stk_toji_money", name: "توجي المال أولاً", icon: "💰", c1: "#1E293B", c2: "#64748B", meme: "ادفع لي أولاً", char: "توجي فوشيغورو", img: makeAnimeStickerSVG("stk_toji_money","توجي المال أولاً","#1E293B","#64748B","💰","ادفع لي أولاً","توجي فوشيغورو","white") }
    ]
  },
  chibi: {
    name: "تشيبي وكوايي",
    icon: "heart",
    items: [
      { id: "stk_nezuko_box", name: "نيزوكو تلوح", icon: "🌸", c1: "#9D174D", c2: "#F472B6", meme: "لطف الشياطين", char: "نيزوكو كامادو", img: makeAnimeStickerSVG("stk_nezuko_box","نيزوكو تلوح","#9D174D","#F472B6","🌸","لطف الشياطين","نيزوكو كامادو","white") },
      { id: "stk_luffy_meat", name: "لوفي لحم", icon: "🍖", c1: "#B45309", c2: "#FBBF24", meme: "لحم لذيذ!", char: "لوفي تشيبي", img: makeAnimeStickerSVG("stk_luffy_meat","لوفي لحم","#B45309","#FBBF24","🍖","لحم لذيذ!","لوفي تشيبي","gold") },
      { id: "stk_gojo_sweet", name: "غوجو حلوى", icon: "🍡", c1: "#312E81", c2: "#C7D2FE", meme: "حلوى وغمزة", char: "غوجو تشيبي", img: makeAnimeStickerSVG("stk_gojo_sweet","غوجو حلوى","#312E81","#C7D2FE","🍡","حلوى وغمزة","غوجو تشيبي","neon") },
      { id: "stk_chopper_hide", name: "شوبر خجول", icon: "🦌", c1: "#0369A1", c2: "#BAE6FD", meme: "خجل معكوس!", char: "توني شوبر", img: makeAnimeStickerSVG("stk_chopper_hide","شوبر خجول","#0369A1","#BAE6FD","🦌","خجل معكوس!","توني شوبر","white") },
      { id: "stk_frieren_book", name: "فريـرن كتاب", icon: "📖", c1: "#064E3B", c2: "#A7F3D0", meme: "سحر الزهور", char: "فريـرن تشيبي", img: makeAnimeStickerSVG("stk_frieren_book","فريـرن كتاب","#064E3B","#A7F3D0","📖","سحر الزهور","فريـرن تشيبي","white") },
      { id: "stk_bond_dog", name: "بوند الكلب", icon: "🐶", c1: "#334155", c2: "#E2E8F0", meme: "بوف! فكاهي", char: "بوند فورجر", img: makeAnimeStickerSVG("stk_bond_dog","بوند الكلب","#334155","#E2E8F0","🐶","بوف! فكاهي","بوند فورجر","white") },
      { id: "stk_killua_choco", name: "كيلوا شوكولاتة", icon: "🍫", c1: "#0284C7", c2: "#BAE6FD", meme: "روبوت شوكو!", char: "كيلوا تشيبي", img: makeAnimeStickerSVG("stk_killua_choco","كيلوا شوكولاتة","#0284C7","#BAE6FD","🍫","روبوت شوكو!","كيلوا تشيبي","white") },
      { id: "stk_itadori_dance", name: "إيتادوري رقص", icon: "🕺", c1: "#C2410C", c2: "#FED7AA", meme: "رقصة البهجة", char: "إيتادوري تشيبي", img: makeAnimeStickerSVG("stk_itadori_dance","إيتادوري رقص","#C2410C","#FED7AA","🕺","رقصة البهجة","إيتادوري تشيبي","gold") }
    ]
  },
  badges: {
    name: "أختام وعبارات أوتاكو",
    icon: "award",
    items: [
      { id: "stk_badge_tatakae", name: "تاتاكاي!", icon: "⚔️", c1: "#7F1D1D", c2: "#B91C1C", meme: "TATAKAE!", char: "شعار الأوتاكو", img: makeAnimeStickerSVG("stk_badge_tatakae","تاتاكاي!","#7F1D1D","#B91C1C","⚔️","TATAKAE!","شعار الأوتاكو","neon") },
      { id: "stk_badge_shinzou", name: "شينزو ساساغيو!", icon: "✊", c1: "#1E293B", c2: "#475569", meme: "SHINZOU!", char: "فيلق الاستطلاع", img: makeAnimeStickerSVG("stk_badge_shinzou","شينزو ساساغيو!","#1E293B","#475569","✊","SHINZOU!","فيلق الاستطلاع","white") },
      { id: "stk_badge_dattebayo", name: "داتيبايو!", icon: "🍥", c1: "#EA580C", c2: "#FACC15", meme: "DATTEBAYO!", char: "طريق النينجا", img: makeAnimeStickerSVG("stk_badge_dattebayo","داتيبايو!","#EA580C","#FACC15","🍥","DATTEBAYO!","طريق النينجا","gold") },
      { id: "stk_badge_bankai", name: "بانكاي!", icon: "⚡", c1: "#450A0A", c2: "#DC2626", meme: "BANKAI!", char: "تحرير السيف", img: makeAnimeStickerSVG("stk_badge_bankai","بانكاي!","#450A0A","#DC2626","⚡","BANKAI!","تحرير السيف","neon") },
      { id: "stk_badge_arise", name: "أرايز!", icon: "👑", c1: "#1E1B4B", c2: "#4F46E5", meme: "ARISE!", char: "سيد الظلال", img: makeAnimeStickerSVG("stk_badge_arise","أرايز!","#1E1B4B","#4F46E5","👑","ARISE!","سيد الظلال","neon") },
      { id: "stk_badge_araara", name: "أرا أرا~", icon: "💜", c1: "#581C87", c2: "#C084FC", meme: "ARA ARA~", char: "أنمي كلاسيك", img: makeAnimeStickerSVG("stk_badge_araara","أرا أرا~","#581C87","#C084FC","💜","ARA ARA~","أنمي كلاسيك","white") },
      { id: "stk_badge_yamero", name: "ياميرو!", icon: "🛑", c1: "#991B1B", c2: "#EF4444", meme: "YAMERO!", char: "توقف فوراً", img: makeAnimeStickerSVG("stk_badge_yamero","ياميرو!","#991B1B","#EF4444","🛑","YAMERO!","توقف فوراً","white") },
      { id: "stk_badge_souka", name: "سوكا...", icon: "💭", c1: "#334155", c2: "#94A3B8", meme: "SOUKA...", char: "فهمت الأمر", img: makeAnimeStickerSVG("stk_badge_souka","سوكا...","#334155","#94A3B8","💭","SOUKA...","فهمت الأمر","white") },
      { id: "stk_badge_nani", name: "ناندا كوري؟! (NANI)", icon: "❓", c1: "#C2410C", c2: "#F59E0B", meme: "NANI?!", char: "صدمة أوتاكو", img: makeAnimeStickerSVG("stk_badge_nani","ناندا كوري؟!","#C2410C","#F59E0B","❓","NANI?!","صدمة أوتاكو","gold") },
      { id: "stk_badge_umai", name: "أوماي!", icon: "🔥", c1: "#7C2D12", c2: "#F59E0B", meme: "UMAI!!", char: "شعلة القلب", img: makeAnimeStickerSVG("stk_badge_umai","أوماي!","#7C2D12","#F59E0B","🔥","UMAI!!","شعلة القلب","gold") }
    ]
  }
};


window.ACTIVE_STICKER_PACK = "otaku";

SHEETS.emojiSheet = (cid) => {
  window.ACTIVE_STICKER_PACK = window.ACTIVE_STICKER_PACK || "legends";
  window.ACTIVE_EMOJI_TAB = window.ACTIVE_EMOJI_TAB || "stk";
  const activeCid = cid || (typeof S !== "undefined" && S.activeChat) || (typeof S !== "undefined" && S.params && S.params.id) || "";

  return sheet(
    `
    <div class="row" style="justify-content:space-between;align-items:center;border-bottom:1px solid var(--line);padding-bottom:8px;gap:8px">
      <div class="row" style="gap:10px;overflow-x:auto" class="no-sb">
        <button id="tab_btn_stk" class="b xs" style="background:none;border:none;color:${window.ACTIVE_EMOJI_TAB==='stk'?'var(--accent)':'var(--muted)'};border-bottom:${window.ACTIVE_EMOJI_TAB==='stk'?'2px solid var(--accent)':'none'};padding-bottom:6px;cursor:pointer;white-space:nowrap" onclick="switchEmojiTab('stk', '${activeCid}')">
          🌟 ملصقات
        </button>
        <button id="tab_btn_my_stk" class="b xs" style="background:none;border:none;color:${window.ACTIVE_EMOJI_TAB==='my_stk'?'var(--accent)':'var(--muted)'};border-bottom:${window.ACTIVE_EMOJI_TAB==='my_stk'?'2px solid var(--accent)':'none'};padding-bottom:6px;cursor:pointer;white-space:nowrap" onclick="switchEmojiTab('my_stk', '${activeCid}')">
          🎨 ملصقاتي (<span id="my_stk_cnt">${(S.myCustomStickers||[]).length}</span>)
        </button>
        <button id="tab_btn_gif" class="b xs" style="background:none;border:none;color:${window.ACTIVE_EMOJI_TAB==='gif'?'var(--accent)':'var(--muted)'};border-bottom:${window.ACTIVE_EMOJI_TAB==='gif'?'2px solid var(--accent)':'none'};padding-bottom:6px;cursor:pointer;white-space:nowrap" onclick="switchEmojiTab('gif', '${activeCid}')">
          🎬 GIF
        </button>
        <button id="tab_btn_emj" class="b xs" style="background:none;border:none;color:${window.ACTIVE_EMOJI_TAB==='emj'?'var(--accent)':'var(--muted)'};border-bottom:${window.ACTIVE_EMOJI_TAB==='emj'?'2px solid var(--accent)':'none'};padding-bottom:6px;cursor:pointer;white-space:nowrap" onclick="switchEmojiTab('emj', '${activeCid}')">
          😀 إيموجي
        </button>
      </div>
      <button class="btn btn-purple btn-xs" style="border-radius:99px;font-weight:bold;white-space:nowrap;flex-shrink:0" onclick="openStickerMaker()">
        ${I('wand','i s')} صانع الملصقات
      </button>
    </div>
    `,
    `
    <div id="stk_tab_content" style="display:${window.ACTIVE_EMOJI_TAB==='stk'?'block':'none'}">
      <div class="row no-sb" style="gap:8px;margin-bottom:12px;border-bottom:1px solid var(--line);padding-bottom:8px;overflow-x:auto">
        ${Object.entries(STICKER_PACKS).map(([pkKey, pk]) => `
          <button class="btn btn-xs ${window.ACTIVE_STICKER_PACK === pkKey ? 'btn-pri' : 'btn-sec'}" onclick="switchStickerPack('${pkKey}')" style="border-radius:99px;white-space:nowrap">
            ${I(pk.icon||'sparkles','i s')} ${pk.name} (${(pk.items||[]).length})
          </button>
        `).join('')}
      </div>

      <div id="stk_pack_items" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;padding:6px 0;max-height:300px;overflow-y:auto" class="no-sb">
        ${renderStickerPackItemsHTML(window.ACTIVE_STICKER_PACK)}
      </div>
    </div>

    <div id="my_stk_tab_content" style="display:${window.ACTIVE_EMOJI_TAB==='my_stk'?'block':'none'}">
      <div id="my_stk_items" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;padding:6px 0;max-height:300px;overflow-y:auto" class="no-sb">
        ${renderMyStickersHTML()}
      </div>
    </div>

    <div id="gif_tab_content" style="display:${window.ACTIVE_EMOJI_TAB==='gif'?'block':'none'}">
      <div class="col" style="gap:10px">
        <div style="position:relative">
          <input type="text" id="gif_search_input" class="input" placeholder="ابحث في GIFs الأنمي..." value="${esc(window.GIF_SEARCH_QUERY||'')}" oninput="searchGifsLive(this.value, '${activeCid}')" style="padding-inline-end:36px">
          <span style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--muted);pointer-events:none">${I("search","i s")}</span>
        </div>

        <div style="display:flex;gap:6px;overflow-x:auto;padding-bottom:4px" class="no-sb">
          ${ANIME_GIF_CATEGORIES.map(([catKey, catLabel]) => `
            <button class="btn btn-xs ${window.GIF_ACTIVE_CATEGORY === catKey ? 'btn-pri' : 'btn-sec'}" onclick="switchGifCategory('${catKey}', '${activeCid}')" style="white-space:nowrap;border-radius:99px">
              ${catLabel}
            </button>
          `).join('')}
        </div>

        <div id="gif_results" style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;max-height:280px;overflow-y:auto;-webkit-overflow-scrolling:touch" class="no-sb">
          ${renderGifsGridHTML(activeCid)}
        </div>
      </div>
    </div>

    <div id="emj_tab_content" style="display:${window.ACTIVE_EMOJI_TAB==='emj'?'block':'none'}">
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:10px;font-size:26px;padding:12px 0;max-height:280px;overflow-y:auto" class="no-sb">
        ${["😀","😂","🥰","😍","😎","🤔","😭","😡","👍","🙏","🔥","❤️","💔","✨","🎉","💀","👀","💯","✔️","❌","⚔️","👑","💥","⚡","🌸","🍙","🍜","🎮","🍵","🎯","🛡️","💎","🏆","🚀","👻","😈","🤡","🦾","🥷","🔮","🌟","🔥"].map(e => `
          <button style="background:none;border:none;cursor:pointer;line-height:1;padding:8px 4px;border-radius:10px" onclick="insertEmoji('${e}')" class="btn-ghost">
            ${e}
          </button>
        `).join('')}
      </div>
    </div>
    `
  );
};

window.switchEmojiTab = function(tab, cid) {
  window.ACTIVE_EMOJI_TAB = tab;
  const emjTab = document.getElementById("emj_tab_content");
  const stkTab = document.getElementById("stk_tab_content");
  const myStkTab = document.getElementById("my_stk_tab_content");
  const gifTab = document.getElementById("gif_tab_content");

  const btnEmj = document.getElementById("tab_btn_emj");
  const btnStk = document.getElementById("tab_btn_stk");
  const btnMyStk = document.getElementById("tab_btn_my_stk");
  const btnGif = document.getElementById("tab_btn_gif");

  if (emjTab) emjTab.style.display = tab === 'emj' ? 'block' : 'none';
  if (stkTab) stkTab.style.display = tab === 'stk' ? 'block' : 'none';
  if (myStkTab) myStkTab.style.display = tab === 'my_stk' ? 'block' : 'none';
  if (gifTab) gifTab.style.display = tab === 'gif' ? 'block' : 'none';

  if (btnEmj) { btnEmj.style.color = tab === 'emj' ? 'var(--accent)' : 'var(--muted)'; btnEmj.style.borderBottom = tab === 'emj' ? '2px solid var(--accent)' : 'none'; }
  if (btnStk) { btnStk.style.color = tab === 'stk' ? 'var(--accent)' : 'var(--muted)'; btnStk.style.borderBottom = tab === 'stk' ? '2px solid var(--accent)' : 'none'; }
  if (btnMyStk) { btnMyStk.style.color = tab === 'my_stk' ? 'var(--accent)' : 'var(--muted)'; btnMyStk.style.borderBottom = tab === 'my_stk' ? '2px solid var(--accent)' : 'none'; }
  if (btnGif) { btnGif.style.color = tab === 'gif' ? 'var(--accent)' : 'var(--muted)'; btnGif.style.borderBottom = tab === 'gif' ? '2px solid var(--accent)' : 'none'; }

  if (tab === 'my_stk') {
    const myItems = document.getElementById("my_stk_items");
    if (myItems) myItems.innerHTML = renderMyStickersHTML();
  } else if (tab === 'gif') {
    const activeCid = cid || (typeof S !== "undefined" && S.activeChat) || (typeof S !== "undefined" && S.params && S.params.id) || "";
    const box = document.getElementById("gif_results");
    if (box) box.innerHTML = renderGifsGridHTML(activeCid);
  }
};
SHEETS.stickerGifSheet = SHEETS.emojiSheet;


window.switchStickerPack = function(pkKey) {
  window.ACTIVE_STICKER_PACK = pkKey;
  const items = document.getElementById("stk_pack_items");
  if (items) items.innerHTML = renderStickerPackItemsHTML(pkKey);
  const btns = document.querySelectorAll("#stk_tab_content .btn-xs");
  btns.forEach(b => {
    if (b.innerText.includes((STICKER_PACKS[pkKey]||{}).name)) {
      b.className = "btn btn-xs btn-pri";
    } else {
      b.className = "btn btn-xs btn-sec";
    }
  });
};

function renderStickerPackItemsHTML(pkKey) {
  const pack = STICKER_PACKS[pkKey] || STICKER_PACKS.legends || STICKER_PACKS.reactions;
  if (!pack) return '';
  const list = pack.items || pack.stickers || [];
  return list.map(s => `
    <button class="col center anime-stk-item" style="background:var(--surface2);border:1px solid var(--line2);border-radius:16px;padding:8px 6px;gap:6px;cursor:pointer;position:relative;transition:all .18s;overflow:hidden" onclick="sendSticker('${s.icon}', '${esc(s.name)}', '${s.img || ''}')" onmouseenter="this.style.borderColor='var(--accent)';this.style.transform='scale(1.04)'" onmouseleave="this.style.borderColor='var(--line2)';this.style.transform='scale(1)'">
      ${s.img ? `
        <img src="${s.img}" alt="${esc(s.name)}" style="width:72px;height:72px;object-fit:contain;filter:drop-shadow(0 3px 6px rgba(0,0,0,0.35));pointer-events:none">
      ` : `
        <span style="color:var(--accent);display:flex;align-items:center;justify-content:center;height:48px;line-height:0">
          ${IC(s.icon || "star", "xl")}
        </span>
      `}
      <span class="tiny b" style="font-size:10.5px;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:100%;color:var(--text)">${esc(s.name)}</span>
      <span class="tiny fnt" style="font-size:9px;opacity:0.75;line-height:1">${esc(s.meme || s.char || 'أنمي')}</span>
    </button>
  `).join('');
}

function renderMyStickersHTML() {
  const list = S.myCustomStickers || [];
  if (!list.length) {
    return `
      <div class="col center" style="grid-column:1/-1;padding:32px 12px;text-align:center;gap:12px">
        <span style="font-size:38px;line-height:1">🎨</span>
        <div class="b sm">لم تصنع أي ملصق بعد!</div>
        <div class="tiny fnt">اصنع ملصقات أنمي خاصة بك بشخصياتك المفضلة وصورك وعباراتك الأوتاكو</div>
        <button class="btn btn-purple btn-sm" onclick="openStickerMaker()">${I('wand','i s')} ابدأ بصناعة أول ملصق الآن 🚀</button>
      </div>
    `;
  }
  return `
    <div style="grid-column:1/-1;margin-bottom:6px">
      <button class="btn btn-purple btn-xs w100" onclick="openStickerMaker()">${I('plus','i s')} صناعة ملصق جديد في الاستوديو</button>
    </div>
  ` + list.map(s => `
    <div class="col center" style="background:var(--surface2);border:1px solid var(--line2);border-radius:16px;padding:8px 6px;gap:6px;position:relative;transition:all .18s">
      <button class="iconbtn btn-xs" style="position:absolute;top:4px;right:4px;background:rgba(0,0,0,0.6);border:none;color:var(--rose);width:22px;height:22px;line-height:0;z-index:3;border-radius:6px" onclick="event.stopPropagation();deleteCustomSticker('${s.id}')" title="حذف">${I('trash','i s')}</button>
      <div onclick="sendSticker('${s.icon||'sparkles'}', '${esc(s.name)}', '${s.img}')" style="cursor:pointer;display:flex;flex-direction:column;align-items:center;width:100%">
        <img src="${s.img}" alt="${esc(s.name)}" style="width:72px;height:72px;object-fit:contain;filter:drop-shadow(0 3px 6px rgba(0,0,0,0.35))">
        <span class="tiny b" style="font-size:10.5px;text-align:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:100%;margin-top:4px">${esc(s.name)}</span>
        <span class="tiny fnt" style="font-size:9px;opacity:0.75">${esc(s.text||'ملصق خاص')}</span>
      </div>
    </div>
  `).join('');
}

window.insertEmoji = function(emoji) {
  const inp = document.getElementById("minp");
  if (inp) {
    inp.value += emoji;
    inp.dispatchEvent(new Event('input'));
  }
};

window.sendSticker = function(icon, name, img) {
  closeOvl();
  const cid = S.activeChat || (S.params && S.params.id);
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) {
    toast("لا توجد محادثة مفتوحة لإرسال الملصق", "warn");
    return;
  }

  const mid = uid();
  const myUid = getChatMyUid();
  const msg = {
    id: mid,
    clientMessageId: mid,
    conversationId: cid,
    from: "me",
    senderId: myUid,
    senderName: S.me.name || "أنا",
    type: "sticker",
    icon: icon,
    name: name || "ملصق",
    src: img || null,
    img: img || null,
    text: name || "ملصق",
    at: now(),
    createdAt: now(),
    st: 2,
    pending: false
  };

  if (!c.messages) c.messages = [];
  c.messages.push(msg);
  if (c.msgs) c.msgs.push(msg);
  c.last = `🌟 ملصق: ${name || "أنمي"}`;
  c.lastAt = now();
  saveDebounced();
  snd("send");
  const msgBox = document.getElementById("msgs");
  if (msgBox && typeof window.updateChatDom === 'function') {
    window.updateChatDom(msgBox, c, u(c.userId), true);
  }
  if (typeof syncChatMessage === 'function') {
    syncChatMessage(cid, msg);
  }
  toast("أُرسل الملصق 🌟", "ok");
};

// ==========================================
// STICKER MAKER STUDIO (صانع الملصقات)
// ==========================================
window.STICKER_MAKER_STATE = {
  charId: "luffy",
  charName: "لوفي جير 5",
  icon: "⚡",
  c1: "#DC2626",
  c2: "#F59E0B",
  text: "تاتاكاي! 🔥",
  border: "white",
  stamp: "⚡",
  customImage: null
};

window.openStickerMaker = function() {
  openSheet('stickerMakerSheet');
  setTimeout(() => {
    initStickerMaker();
  }, 100);
};

SHEETS.stickerMakerSheet = () => {
  const characters = [
    { id: "luffy", n: "لوفي جير 5", icon: "⚡", c1: "#DC2626", c2: "#F59E0B" },
    { id: "gojo", n: "غوجو", icon: "👁️", c1: "#312E81", c2: "#818CF8" },
    { id: "eren", n: "إرين تاتاكاي", icon: "🔥", c1: "#7F1D1D", c2: "#B91C1C" },
    { id: "levi", n: "ليفاي تنظيف", icon: "⚔️", c1: "#1F2937", c2: "#6B7280" },
    { id: "jinwoo", n: "جين وو أرايز", icon: "👑", c1: "#1E1B4B", c2: "#4F46E5" },
    { id: "tanjiro", n: "تانجيرو شمس", icon: "☀️", c1: "#134E4A", c2: "#14B8A6" },
    { id: "anya", n: "آنيا ههه", icon: "😏", c1: "#065F46", c2: "#F472B6" },
    { id: "naruto", n: "ناروتو داتيبايو", icon: "🍥", c1: "#EA580C", c2: "#FACC15" },
    { id: "sasuke", n: "ساسكي شارينغان", icon: "🌙", c1: "#312E81", c2: "#6366F1" },
    { id: "zoro", n: "زورو عاشوراء", icon: "🗡️", c1: "#14532D", c2: "#22C55E" },
    { id: "frieren", n: "فريـرن سحر", icon: "✨", c1: "#064E3B", c2: "#10B981" },
    { id: "saitama", n: "سايتاما أوكي", icon: "😐", c1: "#78350F", c2: "#F59E0B" }
  ];

  const quickSlogans = [
    "تاتاكاي! 🔥", "أرايز! 👑", "داتيبايو! 🍥", "المجال اللانهائي! 👁️",
    "أوماي! حارق 🍱", "ههه... سخرية 😏", "واكو واكو! 🥜", "بانكاي! ⚡",
    "سوكا... 💭", "أنا الأقوى! 🌟", "يا ري يا ري 🧢", "نيكا إله الشمس ☀️"
  ];

  return sheet(
    `🛠️ صانع ملصقات الأنمي الاحترافي`,
    `
    <div class="col" style="gap:14px;padding:4px 0">
      <!-- Live Preview Area -->
      <div class="center" style="background:radial-gradient(circle at center, rgba(168,85,247,0.18), rgba(15,23,42,0.8));border-radius:20px;padding:20px 14px;border:1px solid rgba(255,255,255,0.1);position:relative">
        <div id="stk_maker_preview_wrap" style="transition:transform .2s">
          <canvas id="stk_maker_canvas" width="180" height="180" style="width:160px;height:160px;filter:drop-shadow(0 8px 20px rgba(0,0,0,0.55));border-radius:18px"></canvas>
        </div>
        <div class="row" style="position:absolute;bottom:8px;left:14px;right:14px;justify-content:space-between">
          <span class="badge b-purple xs">${I('sparkles','i s')} معاينة الملصق الحقيقية</span>
          <button class="btn btn-sec btn-xs" onclick="resetStickerMaker()">${I('refresh','i s')} إعادة ضبط</button>
        </div>
      </div>

      <!-- Step 1: Base Character / Custom Image -->
      <div class="col" style="gap:8px">
        <div class="rowb" style="align-items:center">
          <span class="b xs" style="color:var(--accent)">1. اختيار شخصية الأنمي أو رفع صورة:</span>
          <label class="btn btn-sec btn-xs" style="cursor:pointer;border-radius:99px">
            ${I('camera','i s')} رفع صورة خاصة
            <input type="file" id="stk_maker_file" accept="image/*" style="display:none" onchange="handleStickerImageUpload(this)">
          </label>
        </div>
        <div class="row no-sb" style="gap:8px;overflow-x:auto;padding-bottom:4px">
          ${characters.map(ch => `
            <button class="btn btn-xs ${window.STICKER_MAKER_STATE.charId === ch.id ? 'btn-pri' : 'btn-sec'}" style="border-radius:99px;white-space:nowrap" onclick="selectStickerMakerChar('${ch.id}','${ch.n}','${ch.icon}','${ch.c1}','${ch.c2}')">
              ${ch.icon} ${ch.n}
            </button>
          `).join('')}
        </div>
      </div>

      <!-- Step 2: Slogan Text -->
      <div class="col" style="gap:8px">
        <span class="b xs" style="color:var(--accent)">2. عبارة أو ميم أو شعار الأوتاكو:</span>
        <input type="text" id="stk_maker_text" class="inp" placeholder="اكتب عبارة للملصق (مثل: تاتاكاي!، أرايز، داتيبايو)..." value="${esc(window.STICKER_MAKER_STATE.text)}" oninput="window.STICKER_MAKER_STATE.text=this.value;updateStickerMakerPreview()">
        <div class="row no-sb" style="gap:6px;overflow-x:auto;padding-bottom:4px">
          ${quickSlogans.map(sl => `
            <button class="chip xs" style="white-space:nowrap;cursor:pointer" onclick="setStickerMakerSlogan('${esc(sl)}')">
              ${sl}
            </button>
          `).join('')}
        </div>
      </div>

      <!-- Step 3: Outline & Visual Style -->
      <div class="row" style="gap:10px">
        <div class="g1 col" style="gap:4px">
          <span class="b tiny fnt">إطار وقص الملصق:</span>
          <select id="stk_maker_border" class="inp" onchange="window.STICKER_MAKER_STATE.border=this.value;updateStickerMakerPreview()">
            <option value="white" ${window.STICKER_MAKER_STATE.border==='white'?'selected':''}>حواف مقصوصة بيضاء (Die-Cut)</option>
            <option value="neon" ${window.STICKER_MAKER_STATE.border==='neon'?'selected':''}>هالة نيون متوهجة (Cyan Neon)</option>
            <option value="gold" ${window.STICKER_MAKER_STATE.border==='gold'?'selected':''}>إطار ذهبي ملكي (Golden Aura)</option>
            <option value="violet" ${window.STICKER_MAKER_STATE.border==='violet'?'selected':''}>هالة بنفسجية سحرية (Void)</option>
            <option value="none" ${window.STICKER_MAKER_STATE.border==='none'?'selected':''}>بدون إطار (شفاف)</option>
          </select>
        </div>
        <div class="g1 col" style="gap:4px">
          <span class="b tiny fnt">رمز الشارة التعبيرية:</span>
          <select id="stk_maker_stamp" class="inp" onchange="window.STICKER_MAKER_STATE.stamp=this.value;updateStickerMakerPreview()">
            <option value="⚡" ${window.STICKER_MAKER_STATE.stamp==='⚡'?'selected':''}>⚡ برق خارق</option>
            <option value="🔥" ${window.STICKER_MAKER_STATE.stamp==='🔥'?'selected':''}>🔥 نار حارقة</option>
            <option value="👑" ${window.STICKER_MAKER_STATE.stamp==='👑'?'selected':''}>👑 تاج ملكي</option>
            <option value="👁️" ${window.STICKER_MAKER_STATE.stamp==='👁️'?'selected':''}>👁️ عين الغياس والشارينغان</option>
            <option value="⚔️" ${window.STICKER_MAKER_STATE.stamp==='⚔️'?'selected':''}>⚔️ سيوف قتالية</option>
            <option value="🌸" ${window.STICKER_MAKER_STATE.stamp==='🌸'?'selected':''}>🌸 زهور ساكورا</option>
            <option value="💖" ${window.STICKER_MAKER_STATE.stamp==='💖'?'selected':''}>💖 حب وكوايي</option>
            <option value="💀" ${window.STICKER_MAKER_STATE.stamp==='💀'?'selected':''}>💀 جمجمة لعنة</option>
          </select>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="row" style="gap:8px;margin-top:6px">
        <button class="btn btn-purple g1 btn-md" onclick="saveCustomSticker(true)">
          ${I('check','i s')} حفظ في ملصقاتي 💾
        </button>
        <button class="btn btn-pri g1 btn-md" onclick="sendStickerMakerDirect()">
          ${I('send','i s')} إرسال في المحادثة 🚀
        </button>
        <button class="btn btn-sec btn-md" onclick="downloadStickerMakerPNG()" title="تنزيل كصورة PNG">
          ${I('download','i s')}
        </button>
      </div>
    </div>
    `
  );
};

window.initStickerMaker = function() {
  updateStickerMakerPreview();
};

window.selectStickerMakerChar = function(id, n, icon, c1, c2) {
  window.STICKER_MAKER_STATE.charId = id;
  window.STICKER_MAKER_STATE.charName = n;
  window.STICKER_MAKER_STATE.icon = icon;
  window.STICKER_MAKER_STATE.c1 = c1;
  window.STICKER_MAKER_STATE.c2 = c2;
  window.STICKER_MAKER_STATE.customImage = null;
  updateStickerMakerPreview();
};

window.setStickerMakerSlogan = function(txt) {
  window.STICKER_MAKER_STATE.text = txt;
  const inp = document.getElementById("stk_maker_text");
  if (inp) inp.value = txt;
  updateStickerMakerPreview();
};

window.handleStickerImageUpload = function(input) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = function(e) {
      const img = new Image();
      img.onload = function() {
        window.STICKER_MAKER_STATE.customImage = img;
        updateStickerMakerPreview();
        toast("تم تحميل صورتك في صانع الملصقات 📸", "ok");
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(input.files[0]);
  }
};

window.resetStickerMaker = function() {
  window.STICKER_MAKER_STATE = {
    charId: "luffy",
    charName: "لوفي جير 5",
    icon: "⚡",
    c1: "#DC2626",
    c2: "#F59E0B",
    text: "تاتاكاي! 🔥",
    border: "white",
    stamp: "⚡",
    customImage: null
  };
  const inp = document.getElementById("stk_maker_text");
  if (inp) inp.value = window.STICKER_MAKER_STATE.text;
  updateStickerMakerPreview();
  toast("تمت إعادة ضبط الملصق", "info");
};

window.updateStickerMakerPreview = function() {
  const canvas = document.getElementById("stk_maker_canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const W = canvas.width;
  const H = canvas.height;
  const S_STK = window.STICKER_MAKER_STATE;

  ctx.clearRect(0, 0, W, H);

  // Background gradient / round rect
  const rad = 28;
  const borderType = S_STK.border || "white";
  let strokeColor = "#ffffff";
  let strokeWidth = 5;

  if (borderType === "neon") {
    strokeColor = "#00f0ff";
    ctx.shadowColor = "#00f0ff";
    ctx.shadowBlur = 14;
  } else if (borderType === "gold") {
    strokeColor = "#fbbf24";
    ctx.shadowColor = "#fbbf24";
    ctx.shadowBlur = 12;
  } else if (borderType === "violet") {
    strokeColor = "#c084fc";
    ctx.shadowColor = "#a855f7";
    ctx.shadowBlur = 12;
  } else if (borderType === "none") {
    strokeWidth = 0;
    ctx.shadowColor = "rgba(0,0,0,0.5)";
    ctx.shadowBlur = 8;
  } else {
    ctx.shadowColor = "rgba(0,0,0,0.45)";
    ctx.shadowBlur = 8;
  }

  // Draw Base Card with Die-Cut stroke
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(10, 10, W - 20, H - 20, rad);
  ctx.fillStyle = "#ffffff";
  ctx.fill();
  if (strokeWidth > 0) {
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = strokeWidth;
    ctx.stroke();
  }
  ctx.restore();

  // Draw Inner Gradient Card
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(15, 15, W - 30, H - 30, rad - 4);
  const grad = ctx.createLinearGradient(15, 15, W - 15, H - 15);
  grad.addColorStop(0, S_STK.c1 || "#3b82f6");
  grad.addColorStop(1, S_STK.c2 || "#8b5cf6");
  ctx.fillStyle = grad;
  ctx.fill();
  ctx.restore();

  // Character Name Header
  ctx.save();
  ctx.font = "bold 11px system-ui, -apple-system, sans-serif";
  ctx.fillStyle = "#ffffff";
  ctx.textAlign = "center";
  ctx.shadowColor = "rgba(0,0,0,0.6)";
  ctx.shadowBlur = 4;
  ctx.fillText(S_STK.charName || "أنمي بلاك", W / 2, 34);
  ctx.restore();

  // Center Content: custom image or icon
  if (S_STK.customImage) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(W / 2, 78, 38, 0, Math.PI * 2);
    ctx.clip();
    ctx.drawImage(S_STK.customImage, W / 2 - 38, 40, 76, 76);
    ctx.restore();

    // Circle border
    ctx.save();
    ctx.beginPath();
    ctx.arc(W / 2, 78, 38, 0, Math.PI * 2);
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.restore();
  } else {
    // Halo circle
    ctx.save();
    ctx.beginPath();
    ctx.arc(W / 2, 76, 36, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255,255,255,0.22)";
    ctx.fill();
    ctx.restore();

    // Big Icon
    ctx.save();
    ctx.font = "46px system-ui, -apple-system, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(S_STK.icon || "⚡", W / 2, 76);
    ctx.restore();
  }

  // Stamp Badge in Corner
  if (S_STK.stamp) {
    ctx.save();
    ctx.font = "20px system-ui, -apple-system, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(S_STK.stamp, W - 32, 42);
    ctx.restore();
  }

  // Slogan Text Banner at Bottom
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(22, H - 48, W - 44, 28, 8);
  ctx.fillStyle = "rgba(15, 23, 42, 0.94)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.2)";
  ctx.lineWidth = 1;
  ctx.stroke();

  ctx.font = "bold 12px system-ui, -apple-system, sans-serif";
  ctx.fillStyle = "#ffffff";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(S_STK.text || "أنمي بلاك", W / 2, H - 34);
  ctx.restore();
};

window.saveCustomSticker = function(showNotice) {
  const canvas = document.getElementById("stk_maker_canvas");
  if (!canvas) return;
  const dataURL = canvas.toDataURL("image/png");
  const S_STK = window.STICKER_MAKER_STATE;

  const newSticker = {
    id: "my_stk_" + uid(),
    name: S_STK.charName + " - " + (S_STK.text || "ملصق"),
    text: S_STK.text,
    icon: S_STK.stamp || S_STK.icon || "sparkles",
    img: dataURL,
    src: dataURL,
    createdAt: now()
  };

  S.myCustomStickers = S.myCustomStickers || [];
  S.myCustomStickers.unshift(newSticker);
  save();

  if (showNotice) {
    snd("success");
    toast("تم حفظ الملصق في قسم «ملصقاتي» بنجاح! 💾", "ok");
    addXP(15, "صناعة ملصق أنمي");
  }

  const cnt = document.getElementById("my_stk_cnt");
  if (cnt) cnt.innerText = S.myCustomStickers.length;

  return newSticker;
};

window.sendStickerMakerDirect = function() {
  const stk = saveCustomSticker(false);
  if (!stk) return;
  closeOvl();
  sendSticker(stk.icon, stk.name, stk.img);
};

window.downloadStickerMakerPNG = function() {
  const canvas = document.getElementById("stk_maker_canvas");
  if (!canvas) return;
  const dataURL = canvas.toDataURL("image/png");
  const a = document.createElement("a");
  a.href = dataURL;
  a.download = `anime_black_sticker_${Date.now()}.png`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  toast("تم تنزيل الملصق بصيغة PNG 📥", "ok");
  snd("success");
};

window.deleteCustomSticker = function(id) {
  S.myCustomStickers = (S.myCustomStickers || []).filter(x => x.id !== id);
  save();
  const myItems = document.getElementById("my_stk_items");
  if (myItems) myItems.innerHTML = renderMyStickersHTML();
  const cnt = document.getElementById("my_stk_cnt");
  if (cnt) cnt.innerText = (S.myCustomStickers || []).length;
  toast("تم حذف الملصق", "info");
  snd("tap");
};

// ============================================================================
// 8. SCHEDULED MESSAGES ENGINE
// ============================================================================
SHEETS.scheduleSheet = (cid) => {
  return sheet(
    `⏱️ جدولة رسالة جديدة`,
    `
    <div class="col" style="gap:12px">
      <label class="lbl">نص الرسالة</label>
      <textarea id="sched_text" class="input" rows="3" placeholder="اكتب الرسالة التي تريد إرسالها لاحقاً..."></textarea>

      <label class="lbl">وقت الإرسال المحدد</label>
      <div class="grid2" style="gap:8px">
        <button class="btn btn-sec btn-sm" onclick="setSchedTimeOffset(10 * 60 * 1000)">بعد 10 دقائق</button>
        <button class="btn btn-sec btn-sm" onclick="setSchedTimeOffset(60 * 60 * 1000)">بعد ساعة</button>
        <button class="btn btn-sec btn-sm" onclick="setSchedTimeOffset(3 * 3600 * 1000)">بعد 3 ساعات</button>
        <button class="btn btn-sec btn-sm" onclick="setSchedTomorrow9am()">غداً (9:00 ص)</button>
      </div>

      <div style="margin-top:6px">
        <label class="tiny mut" style="display:block;margin-bottom:4px">أو اختر تاريخاً ووقتاً مخصصاً:</label>
        <input type="datetime-local" id="sched_datetime" class="input" style="direction:ltr">
      </div>

      <button class="btn btn-pri" style="margin-top:10px" onclick="confirmScheduleMessage('${cid}')">
        ${I("calendar","i s")} تأكيد جدولة الرسالة
      </button>
    </div>
    `
  );
};

window.setSchedTimeOffset = function(ms) {
  const target = new Date(Date.now() + ms);
  const inp = document.getElementById("sched_datetime");
  if (inp) {
    const tzOffset = target.getTimezoneOffset() * 60000;
    const localISOTime = (new Date(target - tzOffset)).toISOString().slice(0, 16);
    inp.value = localISOTime;
  }
};

window.setSchedTomorrow9am = function() {
  const target = new Date();
  target.setDate(target.getDate() + 1);
  target.setHours(9, 0, 0, 0);
  const inp = document.getElementById("sched_datetime");
  if (inp) {
    const tzOffset = target.getTimezoneOffset() * 60000;
    const localISOTime = (new Date(target - tzOffset)).toISOString().slice(0, 16);
    inp.value = localISOTime;
  }
};

window.confirmScheduleMessage = function(cid) {
  const txtInp = document.getElementById("sched_text");
  const dtInp = document.getElementById("sched_datetime");
  const text = (txtInp && txtInp.value || "").trim();
  const dtVal = dtInp && dtInp.value;

  if (!text) {
    toast("يرجى كتابة نص الرسالة", "err");
    return;
  }
  if (!dtVal) {
    toast("يرجى تحديد وقت الإرسال", "err");
    return;
  }

  const schedTime = new Date(dtVal).getTime();
  if (schedTime <= now()) {
    toast("يجب أن يكون وقت الجدولة في المستقبل", "err");
    return;
  }

  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;

  const mid = uid();
  const myUid = getChatMyUid();
  const msg = {
    id: mid,
    clientMessageId: mid,
    conversationId: cid,
    from: "me",
    senderId: myUid,
    senderName: S.me.name || "أنا",
    type: "text",
    text: text,
    at: now(),
    createdAt: now(),
    isScheduled: true,
    scheduledAt: schedTime,
    st: 6, // SCHEDULED
    pending: false
  };

  c.messages.push(msg);
  save();
  closeOvl();
  toast("تمت جدولة الرسالة بنجاح ⏱️", "ok");
  const msgBox = document.getElementById("msgs");
  if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), true);
  syncChatMessage(cid, msg);
};

SHEETS.scheduledMsgs = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  const schedList = (c ? c.messages : []).filter(m => m.isScheduled && !m.gone);
  return sheet(
    `⏱️ الرسائل المجدولة (${schedList.length})`,
    `
    <div class="col" style="gap:10px">
      ${!schedList.length ? `
        <div class="center tiny fnt" style="padding:24px 0">لا توجد رسائل مجدولة حالياً في هذه المحادثة</div>
      ` : schedList.map(m => `
        <div style="background:var(--surface2);border:1px solid var(--line2);border-radius:12px;padding:10px 12px;display:flex;flex-direction:column;gap:6px">
          <div class="row" style="justify-content:space-between;color:var(--gold);font-size:11px">
            <span class="row" style="gap:4px">
              ${I("clock","i s")} موعد الإرسال: ${new Date(m.scheduledAt).toLocaleString("ar")}
            </span>
          </div>
          <div class="sm fnt b" style="word-break:break-word">${esc(m.text)}</div>
          <div class="row" style="gap:8px;margin-top:4px;justify-content:flex-end">
            <button class="btn btn-ghost btn-xs" onclick="rescheduleMsg('${cid}','${m.id}')">${I("clock","i s")} تعديل الموعد</button>
            <button class="btn btn-sec btn-xs" onclick="sendScheduledNow('${cid}','${m.id}')">إرسال الآن</button>
            <button class="btn btn-danger btn-xs" onclick="deleteScheduledMsg('${cid}','${m.id}')">${I("trash","i s")} إلغاء</button>
          </div>
        </div>
      `).join('')}
      <button class="btn btn-pri btn-sm" onclick="openSheet('scheduleSheet','${cid}')" style="margin-top:6px">
        ${I("plus","i s")} جدولة رسالة جديدة
      </button>
    </div>
    `
  );
};

window.sendScheduledNow = function(cid, mid) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  const m = (c.messages || []).find(x => x.id === mid);
  if (!m) return;

  m.isScheduled = false;
  m.at = now();
  m.st = 2;
  c.last = m.text;
  c.lastAt = now();
  save();
  closeOvl();
  toast("تم إرسال الرسالة المجدولة الآن", "ok");
  snd("send");
  const msgBox = document.getElementById("msgs");
  if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), true);
  syncChatMessage(cid, m);
};

window.rescheduleMsg = function(cid, mid) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  const m = (c.messages || []).find(x => x.id === mid);
  if (!m) return;
  openSheet('scheduleSheet', cid);
  setTimeout(() => {
    const txt = document.getElementById("sched_text");
    const dt = document.getElementById("sched_datetime");
    if (txt) txt.value = m.text || "";
    if (dt && m.scheduledAt) {
      const tzOffset = new Date(m.scheduledAt).getTimezoneOffset() * 60000;
      dt.value = (new Date(m.scheduledAt - tzOffset)).toISOString().slice(0, 16);
    }
  }, 100);
};

window.deleteScheduledMsg = function(cid, mid) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  c.messages = c.messages.filter(x => x.id !== mid);
  save();
  closeOvl();
  toast("تم إلغاء الرسالة المجدولة", "ok");
  const msgBox = document.getElementById("msgs");
  if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), false);
};

// Periodic Scheduled Message Dispatcher (Every 10 seconds)
if (!window._schedCheckInterval) {
  window._schedCheckInterval = setInterval(() => {
    const currentNow = now();
    (S.chats || []).forEach(c => {
      let changed = false;
      (c.messages || []).forEach(m => {
        if (m.isScheduled && m.scheduledAt && currentNow >= m.scheduledAt) {
          m.isScheduled = false;
          m.at = currentNow;
          m.st = 2;
          c.last = m.text;
          c.lastAt = currentNow;
          changed = true;
          syncChatMessage(c.id, m);
        }
      });
      if (changed) {
        save();
        if (S.page === "chatRoom" && S.params && S.params.id === c.id) {
          const msgBox = document.getElementById("msgs");
          if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), true);
        }
      }
    });
  }, 10000);
}

// ============================================================================
// 9. WALLPAPER SYNCHRONIZATION & SYSTEM EVENTS
// ============================================================================
SHEETS.chatWallpaper = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  const curImg = c && c.wallpaperImg;
  const curGrad = c && c.wallpaper;

  const animeWallpapers = [
    ["طوكيو أكيهابارا ليلاً", "#0C0A1E", "#00A3FF"],
    ["حديقة الساكورا اليابانية", "#831843", "#FBCFE8"],
    ["نيون سايبربانك", "#06B6D4", "#7C3AED"],
    ["غرفة الزن البسيطة", "#1C1917", "#57534E"],
    ["فخامة الظلام الملكي", "#0A0A0A", "#1E1E24"],
    ["الفضاء الكوني السحيق", "#020617", "#1E1B4B"]
  ];

  const gradientSwatches = [
    ["#0A0A0A", "#121212"],
    ["#7F1D1D", "#EA580C"],
    ["#3B0764", "#A855F7"],
    ["#064E3B", "#10B981"],
    ["#0C4A6E", "#0EA5E9"],
    ["#831843", "#DB2777"],
    ["#111827", "#374151"],
    ["#1a1206", "#F59E0B"],
    ["#000000", "#00A3FF"]
  ];

  return sheet(
    I("palette","i s") + " خلفية المحادثة والمظهر",
    `
    <div class="col" style="gap:12px">
      <input type="file" id="wpFileCustom" accept="image/*" style="display:none" onchange="uploadWallpaper(this, '${cid}')">

      <button class="btn btn-sec row center" onclick="document.getElementById('wpFileCustom').click()" style="gap:8px">
        ${I("image","i s")} رفع صورة خلفية مخصصة من جهازك
      </button>

      <div class="lbl">خلفيات أنمي مميزة</div>
      <div class="grid2" style="gap:8px">
        ${animeWallpapers.map(([nm, a, b]) => `
          <button style="height:54px;border-radius:12px;background:linear-gradient(135deg,${a},${b});border:2px solid var(--line2);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:4px" onclick="setChatWallpaper('${cid}', ['${a}','${b}'], null, '${nm}')">
            <span class="tiny b" style="color:#fff;text-shadow:0 1px 4px rgba(0,0,0,0.85);font-size:11px">${nm}</span>
          </button>
        `).join('')}
      </div>

      <div class="lbl">تدرجات لونية سريعة</div>
      <div class="grid3" style="gap:8px">
        ${gradientSwatches.map(([c1, c2]) => `
          <button style="height:48px;border-radius:10px;background:linear-gradient(135deg,${c1},${c2});border:2px solid var(--line2);cursor:pointer" onclick="setChatWallpaper('${cid}', ['${c1}','${c2}'], null, 'تدرج لوني')"></button>
        `).join('')}
      </div>

      <button class="btn btn-ghost btn-sm" onclick="setChatWallpaper('${cid}', null, null, 'الافتراضية')" style="margin-top:6px;color:var(--muted)">
        استعادة الخلفية الافتراضية
      </button>
    </div>
    `
  );
};

window.setChatWallpaper = function(cid, colors, imgSrc, name) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  c.wallpaper = colors;
  c.wallpaperImg = imgSrc;
  save();
  closeOvl();

  // Apply immediately to current msgBox
  const msgBox = document.getElementById("msgs");
  if (msgBox) {
    if (imgSrc) {
      msgBox.style.background = `url('${imgSrc}') center/cover`;
    } else if (colors && colors.length >= 2) {
      msgBox.style.background = `linear-gradient(180deg, ${colors[0]}, ${colors[1]})`;
    } else {
      msgBox.style.background = "";
    }
  }

  toast(name ? 'تم تعيين خلفية: ' + name : 'تم تغيير الخلفية', 'ok');

  // Broadcast System Event
  sendSystemEvent(cid, (S.me.name || "أنا") + " قام بتغيير خلفية المحادثة");

  // Synchronize to Firestore for both participants
  if (window.db && window.updateDoc && window.doc) {
    window.updateDoc(window.doc(window.db, "chats", cid), {
      wallpaper: colors || null,
      wallpaperImg: imgSrc || null,
      updatedAt: now()
    }).catch(e => console.error("Error syncing wallpaper:", e));
  }
};

window.uploadWallpaper = function(inp, cid) {
  const f = inp.files && inp.files[0];
  if (!f) return;
  const rd = new FileReader();
  rd.onload = () => {
    const img = new Image();
    img.onload = () => {
      const max = 900;
      const sc = Math.min(1, max / Math.max(img.width, img.height));
      const cv = document.createElement("canvas");
      cv.width = Math.round(img.width * sc);
      cv.height = Math.round(img.height * sc);
      const ctx = cv.getContext("2d");
      ctx.drawImage(img, 0, 0, cv.width, cv.height);
      const optSrc = cv.toDataURL("image/jpeg", 0.85);
      setChatWallpaper(cid, null, optSrc, "صورة مخصصة");
    };
    img.src = rd.result;
  };
  rd.readAsDataURL(f);
};

window.sendSystemEvent = function(cid, text) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  const mid = uid();
  const sysMsg = {
    id: mid,
    clientMessageId: mid,
    conversationId: cid,
    type: "system_event",
    text: text,
    at: now(),
    createdAt: now(),
    st: 2
  };
  c.messages.push(sysMsg);
  save();
  const msgBox = document.getElementById("msgs");
  if (msgBox) window.updateChatDom(msgBox, c, u(c.userId), false);
  syncChatMessage(cid, sysMsg);
};

// ============================================================================
// 10. MESSAGE BUBBLE RENDERER (Unified Architecture for ALL Types)
// ============================================================================
window.msgBubble = function(m, uu, cid) {
  if (!m) return "";
  const me = isMsgMine(m);
  const C = cid || S.activeChat || (S.params && S.params.id);

  // Deleted message state
  if (m.gone || m.isDeleted) {
    return `
      <div class="msg ${me ? "me msg-mine" : "them msg-them"}" data-mid="${m.id||""}" id="m_${m.id||""}" style="opacity:.65;position:relative">
        ${S.selMode ? selBox(m.id) : ""}
        <span class="tiny fnt" style="display:flex;align-items:center;gap:6px">
          ${I("ban","i s")} حُذفت هذه الرسالة
        </span>
        <span class="tm">${hhmm(m.at||m.createdAt)}</span>
      </div>
    `;
  }

  // System Event Message (Centered Pill)
  if (m.type === "system_event") {
    return `
      <div class="center" id="m_${m.id||""}" data-mid="${m.id||""}" style="margin:8px 0;width:100%">
        <span style="background:rgba(0,0,0,0.45);border:1px solid var(--line2);border-radius:99px;padding:3px 14px;font-size:11px;color:var(--muted);backdrop-filter:blur(4px);display:inline-flex;align-items:center;gap:6px">
          ${esc(m.text)} · ${hhmm(m.at||m.createdAt)}
        </span>
      </div>
    `;
  }

  // Reply Quote Preview
  const quote = (m.quote || m.replyToMessageId) ? (() => {
    const q = m.quote || (m.replyToMessageId ? (msgById(m.replyToMessageId) ? { id: m.replyToMessageId, n: msgById(m.replyToMessageId).senderName, t: msgById(m.replyToMessageId).text } : null) : null);
    if (!q) return "";
    return `
      <div style="border-inline-start:3px solid var(--cyan);background:rgba(0,0,0,.2);border-radius:8px;padding:5px 9px;margin-bottom:6px;text-align:right;cursor:pointer" onclick="jumpToMsg('${q.id}')">
        <div class="tiny b" style="color:var(--cyan)">${esc(q.n || "رد على رسالة")}</div>
        <div class="tiny fnt" style="opacity:.85;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(q.t || "مرفق")}</div>
      </div>
    `;
  })() : "";

  // Forwarded Tag
  const fwd = m.fwd ? `
    <div class="tiny fnt" style="opacity:.72;margin-bottom:4px;display:flex;align-items:center;gap:4px">
      ${I("fwd","i s")} مُعاد توجيهها
    </div>
  ` : "";

  // Reactions Bar
  const reacts = (m.reacts && m.reacts.length) ? `
    <div class="row" style="gap:4px;margin-top:6px;flex-wrap:wrap">
      ${Object.entries(m.reacts.reduce((a, r) => { a[r] = (a[r] || 0) + 1; return a; }, {})).map(([ic, n]) => `
        <button style="display:inline-flex;align-items:center;gap:4px;background:${me ? 'rgba(0,0,0,.25)' : 'var(--surface3)'};border:1px solid var(--line2);border-radius:99px;padding:2px 8px;line-height:0;cursor:pointer" onclick="toggleReact('${m.id}','${ic}')">
          <span style="color:var(--accent);line-height:0">${I(ic,"i s")}</span>
          <span class="tiny mono">${n}</span>
        </button>
      `).join("")}
    </div>
  ` : "";

  // CONTENT RENDERING
  let inner = "";

  // Check multi-attachments
  if (m.attachments && m.attachments.length > 0) {
    const atts = m.attachments;
    const attsJson = esc(JSON.stringify(atts));

    if (atts.length === 1) {
      const a = atts[0];
      if (a.type === "image" || a.type === "gif") {
        inner = `
          <img src="${a.src}" alt="" onclick="openImgViewer(${attsJson}, 0)" style="width:100%;max-height:280px;border-radius:12px;display:block;cursor:pointer;object-fit:cover;box-shadow:0 2px 8px rgba(0,0,0,.2)">
        `;
      } else if (a.type === "video") {
        inner = `
          <video src="${a.src}" controls style="width:100%;max-height:280px;border-radius:12px;display:block;background:#000"></video>
        `;
      } else {
        inner = `
          <div class="row" style="gap:9px;min-width:180px">
            <span class="ico-tile" style="width:38px;height:38px;border-radius:12px;background:${me ? 'rgba(0,0,0,.25)' : 'var(--surface3)'};color:${me ? '#fff' : 'var(--gold)'}">${I("file","i l")}</span>
            <span class="g1" style="min-width:0">
              <span class="b xs" style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(a.name||"ملف")}</span>
              <span class="tiny fnt" style="opacity:.75">مرفق محفوظ</span>
            </span>
            <a class="btn btn-sec btn-xs" href="${a.src}" download="${esc(a.name||"file")}" onclick="event.stopPropagation()">${I("download","i s")}</a>
          </div>
        `;
      }
    } else {
      // Multiple attachments grid (2 to 5 items)
      const gridCols = (atts.length === 2 || atts.length === 4) ? "repeat(2, 1fr)" : (atts.length === 3) ? "repeat(3, 1fr)" : "repeat(3, 1fr)";
      inner = `
        <div style="display:grid;grid-template-columns:${gridCols};gap:4px;border-radius:12px;overflow:hidden;margin-bottom:4px">
          ${atts.map((a, i) => `
            <div style="position:relative;height:${atts.length <= 2 ? '140px' : '90px'};background:var(--surface3);cursor:pointer;overflow:hidden" onclick="openImgViewer(${attsJson}, ${i})">
              ${a.type === 'video' ? `
                <video src="${a.src}" style="width:100%;height:100%;object-fit:cover"></video>
                <div style="position:absolute;inset:0;background:rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:#fff">${I("play","i s")}</div>
              ` : a.type === 'file' ? `
                <div class="center" style="height:100%;color:var(--accent);padding:4px;flex-direction:column;gap:2px">
                  ${I("file","i s")}
                  <span style="font-size:8px;max-width:60px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(a.name||"ملف")}</span>
                </div>
              ` : `
                <img src="${a.src}" style="width:100%;height:100%;object-fit:cover;display:block" loading="lazy" alt="">
              `}
            </div>
          `).join('')}
        </div>
      `;
    }

    if (m.text) {
      inner += `<div style="margin-top:6px;line-height:1.5;direction:auto;unicode-bidi:plaintext;white-space:pre-wrap;word-break:break-word">${linkify(m.text)}</div>`;
    }

  } else if (m.type === "share") {
    inner = shareCardHTML(m, me);

  } else if (m.type === "image" && m.src) {
    inner = `<img src="${m.src}" alt="" onclick="openImgViewer([{src:'${m.src}'}], 0)" style="max-width:100%;max-height:280px;border-radius:12px;display:block;cursor:pointer;object-fit:cover;box-shadow:0 2px 8px rgba(0,0,0,.2)">`;
    if (m.text && m.text !== "صورة") inner += `<div style="margin-top:6px;line-height:1.5;white-space:pre-wrap;word-break:break-word">${linkify(m.text)}</div>`;

  } else if (m.type === "video" && m.src) {
    inner = `<video src="${m.src}" controls style="max-width:100%;max-height:280px;border-radius:12px;display:block;background:#000"></video>`;
    if (m.text && m.text !== "فيديو") inner += `<div style="margin-top:6px;line-height:1.5;white-space:pre-wrap;word-break:break-word">${linkify(m.text)}</div>`;

  } else if (m.type === "gif" || (m.type === "image" && m.text === "GIF")) {
    inner = `
      <div style="position:relative;border-radius:12px;overflow:hidden">
        <img src="${m.src}" alt="GIF" onclick="openImgViewer([{src:'${m.src}'}], 0)" style="max-width:100%;max-height:260px;border-radius:12px;display:block;cursor:pointer;object-fit:cover">
        <span style="position:absolute;bottom:6px;right:6px;background:rgba(0,0,0,0.7);color:#fff;font-size:9.5px;padding:2px 6px;border-radius:4px;font-weight:900">GIF</span>
      </div>
    `;

  } else if (m.type === "sticker") {
    if (m.src || m.img) {
      inner = `
        <div class="stk-render-box" style="padding:4px;display:flex;flex-direction:column;align-items:center;cursor:pointer" onclick="openImg('${m.src || m.img}', '${esc(m.name || "ملصق أنمي")}')">
          <img src="${m.src || m.img}" alt="${esc(m.name || "ملصق")}" style="max-width:140px;max-height:140px;width:auto;height:auto;object-fit:contain;filter:drop-shadow(0 6px 14px rgba(0,0,0,0.38));border-radius:12px;display:block" loading="lazy">
          ${m.name ? `<span class="tiny b" style="font-size:10px;margin-top:4px;opacity:0.9;color:${me ? '#fff' : 'var(--text)'}">${esc(m.name)}</span>` : ''}
        </div>
      `;
    } else {
      inner = `
        <div style="line-height:0;color:${me ? '#fff' : 'var(--accent)'};padding:6px 2px;display:flex;align-items:center;justify-content:center;gap:6px">
          ${IC(m.icon || "star", "xl")}
          ${m.name ? `<span class="tiny b">${esc(m.name)}</span>` : ''}
        </div>
      `;
    }

  } else if (m.type === "voice") {
    inner = `
      <div class="row audio-bar" style="gap:8px;min-width:190px">
        <button class="iconbtn" id="vbtn_${m.id}" style="width:34px;height:34px;background:${me ? 'rgba(255,255,255,.22)' : 'var(--surface3)'};border-color:transparent;color:${me ? '#fff' : 'var(--accent)'};flex-shrink:0" onclick="playVoice(this,'${m.id}')" aria-label="تشغيل">
          ${I("play","i s")}
        </button>
        <div class="g1 vbars" id="vbars_${m.id}" style="display:flex;gap:2.5px;align-items:center;height:24px;cursor:pointer" onclick="seekVoice(event,'${m.id}')">
          ${Array.from({ length: 22 }, (_, i) => `<i style="width:2.5px;height:${5 + strHash((m.id||"v") + "w" + i) % 14}px;background:${me ? 'rgba(255,255,255,.75)' : 'var(--muted)'};border-radius:99px;transition:all .15s"></i>`).join("")}
        </div>
        <span class="tiny mono vtime" id="vtime_${m.id}" style="opacity:.85;flex-shrink:0;font-size:10.5px">
          0:${String(m.dur || 14).padStart(2, "0")}
        </span>
      </div>
    `;

  } else if (m.type === "location" || m.type === "map") {
    const lat = m.lat || 35.6983;
    const lng = m.lng || 139.7731;
    const mapUrl = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
    inner = `
      <div class="col" style="gap:6px;min-width:200px">
        <div class="row" style="gap:8px">
          <span style="color:var(--rose);font-size:18px">📍</span>
          <div class="g1">
            <div class="b xs">${esc(m.label || "موقع جغرافي")}</div>
            <div class="tiny fnt" style="opacity:0.8">${esc(m.address || `${lat.toFixed(4)}, ${lng.toFixed(4)}`)}</div>
          </div>
        </div>
        <a class="btn btn-sec btn-xs center" href="${mapUrl}" target="_blank" style="margin-top:4px;gap:4px">
          ${I("map","i s")} فتح في خرائط Google
        </a>
      </div>
    `;

  } else if (m.type === "contact") {
    const cu = u(m.uid || "");
    inner = `
      <div class="row" style="gap:9px;min-width:190px">
        ${av(cu, 40)}
        <span class="g1">
          <span class="b xs" style="display:block">${esc(cu.name)}</span>
          <span class="tiny fnt" style="opacity:.8">@${esc(cu.username)} · جهة اتصال</span>
        </span>
        <span class="col" style="gap:4px">
          <button class="btn btn-sec btn-xs" onclick="openProfile('${cu.id}')">ملفه</button>
          <button class="btn btn-sec btn-xs" onclick="startChat('${cu.id}')">راسله</button>
        </span>
      </div>
    `;

  } else if (m.type === "file") {
    inner = `
      <div class="row" style="gap:9px;min-width:180px">
        <span class="ico-tile" style="width:38px;height:38px;border-radius:12px;background:${me ? 'rgba(0,0,0,.25)' : 'var(--surface3)'};color:${me ? '#fff' : 'var(--gold)'}">${I("file","i l")}</span>
        <span class="g1" style="min-width:0">
          <span class="b xs" style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc((m.name||"ملف").slice(0,28))}</span>
          <span class="tiny fnt" style="opacity:.75">مرفق محفوظ داخل المحادثة</span>
        </span>
        ${m.src ? `<a class="btn btn-sec btn-xs" href="${m.src}" download="${esc(m.name||"file")}" onclick="event.stopPropagation()">${I("download","i s")}</a>` : ""}
      </div>
    `;

  } else if (m.type === "call") {
    inner = `
      <div class="row" style="gap:8px">
        <span class="ico-tile" style="width:34px;height:34px;border-radius:11px;background:${me ? 'rgba(0,0,0,.25)' : 'var(--surface3)'};color:${m.missed ? 'var(--rose)' : me ? '#fff' : 'var(--emerald)'}">
          ${I(m.ctype === "video" ? "video" : "phone", "i l")}
        </span>
        <span class="g1">
          <span class="b xs" style="display:block">${m.missed ? "مكالمة فائتة" : m.ctype === "video" ? "مكالمة فيديو" : "مكالمة صوتية"}</span>
          <span class="tiny fnt" style="opacity:.8">${m.dur ? Math.floor(m.dur / 60) + ":" + String(m.dur % 60).padStart(2, "0") + " د" : ""} · ${m.out ? "صادرة" : "واردة"}</span>
        </span>
      </div>
    `;

  } else if (m.type === "cpoll") {
    const tot = (m.votes || []).reduce((a, b) => a + b, 0) || 0;
    inner = `
      <div style="min-width:200px">
        <div class="b xs">${I("barchart","i s")} ${esc(m.q || "استطلاع")}</div>
        ${(m.opts || []).map((o, oi) => {
          const pc = tot ? Math.round(100 * (m.votes[oi] || 0) / tot) : 0;
          return `
            <button style="display:block;width:100%;margin-top:7px;background:${me ? 'rgba(0,0,0,.2)' : 'var(--surface3)'};border:1px solid ${m.me === oi ? 'var(--accent)' : 'var(--line2)'};border-radius:10px;padding:0;overflow:hidden;cursor:pointer;text-align:right" onclick="voteChatPoll('${m.id}',${oi})">
              <span style="display:block;position:relative;padding:7px 10px">
                <span style="position:absolute;inset:0;width:${pc}%;background:${me ? 'rgba(255,255,255,.18)' : 'rgba(0,163,255,.16)'}"></span>
                <span class="row" style="justify-content:space-between;position:relative">
                  <span class="tiny b">${esc(o)}</span>
                  <span class="tiny mono mut">${pc}%</span>
                </span>
              </span>
            </button>
          `;
        }).join("")}
        <div class="tiny fnt" style="opacity:.75;margin-top:6px;text-align:left">${tot} تصويت</div>
      </div>
    `;

  } else {
    // Default text message
    inner = `<div style="direction:auto;unicode-bidi:plaintext;white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere">${linkify(m.text || "")}</div>`;
  }

  // Double-tap & Long-press handlers
  return `
    <div class="msg ${me ? "me msg-mine" : "them msg-them"}"
         data-mid="${m.id || ""}"
         id="m_${m.id || ""}"
         style="position:relative"
         ondblclick="triggerQuickReact('${m.id}')"
         oncontextmenu="event.preventDefault();openSheet('msgMenu','${m.id}')"
         onclick="if(S.selMode)toggleSel('${m.id}')">
      ${S.selMode ? selBox(m.id) : ""}
      ${quote}
      ${fwd}
      ${inner}
      ${(m.uploading || (m.uploadProgress !== undefined && m.uploadProgress < 100)) ? `
        <div id="m_progress_${m.id}" class="upload-progress-box" style="margin-top:6px;background:rgba(0,0,0,0.6);border:1px solid rgba(255,255,255,0.15);border-radius:10px;padding:7px 10px;backdrop-filter:blur(6px);box-shadow:0 2px 8px rgba(0,0,0,0.25)">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:5px;font-size:11px;font-weight:700;color:#fff">
            <span style="display:inline-flex;align-items:center;gap:6px">
              <span class="spin" style="display:inline-block;width:11px;height:11px;border:2px solid var(--accent);border-top-color:transparent;border-radius:50%"></span>
              <span class="ptxt">${m.uploadProgress || 0}% جارٍ التحميل والرفع...</span>
            </span>
            <span class="mono tiny pnum" style="color:var(--cyan)">${m.uploadProgress || 0}%</span>
          </div>
          <div style="width:100%;height:5px;background:rgba(255,255,255,0.15);border-radius:99px;overflow:hidden">
            <div class="pfill" style="width:${m.uploadProgress || 0}%;height:100%;background:linear-gradient(90deg,#00A3FF,#10B981);border-radius:99px;transition:width 0.2s ease"></div>
          </div>
        </div>
      ` : ""}
      ${reacts}
      <span class="tm">
        ${(m.isEdited || m.edited) ? '<span class="tiny mut" style="margin-inline-end:3px">معدلة</span>' : ''}
        ${hhmm(m.at || m.createdAt)}
        ${me ? metaStatusHTML(m) : ''}
      </span>
    </div>
  `;
};

// Meta status icons for outgoing messages (WhatsApp / Telegram style ticks)
function metaStatusHTML(m) {
  if (!m) return "";
  if (m.isScheduled || m.st === 6) {
    return `<span style="color:var(--gold);font-size:10px;margin-inline-start:4px" title="مجدولة">⏱️</span>`;
  }
  if (m.failed || m.st === 5) {
    return `<button type="button" title="تعذّر الإرسال — اضغط لإعادة المحاولة" style="background:none;border:none;padding:0;color:var(--rose);line-height:0;display:inline-flex;align-items:center;vertical-align:-2px;cursor:pointer;gap:2px;margin-inline-start:4px" onclick="event.stopPropagation();retryPendingMsg('','${m.id}')">${I("alert","i s")}<span style="font-size:9.5px;color:var(--rose)">إعادة المحاولة</span></button>`;
  }
  if (m.uploading || (m.uploadProgress !== undefined && m.uploadProgress < 100)) {
    return `<span title="جارٍ التحميل والرفع" style="opacity:0.85;line-height:0;display:inline-flex;align-items:center;vertical-align:-2px;margin-inline-start:4px;color:var(--cyan)">
      <span class="spin" style="display:inline-block;width:10px;height:10px;border:1.5px solid currentColor;border-top-color:transparent;border-radius:50%"></span>
    </span>`;
  }
  if (m.st === 4) {
    return `<span title="مقروءة" style="color:var(--cyan);line-height:0;display:inline-flex;align-items:center;vertical-align:-2px;margin-inline-start:4px">${I("check","i s")}<span style="margin-inline-start:-6px">${I("check","i s")}</span></span>`;
  }
  if (m.st === 3) {
    return `<span title="مستلمة" style="color:rgba(255,255,255,0.75);line-height:0;display:inline-flex;align-items:center;vertical-align:-2px;margin-inline-start:4px">${I("check","i s")}<span style="margin-inline-start:-6px">${I("check","i s")}</span></span>`;
  }
  // Sent (st === 2 or default) - Immediate single tick checkmark
  return `<span title="مرسلة" style="color:rgba(255,255,255,0.75);line-height:0;display:inline-flex;vertical-align:-2px;margin-inline-start:4px">${I("check","i s")}</span>`;
}
window.metaStatusHTML = metaStatusHTML;

// Quick reaction burst on double-tap
window.triggerQuickReact = function(mid) {
  toggleReact(mid, "heart");
  const el = document.getElementById("m_" + mid);
  if (el) {
    const burst = document.createElement("div");
    burst.innerHTML = "❤️";
    burst.style.cssText = "position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) scale(1.5);font-size:32px;pointer-events:none;z-index:20;animation:heartBurst 0.6s ease forwards";
    el.appendChild(burst);
    setTimeout(() => burst.remove(), 600);
  }
};

// ============================================================================
// 11. SMART SCROLL & DOM SYNCHRONIZATION (No-Jump, Smooth Updates)
// ============================================================================
window.updateChatDom = function(msgBox, c, uu, forceScrollBottom) {
  if (!msgBox || !c) return;

  // Measure current scroll position
  const isNearBottom = (msgBox.scrollHeight - msgBox.scrollTop - msgBox.clientHeight) < 180;
  const shouldScroll = forceScrollBottom || isNearBottom;

  // Insert chat start header if missing
  if (!msgBox.querySelector('.chat-start-hdr')) {
    msgBox.insertAdjacentHTML("afterbegin", `
      <div class="center tiny fnt chat-start-hdr" style="margin-bottom:6px">
        — بداية المحادثة · ${new Date(c.lastAt || now()).toLocaleDateString("ar")} —
      </div>
    `);
    if (c.vanish) {
      msgBox.insertAdjacentHTML("afterbegin", `
        <div class="center tiny fnt" style="color:var(--emerald);margin-bottom:6px">
          ${I("clock","i s")} الرسائل تختفي تلقائياً بعد ${c.vanish === 24 ? "٢٤ ساعة" : "٣ أيام"}
        </div>
      `);
    }
  }

  // Surgical render for messages
  let lastDay = "";
  c.messages.forEach(m => {
    // Day header
    const dl = dayLbl(m.at || m.createdAt);
    if (dl !== lastDay) {
      lastDay = dl;
      const dlId = 'day_' + Array.from(dl).map(char => char.charCodeAt(0)).join('');
      if (!document.getElementById(dlId)) {
        const dlHtml = `<div class="center" id="${dlId}" style="margin:10px 0 8px"><span class="tiny b" style="background:var(--surface3);border:1px solid var(--line2);border-radius:99px;padding:4px 12px;color:var(--muted)">${dl}</span></div>`;
        const typingEl = document.getElementById("chat_typing_indicator");
        if (typingEl) {
          typingEl.insertAdjacentHTML("beforebegin", dlHtml);
        } else {
          msgBox.insertAdjacentHTML("beforeend", dlHtml);
        }
      }
    }

    // Message element
    const mId = "m_" + m.id;
    let mEl = document.getElementById(mId);
    const mHash = (typeof window.getMsgHash === "function") ? window.getMsgHash(m) : ((m.text || "") + (m.st || 2));

    const mHtml = (typeof window.msgBubble === "function") ? window.msgBubble(m, uu, c.id) : msgBubble(m, uu, c.id);

    if (mEl) {
      if (mEl.getAttribute("data-hash") !== String(mHash)) {
        mEl.outerHTML = mHtml.replace('class="msg ', 'data-hash="' + mHash + '" class="msg ');
      }
    } else {
      const typingEl = document.getElementById("chat_typing_indicator");
      if (typingEl) {
        typingEl.insertAdjacentHTML("beforebegin", mHtml.replace('class="msg ', 'data-hash="' + mHash + '" class="msg '));
      } else {
        msgBox.insertAdjacentHTML("beforeend", mHtml.replace('class="msg ', 'data-hash="' + mHash + '" class="msg '));
      }
    }
  });

  
  // Remove deleted messages from DOM
  msgBox.querySelectorAll('.msg[id^="m_"]').forEach(el => {
     if(!c.messages.find(m => "m_" + m.id === el.id)) el.remove();
  });
  
  // Apply scroll behavior
  if (shouldScroll) {
    msgBox.scrollTop = msgBox.scrollHeight;
    const fab = document.getElementById("msgfab");
    if (fab) fab.style.display = "none";
  } else {
    // Show floating button if scrolled up
    const fab = document.getElementById("msgfab");
    if (fab) fab.style.display = "flex";
  }
};

window.jumpToMsg = function(mid) {
  if (!mid) return;
  const mEl = document.getElementById("m_" + mid);
  if (mEl) {
    mEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    mEl.classList.add("msgflash");
    setTimeout(() => mEl.classList.remove("msgflash"), 1800);
  } else {
    toast("الرسالة قديمة أو غير موجودة في العرض الحالي", "info");
  }
};

// ============================================================================
// 12. CHAT SEARCH SHEET (Tabs: All, Messages, Media, Files, Links)
// ============================================================================
window._chatSearchTab = 'all';
SHEETS.chatSearch = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  window._chatSearchTab = 'all';
  return sheet(
    I("search","i s") + " البحث في المحادثة",
    `
    <div class="col" style="gap:10px">
      <input type="text" id="chat_search_query" class="input" placeholder="ابحث بالنص، المستخدم (@)، الروابط أو الملفات..." oninput="doChatSearch('${cid}', this.value)" autofocus>
      <div class="row" style="gap:6px;overflow-x:auto;padding-bottom:2px" class="no-sb" id="chat_search_tabs">
        <button class="btn btn-xs ${window._chatSearchTab==='all'?'btn-pri':'btn-sec'}" onclick="setChatSearchTab('${cid}','all')">الكل</button>
        <button class="btn btn-xs ${window._chatSearchTab==='text'?'btn-pri':'btn-sec'}" onclick="setChatSearchTab('${cid}','text')">الرسائل</button>
        <button class="btn btn-xs ${window._chatSearchTab==='media'?'btn-pri':'btn-sec'}" onclick="setChatSearchTab('${cid}','media')">الوسائط</button>
        <button class="btn btn-xs ${window._chatSearchTab==='files'?'btn-pri':'btn-sec'}" onclick="setChatSearchTab('${cid}','files')">الملفات</button>
        <button class="btn btn-xs ${window._chatSearchTab==='links'?'btn-pri':'btn-sec'}" onclick="setChatSearchTab('${cid}','links')">الروابط</button>
      </div>
      <div id="chat_search_results" class="col" style="gap:6px;max-height:340px;overflow-y:auto" class="no-sb">
        <div class="center tiny fnt" style="padding:20px 0">اكتب للبحث في سجل الرسائل والمحتوى المشترك</div>
      </div>
    </div>
    `
  );
};

window.setChatSearchTab = function(cid, tab) {
  window._chatSearchTab = tab;
  const tabs = document.getElementById("chat_search_tabs");
  if (tabs) {
    tabs.querySelectorAll("button").forEach(b => {
      b.className = "btn btn-xs btn-sec";
    });
    const activeBtn = Array.from(tabs.querySelectorAll("button")).find(b => b.getAttribute("onclick") && b.getAttribute("onclick").includes(`'${tab}'`));
    if (activeBtn) activeBtn.className = "btn btn-xs btn-pri";
  }
  const qInp = document.getElementById("chat_search_query");
  doChatSearch(cid, qInp ? qInp.value : "");
};

window.doChatSearch = function(cid, query) {
  const c = (S.chats || []).find(x => x.id === cid);
  const box = document.getElementById("chat_search_results");
  if (!c || !box) return;
  const q = (query || "").trim().toLowerCase();
  const tab = window._chatSearchTab || 'all';
  
  if (!q && tab === 'all') {
    box.innerHTML = `<div class="center tiny fnt" style="padding:20px 0">اكتب للبحث في سجل الرسائل والمحتوى المشترك</div>`;
    return;
  }

  const allMsgs = (c.messages || []).filter(m => !m.gone && !m.isDeleted);
  const matches = allMsgs.filter(m => {
    const t = (m.text || "").toLowerCase();
    const sn = (m.senderName || "").toLowerCase();
    const fn = (m.name || "").toLowerCase();
    const atts = m.attachments || [];
    const hasMedia = m.type === 'image' || m.type === 'video' || m.type === 'gif' || atts.some(a => a.type === 'image' || a.type === 'video' || a.type === 'gif');
    const hasFiles = m.type === 'file' || atts.some(a => a.type === 'file');
    const hasLinks = t.includes('http://') || t.includes('https://');

    if (tab === 'text' && (m.type !== 'text' && !t)) return false;
    if (tab === 'media' && !hasMedia) return false;
    if (tab === 'files' && !hasFiles) return false;
    if (tab === 'links' && !hasLinks) return false;

    if (!q) return true;

    const attMatch = atts.some(a => (a.name || "").toLowerCase().includes(q) || (a.type || "").toLowerCase().includes(q));
    return t.includes(q) || sn.includes(q) || fn.includes(q) || attMatch;
  });

  if (!matches.length) {
    box.innerHTML = `<div class="center tiny fnt" style="padding:20px 0">لا توجد نتائج مطابقة ${q ? `لـ "${esc(q)}"` : ''}</div>`;
    return;
  }

  box.innerHTML = matches.map(m => {
    const isMine = isMsgMine(m);
    const dateStr = new Date(m.at || m.createdAt).toLocaleDateString("ar");
    const timeStr = hhmm(m.at || m.createdAt);
    let typeIcon = I("chat","i s");
    if (m.type === 'image' || m.type === 'gif') typeIcon = I("image","i s");
    else if (m.type === 'video') typeIcon = I("video","i s");
    else if (m.type === 'voice') typeIcon = I("mic","i s");
    else if (m.type === 'file') typeIcon = I("file","i s");
    else if (m.type === 'location') typeIcon = "📍";
    else if (m.type === 'contact') typeIcon = "👤";
    else if (m.type === 'poll') typeIcon = "📊";

    return `
      <button class="card2" style="padding:10px;text-align:right;cursor:pointer;display:flex;flex-direction:column;gap:4px" onclick="closeOvl();jumpToMsg('${m.id}')">
        <div class="row" style="justify-content:space-between;width:100%">
          <span class="tiny b row" style="gap:4px;color:var(--accent)">
            ${typeIcon}
            <span>${isMine ? 'أنت' : (m.senderName || 'المستخدم')}</span>
          </span>
          <span class="tiny mono mut">${dateStr} ${timeStr}</span>
        </div>
        <div class="sm fnt" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%">
          ${esc(m.text || m.name || (m.attachments && m.attachments.length ? `${m.attachments.length} مرفقات` : 'رسالة'))}
        </div>
      </button>
    `;
  }).join('');
};


// 13. FULL MESSAGE OPTIONS MENU (SHEETS.msgMenu)
// ============================================================================
SHEETS.msgMenu = (mid) => {
  const m = msgById(mid);
  if (!m) return sheet("خيارات الرسالة", "<div class='tiny fnt'>الرسالة غير موجودة</div>");
  const me = isMsgMine(m);
  const c = chatOfMid(mid);
  const cid = c ? c.id : (S.activeChat || "");

  const RX = ["heart", "face-laugh", "face-wow", "face-sad", "flame", "star"];

  return sheet(
    `خيارات الرسالة`,
    `
    <div class="col" style="gap:8px">
      <!-- Quick Reactions Bar -->
      <div class="row" style="gap:8px;justify-content:center;padding:6px 0 10px;border-bottom:1px solid var(--line)">
        ${RX.map(ic => `
          <button class="iconbtn" style="width:42px;height:42px;background:var(--surface3);border-radius:50%" onclick="toggleReact('${mid}','${ic}');closeOvl()" aria-label="تفاعل ${ic}">
            ${I(ic,"i l")}
          </button>
        `).join("")}
      </div>

      <!-- Action Buttons -->
      <button class="lstrow" onmousedown="event.preventDefault()" ontouchstart="event.preventDefault()" onclick="closeOvl();window.setReplyTo('${mid}')">
        <span style="color:var(--accent)">${I("reply","i s")}</span>
        <span class="g1 b xs" style="text-align:right">رد</span>
      </button>

      ${me && !m.gone ? `
        <button class="lstrow" onclick="closeOvl();S.editMid='${mid}';render();setTimeout(()=>{const i=document.getElementById('minp');if(i){i.value='${esc(m.text||"")}';i.focus();}},100)">
          <span style="color:var(--gold)">${I("edit","i s")}</span>
          <span class="g1 b xs" style="text-align:right">تعديل</span>
        </button>
      ` : ''}

      ${m.text ? `
        <button class="lstrow" onclick="copyMsg('${mid}')">
          <span style="color:var(--muted)">${I("copy","i s")}</span>
          <span class="g1 b xs" style="text-align:right">نسخ النص</span>
        </button>
      ` : ''}

      <button class="lstrow" onclick="closeOvl();openSheet('fwdSheet','${mid}')">
        <span style="color:var(--emerald)">${I("fwd","i s")}</span>
        <span class="g1 b xs" style="text-align:right">إعادة توجيه</span>
      </button>

      <button class="lstrow" onclick="closeOvl();starMsg('${mid}')">
        <span style="color:var(--gold)">${I("star","i s")}</span>
        <span class="g1 b xs" style="text-align:right">${m.star ? 'إلغاء التمييز' : 'تمييز بنجمة'}</span>
      </button>

      <button class="lstrow" onclick="closeOvl();pinMsg('${mid}')">
        <span style="color:var(--cyan)">${I("pin","i s")}</span>
        <span class="g1 b xs" style="text-align:right">${(c&&c.pinnedMsgs||[]).includes(mid) ? 'إلغاء التثبيت' : 'تثبيت في المحادثة'}</span>
      </button>

      <button class="lstrow" onclick="closeOvl();delMsg('${mid}')" style="color:var(--rose)">
        <span>${I("trash","i s")}</span>
        <span class="g1 b xs" style="text-align:right">حذف لدي</span>
      </button>

      ${me ? `
        <button class="lstrow" onclick="closeOvl();delMsgAll('${mid}')" style="color:var(--rose);font-weight:700">
          <span>${I("trash","i s")}</span>
          <span class="g1 b xs" style="text-align:right">حذف للجميع</span>
        </button>
      ` : ''}
    </div>
    `
  );
};

// ============================================================================
// 14. CHAT ROOM MAIN PAGE (PAGES.chatRoom)
// ============================================================================
PAGES.chatRoom = () => {
  const c = (S.chats || []).find(x => x.id === S.params.id);
  if (!c || !c.messages) {
    setNav(false);
    setHdr(backHdr("المحادثة", ""));
    return emptyState("chat", "المحادثة غير موجودة", "");
  }

  const uu = u(c.userId);
  setNav(false);
  S.activeChat = c.id;

  // Vanish mode filter
  if (c.vanish) {
    const cut = now() - c.vanish * 36e5;
    const b4 = (c.messages || []).length;
    c.messages = c.messages.filter(m => !m.at || m.at >= cut || (c.pinnedMsgs || []).includes(m.id));
    if ((c.messages || []).length !== b4) save();
  }

  const blocked = (S.blocked || []).includes(uu.id);
  const pinned = (c.pinnedMsgs || []).length ? msgById(c.pinnedMsgs[(c.pinnedMsgs || []).length - 1]) : null;

  // Custom Header Design (RTL aware, rich user info & presence)
  setHdr(`
    <div style="display:flex;align-items:center;gap:8px;width:100%">
      <button class="iconbtn" onclick="go('chat')" aria-label="رجوع">${I("back")}</button>
      <button class="row g1" style="gap:9px;text-align:right;padding:2px;border-radius:12px;background:transparent;border:none;color:var(--text);cursor:pointer" onclick="go('chatInfo',{id:'${c.id}'})" title="معلومات المحادثة">
        ${av(uu, 38, true)}
        <span class="g1" style="min-width:0;display:flex;flex-direction:column;justify-content:center">
          <span class="row" style="gap:4px;line-height:1.2">
            <span class="b sm" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(uu.name)}</span>
            ${vbadge(uu)}${lvlBadge(uu)}
          </span>
          <span id="chat_hdr_st" class="tiny ${S.typingIn && S.typingIn[c.id] ? '' : 'fnt'}" style="color:${S.typingIn && S.typingIn[c.id] ? 'var(--cyan)' : uu.online ? 'var(--emerald)' : 'var(--faint)'};line-height:1.2;margin-top:2px">
            ${S.typingIn && S.typingIn[c.id] ? "يكتب الآن…" : uu.online ? "متصل الآن 🟢" : "آخر ظهور " + ago(uu.lastSeen || uu.joined)}
          </span>
        </span>
      </button>

      ${(c.pinnedMsgs || []).length ? `
        <button class="iconbtn" style="color:var(--gold)" onclick="jumpToMsg('${c.pinnedMsgs[(c.pinnedMsgs || []).length - 1]}')" aria-label="مثبتة">${I("pin","i s")}</button>
      ` : ""}
      <button class="iconbtn" onclick="openSheet('chatSearch','${c.id}')" aria-label="بحث">${I("search","i s")}</button>
      <button class="iconbtn" onclick="startCall('${c.id}','voice')" aria-label="مكالمة صوتية" style="color:var(--emerald)">${I("phone","i s")}</button>
      <button class="iconbtn" onclick="startCall('${c.id}','video')" aria-label="مكالمة فيديو" style="color:var(--cyan)">${I("video","i s")}</button>
      <button class="iconbtn" onclick="openSheet('chatRoomMenu','${c.id}')" aria-label="خيارات">${I("more","i s")}</button>
    </div>
  `);

  // Message rows
  let rows = [];
  let lastDay = "";
  c.messages.forEach(m => {
    const dl = dayLbl(m.at || m.createdAt);
    if (dl !== lastDay) {
      lastDay = dl;
      const dlId = 'day_' + Array.from(dl).map(char => char.charCodeAt(0)).join('');
      rows.push(`<div class="center" id="${dlId}" style="margin:10px 0 8px"><span class="tiny b" style="background:var(--surface3);border:1px solid var(--line2);border-radius:99px;padding:4px 12px;color:var(--muted)">${dl}</span></div>`);
    }
    const html = (typeof window.msgBubble === "function") ? window.msgBubble(m, uu, c.id) : msgBubble(m, uu, c.id);
    const mHash = (typeof window.getMsgHash === "function") ? window.getMsgHash(m) : ((m.text || "") + (m.st || 2));
    rows.push(html.replace('class="msg ', 'data-hash="' + mHash + '" class="msg '));
  });

  const attachHtml = renderAttachPreviewHTML(c.id);

  return `
    <div style="display:flex;flex-direction:column;height:100%;position:relative">
      <!-- Offline Network State Banner -->
      <div id="chat_net_banner" style="display:${navigator.onLine ? 'none' : 'flex'};align-items:center;justify-content:center;gap:6px;padding:5px 12px;background:rgba(239,68,68,0.15);border-bottom:1px solid rgba(239,68,68,0.25);font-size:11px;color:var(--rose);flex-shrink:0">
        ${I("alert","i s")} <span>لا يوجد اتصال بالإنترنت — وضع غير متصل (سيتم إرسال الرسائل تلقائياً عند عودة الاتصال)</span>
      </div>
      ${pinned ? `
        <div class="row" style="gap:8px;padding:7px 12px;background:linear-gradient(90deg,rgba(245,158,11,.14),transparent);border-bottom:1px solid var(--line);flex-shrink:0">
          <span style="color:var(--gold)">${I("pin","i s")}</span>
          <button class="tiny g1" style="text-align:right;background:none;border:none;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap" onclick="jumpToMsg('${pinned.id}')">
            مثبت: ${esc((pinned.text || "ملصق").slice(0, 60))}
          </button>
          <button class="iconbtn" style="width:26px;height:26px" onclick="pinMsg('${pinned.id}')" aria-label="إلغاء التثبيت">${I("x","i s")}</button>
        </div>
      ` : ""}

      <!-- Main Messages Container -->
      <div class="chatbody no-sb" id="msgs"
           onscroll="const f=document.getElementById('msgfab');if(f)f.style.display=(this.scrollHeight-this.scrollTop-this.clientHeight>240)?'flex':'none'"
           ${c.wallpaperImg ? ` style="background:url('${c.wallpaperImg}') center/cover"` : c.wallpaper ? ` style="background:linear-gradient(180deg,${c.wallpaper[0]},${c.wallpaper[1]})"` : ""}>
        <div class="center tiny fnt chat-start-hdr" style="margin-bottom:6px">— بداية المحادثة · ${new Date(c.lastAt || now()).toLocaleDateString("ar")} —</div>
        ${c.vanish ? `<div class="center tiny fnt" style="color:var(--emerald);margin-bottom:6px">${I("clock","i s")} الرسائل تختفي تلقائياً بعد ${c.vanish === 24 ? "٢٤ ساعة" : "٣ أيام"}</div>` : ""}
        ${rows.join("")}
        <div id="chat_typing_indicator" style="display:${(S.typingIn && S.typingIn[c.id]) ? 'flex' : 'none'};gap:6px;margin-top:4px" class="msg them row">
          ${av(uu, 20)}
          <span class="dot3"><i></i><i></i><i></i></span>
        </div>
      </div>

      <!-- Floating Scroll-To-Bottom FAB -->
      <button id="msgfab" class="iconbtn" style="display:none;position:absolute;bottom:78px;left:14px;z-index:15;width:42px;height:42px;background:var(--surface2);box-shadow:0 6px 20px rgba(0,0,0,.5);border:1px solid var(--line2);color:var(--text)" onclick="const b=document.getElementById('msgs');if(b)b.scrollTo({top:b.scrollHeight,behavior:'smooth'})" aria-label="لأسفل">
        ${I("chevdown","i s")}
      </button>

      ${blocked ? `
        <div class="pad center" style="border-top:1px solid var(--line);flex-shrink:0">
          <div class="tiny fnt" style="color:var(--rose)">${I("ban","i s")} هذا المستخدم محظور — لا يمكنك مراسلته</div>
          <button class="btn btn-sec btn-sm" style="margin-top:8px" onclick="unblockUser('${uu.id}')">إلغاء الحظر للمراسلة</button>
        </div>
      ` : `
        <!-- Edit Bar -->
        ${S.editMid ? `
          <div id="edit_bar" class="row" style="gap:8px;padding:6px 12px;background:var(--surface2);border-top:1px solid var(--line);flex-shrink:0">
            <span style="color:var(--gold)">${I("edit","i s")}</span>
            <span class="tiny g1" style="text-align:right">تعديل رسالتك: ${esc(((msgById(S.editMid)||{}).text||"").slice(0,50))}</span>
            <button class="iconbtn" style="width:26px;height:26px" onclick="S.editMid=null;const i=document.getElementById('minp');if(i)i.value='';const eb=document.getElementById('edit_bar');if(eb)eb.remove();">${I("x","i s")}</button>
          </div>
        ` : ""}

        <!-- Reply Bar -->
        ${S.replyTo ? `
          <div id="reply_bar" class="row" style="gap:8px;padding:6px 12px;background:var(--surface2);border-top:1px solid var(--line);flex-shrink:0">
            <span style="color:var(--accent)">${I("reply","i s")}</span>
            <span class="tiny g1" style="text-align:right">رد على: ${esc((((msgById(S.replyTo)||{}).text)||"ملصق").slice(0,50))}</span>
            <button class="iconbtn" style="width:26px;height:26px" onclick="S.replyTo=null;const rb=document.getElementById('reply_bar');if(rb)rb.remove();">${I("x","i s")}</button>
          </div>
        ` : ""}

        <!-- Selection Mode Bar -->
        ${S.selMode ? `
          <div class="row" style="gap:6px;padding:7px 10px;background:var(--surface2);border-top:1px solid var(--line);flex-shrink:0">
            <span class="tiny b g1">${(S.selIds||[]).length} رسالة محددة</span>
            <button class="btn btn-sec btn-xs" onclick="openSheet('fwdSheetSel')">${I("fwd","i s")} توجيه</button>
            <button class="btn btn-sec btn-xs" onclick="starSel()">${I("star","i s")} تمييز</button>
            <button class="btn btn-danger btn-xs" onclick="delSel()">${I("trash","i s")} حذف</button>
            <button class="btn btn-ghost btn-xs" onclick="S.selMode=false;S.selIds=[];render()">خروج</button>
          </div>
        ` : ""}

        <!-- Attachments Preview Area -->
        <div id="composer_attach_area">${attachHtml}</div>

        <!-- Real Voice Recording Area -->
        <div id="voice_record_area" style="display:none;padding:10px 14px;background:var(--surface);border-top:1px solid var(--line);align-items:center;gap:10px;flex-shrink:0;user-select:none">
          <span class="pulse-red" style="width:10px;height:10px;border-radius:50%;background:var(--rose);flex-shrink:0"></span>
          <span class="mono b" id="voice_timer" style="color:var(--rose);flex-shrink:0">0:00</span>
          <span id="voice_swipe_hint" style="color:var(--muted);font-size:10px;user-select:none;transition:transform .1s;flex-shrink:0">⟵ اسحب للإلغاء</span>
          <div class="g1" style="display:flex;align-items:center;height:22px;gap:2px;overflow:hidden" id="voice_waves"></div>
          <button class="iconbtn" id="voice_pause_btn" onclick="togglePauseVoice()" style="color:var(--muted)" title="إيقاف مؤقت / استئناف">${I("pause","i s")}</button>
          <button class="iconbtn" id="voice_preview_btn" onclick="stopAndPreviewVoice('${c.id}')" style="color:var(--cyan)" title="معاينة">${I("eye","i s")}</button>
          <button class="iconbtn" onclick="cancelVoice()" style="color:var(--rose)" title="إلغاء">${I("trash","i s")}</button>
          <button class="iconbtn" onclick="finishVoice('${c.id}')" style="background:var(--emerald);color:#fff;border-radius:50%;box-shadow:0 4px 12px rgba(16,185,129,0.3)" title="إرسال">${I("send","i s")}</button>
        </div>
        <!-- Voice Preview Before Send Area -->
        <div id="voice_preview_area" style="display:none;padding:10px 14px;background:var(--surface);border-top:1px solid var(--line);align-items:center;gap:10px;flex-shrink:0"></div>

        <!-- Main Composer -->
        <div class="composer" id="main_composer">
          <button class="iconbtn" onclick="openSheet('attachSheet')" onpointerdown="event.preventDefault()" onmousedown="event.preventDefault()" aria-label="إرفاق" style="border-radius:50%;color:var(--emerald);background:rgba(16,185,129,0.1);border-color:rgba(16,185,129,0.2)">
            ${I("plus")}
          </button>
          <textarea id="minp" rows="1" placeholder="${S.editMid ? 'اكتب التعديل...' : 'اكتب رسالة...'}"
                    oninput="this.style.height='auto';this.style.height=Math.min(96,this.scrollHeight)+'px';if(window.DraftsManager)window.DraftsManager.saveChatDraft('${c.id}',this.value);else{S.chatDrafts=S.chatDrafts||{};S.chatDrafts['${c.id}']=this.value;saveDebounced();}notifyTyping('${c.id}');window.updateComposerActionBtn('${c.id}')"
                    onkeyup="window.updateComposerActionBtn('${c.id}')"
                    onchange="if(window.DraftsManager)window.DraftsManager.saveChatDraft('${c.id}',this.value);window.updateComposerActionBtn('${c.id}')"
                    onpaste="setTimeout(()=>window.updateComposerActionBtn('${c.id}'),10)"
                    oncut="setTimeout(()=>window.updateComposerActionBtn('${c.id}'),10)"
                    onblur="if(window.DraftsManager)window.DraftsManager.saveChatDraft('${c.id}',this.value);window.updateComposerActionBtn('${c.id}')"
                    onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();window.handleComposerActionBtn('${c.id}')}">${esc((S.chatDrafts||{})[c.id]||"")}</textarea>
          <button class="iconbtn" onclick="openSheet('emojiSheet', '${c.id}')" onpointerdown="event.preventDefault()" onmousedown="event.preventDefault()" aria-label="ملصقات و GIF" title="ملصقات و GIF وإيموجي" style="border-radius:50%;color:var(--purple);background:rgba(139,92,246,0.12);border-color:rgba(139,92,246,0.25)">
            ${I("sparkles","i s")}
          </button>
          ${(() => {
            const draftVal = ((S.chatDrafts || {})[c.id] || "").trim();
            const hasAtt = (window.ATTACH_CACHE && window.ATTACH_CACHE[c.id] && window.ATTACH_CACHE[c.id].length > 0);
            const isSend = draftVal.length > 0 || hasAtt || !!S.editMid;
            return `
              <button class="iconbtn" id="chat_send_btn" data-cid="${c.id}" type="button"
                      onpointerdown="event.preventDefault()"
                      onmousedown="event.preventDefault()"
                      style="${isSend ? 'background:linear-gradient(135deg, #00A3FF, #8B5CF6);color:#ffffff;border:none;box-shadow:0 4px 14px rgba(0, 163, 255, 0.4);' : 'background:rgba(0,163,255,0.15);color:var(--accent);border:1px solid rgba(0,163,255,0.3);box-shadow:none;'}border-radius:50%;cursor:pointer;touch-action:manipulation;-webkit-tap-highlight-color:transparent;user-select:none;transition:all 0.2s ease"
                      onclick="window.handleComposerActionBtn('${c.id}')"
                      aria-label="${isSend ? 'إرسال' : 'تسجيل صوتي'}"
                      title="${isSend ? 'إرسال الرسالة' : 'تسجيل صوتي (اضغط للتسجيل)'}">
                ${isSend ? I("send","i s") : I("mic","i s")}
              </button>
            `;
          })()}
        </div>
      `}
    </div>
  `;
};

// ============================================================================
// Tabbed Shared Media Sheet
window._chatMediaTab = 'media';
SHEETS.chatMedia = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid) || (S.chats && S.chats[0]);
  if (!c) return sheet("الوسائط المشتركة", "<div class='tiny fnt'>المحادثة غير موجودة</div>");

  const allMsgs = (c.messages || []).filter(m => !m.gone && !m.isDeleted);
  const mediaItems = [];
  const fileItems = [];
  const voiceItems = [];
  const linkItems = [];

  allMsgs.forEach(m => {
    if (m.attachments && m.attachments.length) {
      m.attachments.forEach(a => {
        if (a.type === 'image' || a.type === 'video' || a.type === 'gif') {
          mediaItems.push({ type: a.type, src: a.src, name: a.name || 'وسائط', mid: m.id, at: m.at || m.createdAt });
        } else if (a.type === 'file') {
          fileItems.push({ type: 'file', src: a.src, name: a.name || 'ملف', size: a.size || 0, mid: m.id, at: m.at || m.createdAt });
        }
      });
    }
    if (m.type === 'image' || m.type === 'video' || m.type === 'gif') {
      if (m.src) mediaItems.push({ type: m.type, src: m.src, name: m.text || 'وسائط', mid: m.id, at: m.at || m.createdAt });
    } else if (m.type === 'file') {
      fileItems.push({ type: 'file', src: m.src, name: m.name || m.text || 'ملف', size: m.size || 0, mid: m.id, at: m.at || m.createdAt });
    } else if (m.type === 'voice') {
      voiceItems.push({ type: 'voice', src: m.src, dur: m.dur || 12, mid: m.id, at: m.at || m.createdAt });
    }
    if (m.text) {
      const urls = m.text.match(/(https?:\/\/[^\s<]+)/g);
      if (urls) {
        urls.forEach(uStr => {
          linkItems.push({ url: uStr, mid: m.id, at: m.at || m.createdAt });
        });
      }
    }
  });

  const tab = window._chatMediaTab || 'media';

  return sheet(
    I("image","i s") + " الوسائط والمحتوى المشترك",
    `
    <div class="col" style="gap:10px">
      <div class="row" style="gap:6px;overflow-x:auto;padding-bottom:2px" class="no-sb" id="chat_media_tabs">
        <button class="btn btn-xs ${tab==='media'?'btn-pri':'btn-sec'}" onclick="setChatMediaTab('${cid}','media')">الصور والفيديو (${mediaItems.length})</button>
        <button class="btn btn-xs ${tab==='files'?'btn-pri':'btn-sec'}" onclick="setChatMediaTab('${cid}','files')">الملفات (${fileItems.length})</button>
        <button class="btn btn-xs ${tab==='voice'?'btn-pri':'btn-sec'}" onclick="setChatMediaTab('${cid}','voice')">الصوتيات (${voiceItems.length})</button>
        <button class="btn btn-xs ${tab==='links'?'btn-pri':'btn-sec'}" onclick="setChatMediaTab('${cid}','links')">الروابط (${linkItems.length})</button>
      </div>
      <div id="chat_media_content" style="max-height:360px;overflow-y:auto" class="no-sb">
        ${renderChatMediaContent(cid, tab, mediaItems, fileItems, voiceItems, linkItems)}
      </div>
    </div>
    `
  );
};

window.setChatMediaTab = function(cid, tab) {
  window._chatMediaTab = tab;
  openSheet('chatMedia', cid);
};

function renderChatMediaContent(cid, tab, media, files, voice, links) {
  if (tab === 'media') {
    if (!media.length) return `<div class="center tiny fnt" style="padding:24px 0">لا توجد صور أو مقاطع فيديو مشتركة</div>`;
    return `
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px">
        ${media.map(m => `
          <div style="position:relative;aspect-ratio:1;border-radius:8px;overflow:hidden;background:var(--surface3);cursor:pointer;border:1px solid var(--line2)" onclick="closeOvl();openImageViewer('${m.src}')">
            ${m.type === 'video' ? `
              <video src="${m.src}" style="width:100%;height:100%;object-fit:cover"></video>
              <div style="position:absolute;inset:0;background:rgba(0,0,0,0.35);display:flex;align-items:center;justify-content:center;color:#fff">${I("play","i s")}</div>
            ` : `
              <img src="${m.src}" style="width:100%;height:100%;object-fit:cover" alt="">
            `}
          </div>
        `).join('')}
      </div>
    `;
  }
  if (tab === 'files') {
    if (!files.length) return `<div class="center tiny fnt" style="padding:24px 0">لا توجد ملفات مشتركة</div>`;
    return `
      <div class="col" style="gap:6px">
        ${files.map(f => `
          <div class="card2 row" style="padding:8px 10px;justify-content:space-between">
            <div class="row" style="gap:8px;min-width:0">
              <span style="color:var(--accent)">${I("file","i s")}</span>
              <div class="col" style="min-width:0">
                <span class="sm b" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(f.name)}</span>
                <span class="tiny mut">${(f.size/1024).toFixed(1)} KB</span>
              </div>
            </div>
            <div class="row" style="gap:4px">
              ${f.src ? `<a href="${f.src}" download="${esc(f.name)}" class="iconbtn" style="width:28px;height:28px" title="تحميل">${I("download","i s")}</a>` : ''}
              <button class="iconbtn" style="width:28px;height:28px" onclick="closeOvl();jumpToMsg('${f.mid}')" title="الانتقال للرسالة">${I("fwd","i s")}</button>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  }
  if (tab === 'voice') {
    if (!voice.length) return `<div class="center tiny fnt" style="padding:24px 0">لا توجد تسجيلات صوتية مشتركة</div>`;
    return `
      <div class="col" style="gap:6px">
        ${voice.map(v => `
          <div class="card2 row" style="padding:8px 10px;justify-content:space-between">
            <div class="row" style="gap:8px">
              <span style="color:var(--cyan)">${I("mic","i s")}</span>
              <span class="sm b">رسالة صوتية (${v.dur} ثانية)</span>
            </div>
            <button class="btn btn-sec btn-xs" onclick="closeOvl();jumpToMsg('${v.mid}')">الانتقال للرسالة</button>
          </div>
        `).join('')}
      </div>
    `;
  }
  if (tab === 'links') {
    if (!links.length) return `<div class="center tiny fnt" style="padding:24px 0">لا توجد روابط مشتركة</div>`;
    return `
      <div class="col" style="gap:6px">
        ${links.map(l => `
          <div class="card2 row" style="padding:8px 10px;justify-content:space-between">
            <a href="${l.url}" target="_blank" rel="noopener" class="sm b" style="color:var(--cyan);text-decoration:underline;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:70%">${esc(l.url)}</a>
            <button class="btn btn-ghost btn-xs" onclick="closeOvl();jumpToMsg('${l.mid}')">الرسالة</button>
          </div>
        `).join('')}
      </div>
    `;
  }
  return "";
}


// 15. CHAT ROOM MENU EXTENSION (Include Scheduled Messages)
// ============================================================================
const _origChatRoomMenu = SHEETS.chatRoomMenu;
SHEETS.chatRoomMenu = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid) || (S.chats && S.chats[0]);
  if (!c) return sheet("القائمة", "<div class='tiny fnt'>لا محادثات بعد</div>");
  const uu = u(c.userId);
  const schedCount = (c.messages || []).filter(m => m.isScheduled && !m.gone).length;

  return sheet(
    I("more","i s") + " خيارات المحادثة",
    `
    <div class="col" style="gap:4px">
      <button class="lstrow" onclick="closeOvl();go('chatInfo',{id:'${cid}'})">
        <span style="color:var(--cyan)">${I("info","i s")}</span>
        <span class="g1 b xs" style="text-align:right">معلومات المحادثة</span>
      </button>
      <button class="lstrow" onclick="closeOvl();openProfile('${uu.id}')">
        ${av(uu, 36)}
        <span class="g1 b xs" style="text-align:right">الملف الشخصي</span>
      </button>
      <button class="lstrow" onclick="startCall('${cid}','voice')">
        <span style="color:var(--emerald)">${I("phone","i s")}</span>
        <span class="g1 b xs" style="text-align:right">مكالمة صوتية</span>
      </button>
      <button class="lstrow" onclick="startCall('${cid}','video')">
        <span style="color:var(--cyan)">${I("video","i s")}</span>
        <span class="g1 b xs" style="text-align:right">مكالمة فيديو</span>
      </button>
      <button class="lstrow" onclick="closeOvl();openSheet('chatSearch','${cid}')">
        <span style="color:var(--accent)">${I("search","i s")}</span>
        <span class="g1 b xs" style="text-align:right">بحث في الرسائل</span>
      </button>
      <button class="lstrow" onclick="closeOvl();openSheet('scheduledMsgs','${cid}')">
        <span style="color:var(--gold)">⏱️</span>
        <span class="g1 b xs" style="text-align:right">الرسائل المجدولة (${schedCount})</span>
      </button>
      <button class="lstrow" onclick="closeOvl();openSheet('chatMedia','${cid}')">
        <span style="color:var(--accent)">${I("image","i s")}</span>
        <span class="g1 b xs" style="text-align:right">الوسائط المشتركة</span>
      </button>
      <button class="lstrow" onclick="closeOvl();openSheet('starredMsgs','${cid}')">
        <span style="color:var(--gold)">${I("star","i s")}</span>
        <span class="g1 b xs" style="text-align:right">الرسائل المميزة بنجمة</span>
      </button>
      <button class="lstrow" onclick="closeOvl();openSheet('chatWallpaper','${cid}')">
        <span style="color:var(--purple)">${I("palette","i s")}</span>
        <span class="g1 b xs" style="text-align:right">خلفية المحادثة والمظهر</span>
      </button>
      <button class="lstrow" onclick="closeOvl();openSheet('chatMenu','${cid}')">
        <span style="color:var(--muted)">${I("settings","i s")}</span>
        <span class="g1 b xs" style="text-align:right">إعدادات المحادثة</span>
      </button>
      <button class="lstrow" onclick="clearChatMsgs('${cid}')" style="color:var(--rose)">
        <span>${I("trash","i s")}</span>
        <span class="g1 b xs" style="text-align:right">مسح سجل الرسائل</span>
      </button>
      <button class="lstrow" onclick="closeOvl();go('report',{id:'${uu.id}',type:'user'})" style="color:var(--rose)">
        <span>${I("alert","i s")}</span>
        <span class="g1 b xs" style="text-align:right">إبلاغ عن المستخدم</span>
      </button>
      <button class="lstrow" onclick="blockUser('${uu.id}')" style="color:var(--rose)">
        <span>${I("ban","i s")}</span>
        <span class="g1 b xs" style="text-align:right">حظر المستخدم</span>
      </button>
    </div>
    `
  );
};

// ============================================================================
// 16. CHAT INFO SCREEN (ChatInfoScreen / PAGES.chatInfo)
// ============================================================================

// Material 3 Confirmation Dialog Engine
window.openConfirmDialog = function({ title, message, confirmText, cancelText, isDanger, icon, onConfirm }) {
  const ovl = document.getElementById("ovl");
  if (!ovl) return;
  const iconHtml = icon ? `
    <div style="width:52px;height:52px;border-radius:50%;background:${isDanger ? 'rgba(244,63,94,0.15)' : 'rgba(0,240,255,0.15)'};color:${isDanger ? 'var(--rose)' : 'var(--accent)'};display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:24px">
      ${icon}
    </div>
  ` : '';
  
  ovl.innerHTML = `
    <div class="ov glass" onclick="if(event.target===this)closeOvl()">
      <div class="card2" onclick="event.stopPropagation()" style="width:90%;max-width:390px;padding:24px 20px;border-radius:24px;box-shadow:0 24px 48px rgba(0,0,0,0.6);text-align:center;border:1px solid var(--line2);animation:mIn .2s cubic-bezier(0.16,1,0.3,1)">
        ${iconHtml}
        <h3 class="b" style="font-size:17px;margin-bottom:8px;color:var(--text)">${title}</h3>
        <p class="sm mut" style="line-height:1.5;margin-bottom:22px">${message}</p>
        <div class="row" style="gap:10px;justify-content:center">
          <button class="btn btn-sec g1" onclick="closeOvl()">${cancelText || "إلغاء"}</button>
          <button class="btn ${isDanger ? 'btn-danger' : 'btn-pri'} g1" id="confirm_dialog_act_btn">${confirmText || "تأكيد"}</button>
        </div>
      </div>
    </div>
  `;
  const actBtn = document.getElementById("confirm_dialog_act_btn");
  if (actBtn) {
    actBtn.onclick = function() {
      closeOvl();
      if (typeof onConfirm === "function") onConfirm();
    };
  }
};

// Reusable Material 3 Toggle Switch Renderer
window.renderM3Switch = function(checked, onchangeAttr, id) {
  const switchId = id || ('sw_' + uid());
  return `
    <label class="m3-switch" style="position:relative;display:inline-block;width:46px;height:26px;flex-shrink:0;cursor:pointer" onclick="event.stopPropagation()">
      <input type="checkbox" id="${switchId}" ${checked ? 'checked' : ''} onchange="${onchangeAttr}" style="opacity:0;width:0;height:0;position:absolute">
      <span style="position:absolute;inset:0;background:${checked ? 'var(--cyan)' : 'var(--surface3)'};border:1.5px solid ${checked ? 'var(--cyan)' : 'var(--line2)'};border-radius:99px;transition:background .2s, border-color .2s">
        <span style="position:absolute;height:20px;width:20px;${checked ? 'left:22px' : 'left:2px'};bottom:1.5px;background:#fff;border-radius:50%;transition:left .2s;box-shadow:0 2px 4px rgba(0,0,0,0.35)"></span>
      </span>
    </label>
  `;
};

// Toggle Contact State
window.toggleContact = function(userId) {
  S.contacts = S.contacts || [];
  const idx = S.contacts.indexOf(userId);
  const targetUser = u(userId);
  if (idx > -1) {
    S.contacts.splice(idx, 1);
    toast(`تمت إزالة ${targetUser.name} من جهات الاتصال`, "info");
  } else {
    S.contacts.push(userId);
    toast(`تمت إضافة ${targetUser.name} إلى جهات الاتصال ✓`, "ok");
  }
  save();
  render();
};

// Share User Profile Link
window.shareProfile = async function(userId) {
  const targetUser = u(userId);
  const shareData = {
    title: targetUser.name + " - أنمي بلاك",
    text: "الملف الشخصي لـ " + targetUser.name + " على أنمي بلاك",
    url: window.location.origin + window.location.pathname + "#profile_" + targetUser.id
  };
  if (navigator.share) {
    try {
      await navigator.share(shareData);
      toast("تمت مشاركة الملف الشخصي", "ok");
      return;
    } catch(e){}
  }
  try {
    await navigator.clipboard.writeText(shareData.url);
    toast("تم نسخ رابط الملف الشخصي إلى الحافظة 📋", "ok");
  } catch(e) {
    toast("الرابط: " + shareData.url, "info");
  }
};

// Mute Notifications Duration Management
window.setChatMuteDuration = function(cid, hours) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  if (hours === 0) {
    c.muted = true;
    c.muteUntil = null;
    toast("تم كتم إشعارات المحادثة دائماً 🔕", "info");
  } else {
    c.muted = true;
    c.muteUntil = Date.now() + (hours * 3600000);
    toast(`تم كتم الإشعارات لمدة ${hours === 8 ? '8 ساعات' : 'أسبوع'} 🔕`, "info");
  }
  save();
  closeOvl();
  render();
};

window.unmuteChatNow = function(cid) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  c.muted = false;
  c.muteUntil = null;
  save();
  closeOvl();
  render();
  toast("تم إلغاء كتم الإشعارات 🔔", "ok");
};

SHEETS.muteDurationSheet = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return sheet("كتم الإشعارات", "المحادثة غير موجودة");
  return sheet(
    I("mute","i s") + " كتم إشعارات المحادثة",
    `
    <div class="col" style="gap:8px">
      <div class="tiny mut" style="margin-bottom:4px">حدد مدة كتم التنبيهات لهذه المحادثة:</div>
      <button class="lstrow" onclick="setChatMuteDuration('${cid}', 8)">
        <span style="color:var(--accent)">${I("clock","i s")}</span>
        <span class="g1 b sm" style="text-align:right">كتم لمدة 8 ساعات</span>
      </button>
      <button class="lstrow" onclick="setChatMuteDuration('${cid}', 168)">
        <span style="color:var(--accent)">${I("calendar","i s")}</span>
        <span class="g1 b sm" style="text-align:right">كتم لمدة أسبوع (7 أيام)</span>
      </button>
      <button class="lstrow" onclick="setChatMuteDuration('${cid}', 0)">
        <span style="color:var(--rose)">${I("mute","i s")}</span>
        <span class="g1 b sm" style="text-align:right">كتم دائماً حتى إعادة التشغيل</span>
      </button>
      ${c.muted ? `
        <button class="lstrow" onclick="unmuteChatNow('${cid}')" style="color:var(--emerald)">
          <span>${I("volume","i s")}</span>
          <span class="g1 b sm" style="text-align:right">إلغاء الكتم واستقبال التنبيهات</span>
        </button>
      ` : ''}
    </div>
    `
  );
};

// Custom Notification Tone Sheet
window.setChatNotifTone = function(cid, toneId, toneName) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  c.notifTone = toneId;
  c.notifToneName = toneName;
  save();
  closeOvl();
  render();
  toast(`تم تعيين نغمة المحادثة: ${toneName} 🎵`, "ok");
};

SHEETS.chatNotifToneSheet = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return sheet("نغمات المحادثة", "المحادثة غير موجودة");
  const currentTone = c.notifTone || "default";
  const tones = [
    { id: "default", name: "الافتراضية (أنمي بلاك)", desc: "النغمة العامة للتطبيق" },
    { id: "bell", name: "رنة جرس الأنمي (Anime Bell)", desc: "نغمة هادئة وواضحة" },
    { id: "cyber", name: "سايبر بييب (Cyber Chime)", desc: "نغمة رقمية عصرية" },
    { id: "sakura", name: "نسيم الساكورا (Sakura Flute)", desc: "نغمة شرقية لطيفة" },
    { id: "shuriken", name: "حفيف الشوريكين (Ninja Blade)", desc: "نغمة سريعة وحاسمة" },
    { id: "silent", name: "صامت تماماً", desc: "اهتزاز بدون صوت" }
  ];
  return sheet(
    I("bell","i s") + " تخصيص إشعارات المحادثة",
    `
    <div class="col" style="gap:6px">
      <div class="tiny mut" style="margin-bottom:4px">اختر نغمة التنبيه المخصصة لهذه المحادثة:</div>
      ${tones.map(t => `
        <button class="lstrow ${currentTone === t.id ? 'active' : ''}" onclick="setChatNotifTone('${cid}', '${t.id}', '${t.name}')">
          <span style="color:${currentTone === t.id ? 'var(--accent)' : 'var(--muted)'}">${currentTone === t.id ? I("check","i s") : I("music","i s")}</span>
          <div class="col g1" style="text-align:right">
            <span class="sm b" style="color:${currentTone === t.id ? 'var(--accent)' : 'var(--text)'}">${t.name}</span>
            <span class="tiny mut">${t.desc}</span>
          </div>
        </button>
      `).join('')}
    </div>
    `
  );
};

// Chat Theme Color Sheet
window.setChatThemeColor = function(cid, colorKey) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  c.themeColor = colorKey;
  save();
  closeOvl();
  render();
  toast("تم تغيير لون فقاعات المحادثة ✨", "ok");
};

SHEETS.chatThemeColorSheet = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return sheet("لون المحادثة", "المحادثة غير موجودة");
  const colors = [
    { id: "cyan", name: "سماوي نيون (الافتراضي)", val: "#00F0FF" },
    { id: "purple", name: "أرجواني سايبربانك", val: "#8B5CF6" },
    { id: "emerald", name: "أخضر زمردي", val: "#10B981" },
    { id: "rose", name: "وردي الساكورا", val: "#FB7185" },
    { id: "amber", name: "ذهبي دافئ", val: "#F59E0B" },
    { id: "blue", name: "أزرق ملكي", val: "#3B82F6" },
    { id: "crimson", name: "قرمزي حماسي", val: "#E11D48" }
  ];
  const curColor = c.themeColor || "cyan";
  return sheet(
    I("palette","i s") + " تخصيص لون المحادثة",
    `
    <div class="col" style="gap:10px">
      <div class="tiny mut">حدد لون فقاعاتك المميز في هذه المحادثة:</div>
      <div class="grid3" style="gap:8px">
        ${colors.map(col => `
          <button class="card2 center col" style="padding:12px 8px;gap:6px;cursor:pointer;border:2px solid ${curColor === col.id ? col.val : 'var(--line2)'};border-radius:14px" onclick="setChatThemeColor('${cid}','${col.id}')">
            <div style="width:28px;height:28px;border-radius:50%;background:${col.val};box-shadow:0 2px 8px ${col.val}66"></div>
            <span class="tiny b" style="white-space:nowrap">${col.name.split(' ')[0]}</span>
          </button>
        `).join('')}
      </div>
    </div>
    `
  );
};

// Disappearing Messages / Vanish Mode
window.setChatVanishMode = function(cid, hours) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return;
  c.vanish = hours;
  save();
  closeOvl();
  render();
  if (hours > 0) {
    toast(`تم تفعيل الرسائل المختفية (${hours >= 24 ? (hours/24) + ' يوم' : hours + ' ساعة'}) ⏱️`, "info");
  } else {
    toast("تم إيقاف الرسائل المختفية", "ok");
  }
};

SHEETS.vanishModeSheet = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return sheet("الرسائل المختفية", "المحادثة غير موجودة");
  const curVanish = c.vanish || 0;
  const options = [
    { hours: 0, label: "إيقاف الرسائل المختفية", desc: "تبقى الرسائل في المحادثة حتى يتم حذفها يدوياً" },
    { hours: 24, label: "24 ساعة (يوم واحد)", desc: "تختفي الرسائل تلقائياً بعد 24 ساعة من إرسالها" },
    { hours: 168, label: "7 أيام (أسبوع)", desc: "تختفي الرسائل تلقائياً بعد أسبوع واحد" },
    { hours: 2160, label: "90 يوماً (3 أشهر)", desc: "تختفي الرسائل تلقائياً بعد 90 يوماً" }
  ];
  return sheet(
    I("clock","i s") + " الرسائل المختفية (Vanish Mode)",
    `
    <div class="col" style="gap:8px">
      <div class="tiny mut" style="line-height:1.4">عند تفعيل ميزة الرسائل المختفية، ستُحذف جميع الرسائل الجديدة في هذه المحادثة تلقائياً بعد انقضاء الوقت المحدد، باستثناء الرسائل المثبتة.</div>
      ${options.map(opt => `
        <button class="lstrow ${curVanish === opt.hours ? 'active' : ''}" onclick="setChatVanishMode('${cid}', ${opt.hours})">
          <span style="color:${curVanish === opt.hours ? 'var(--accent)' : 'var(--muted)'}">${curVanish === opt.hours ? I("check","i s") : I("clock","i s")}</span>
          <div class="col g1" style="text-align:right">
            <span class="sm b" style="color:${curVanish === opt.hours ? 'var(--accent)' : 'var(--text)'}">${opt.label}</span>
            <span class="tiny mut">${opt.desc}</span>
          </div>
        </button>
      `).join('')}
    </div>
    `
  );
};

// Encryption & Security Info Sheet
SHEETS.chatSecurityInfoSheet = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  const uu = c ? u(c.userId) : null;
  const myId = (S.me && S.me.id) || 'me';
  const otherId = uu ? uu.id : 'user';
  const seed = myId + '_' + otherId;
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = ((hash << 5) - hash) + seed.charCodeAt(i);
    hash |= 0;
  }
  const codeBlocks = [
    Math.abs(hash % 90000 + 10000),
    Math.abs((hash * 3) % 90000 + 10000),
    Math.abs((hash * 7) % 90000 + 10000),
    Math.abs((hash * 13) % 90000 + 10000)
  ];
  return sheet(
    I("shield","i s") + " التشفير التام ومعلومات الأمان",
    `
    <div class="col" style="gap:14px;text-align:center">
      <div class="center" style="width:64px;height:64px;border-radius:50%;background:rgba(16,185,129,0.15);color:var(--emerald);margin:0 auto">
        ${I("lock","i l")}
      </div>
      <div class="col" style="gap:4px">
        <h3 class="b" style="font-size:16px;color:var(--text)">المحادثة مشفرة تماماً</h3>
        <p class="sm mut" style="line-height:1.5">الرسائل والمكالمات والوسائط المشتركة في هذه المحادثة مشفرة ومحمية من الطرفين (End-to-End Encryption). لا يمكن لأي طرف خارجي قراءتها أو الاستماع إليها.</p>
      </div>
      <div class="card2" style="padding:14px;border-radius:14px;background:var(--surface3)">
        <div class="tiny b mut" style="margin-bottom:8px">رمز أمان الجلسة والتحقق (Safety Fingerprint)</div>
        <div class="mono b" style="font-size:16px;letter-spacing:2px;color:var(--accent);direction:ltr">${codeBlocks.join('  ')}</div>
      </div>
      <button class="btn btn-sec btn-sm" onclick="toast('تم التحقق من بصمة التشفير بنجاح ✓','ok')">
        ${I("check","i s")} تأكيد مطابقة الرمز
      </button>
    </div>
    `
  );
};

// Pinned Messages Sheet
SHEETS.pinnedMsgsSheet = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return sheet("الرسائل المثبتة", "المحادثة غير موجودة");
  const pids = c.pinnedMsgs || [];
  const msgs = pids.map(id => (c.messages || []).find(m => m.id === id)).filter(Boolean);
  return sheet(
    I("pin","i s") + ` الرسائل المثبتة (${msgs.length})`,
    `
    <div class="col" style="gap:8px;max-height:360px;overflow-y:auto" class="no-sb">
      ${!msgs.length ? `
        <div class="center tiny mut" style="padding:30px 0">لا توجد رسائل مثبتة في هذه المحادثة</div>
      ` : msgs.map(m => `
        <div class="card2 row" style="padding:10px 12px;justify-content:space-between;align-items:flex-start">
          <div class="col g1" style="min-width:0;cursor:pointer" onclick="closeOvl();jumpToMsg('${m.id}')">
            <span class="tiny b" style="color:var(--accent)">${isMsgMine(m) ? 'أنت' : (m.senderName || 'المستخدم')}</span>
            <span class="sm fnt" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block">${esc(m.text || m.name || 'مرفق')}</span>
            <span class="tiny mono mut">${hhmm(m.at || m.createdAt)}</span>
          </div>
          <button class="iconbtn" style="width:28px;height:28px;color:var(--rose)" onclick="pinMsg('${m.id}')" title="إلغاء التثبيت">
            ${I("x","i s")}
          </button>
        </div>
      `).join('')}
    </div>
    `
  );
};

// Export Chat Transcript File
window.exportChatTranscript = function(cid) {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c || !c.messages || !c.messages.length) {
    toast("لا توجد رسائل لتصديرها", "info");
    return;
  }
  const uu = u(c.userId);
  let content = `=========================================\n`;
  content += `سجل محادثة أنمي بلاك (Anime Black)\n`;
  content += `بين: ${S.me.name || 'أنا'} و ${uu.name || 'المستخدم'}\n`;
  content += `تاريخ التصدير: ${new Date().toLocaleString('ar')}\n`;
  content += `عدد الرسائل: ${c.messages.length}\n`;
  content += `=========================================\n\n`;

  c.messages.forEach(m => {
    if (m.gone || m.isDeleted) return;
    const time = new Date(m.at || m.createdAt).toLocaleString('ar');
    const sender = isMsgMine(m) ? (S.me.name || 'أنا') : (m.senderName || uu.name || 'المستخدم');
    let text = m.text || '';
    if (m.type === 'image') text = `[صورة: ${m.text || 'صورة'}]`;
    else if (m.type === 'video') text = `[فيديو: ${m.text || 'فيديو'}]`;
    else if (m.type === 'voice') text = `[رسالة صوتية (${m.dur || ''} ثانية)]`;
    else if (m.type === 'file') text = `[ملف: ${m.name || 'مستند'}]`;
    else if (m.type === 'gif') text = `[ملصق متحرك GIF]`;
    else if (m.type === 'sticker') text = `[ملصق: ${m.name || ''}]`;
    if (m.attachments && m.attachments.length) {
      text += ` + [${m.attachments.length} مرفقات]`;
    }
    content += `[${time}] ${sender}: ${text}\n`;
  });

  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `anime_black_chat_${uu.username || cid}_${Date.now()}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  toast("تم تصدير سجل المحادثة بنجاح 📄", "ok");
};

// Clear Local Cached Media
window.clearChatMediaCache = function(cid) {
  openConfirmDialog({
    title: "مسح الوسائط المؤقتة",
    message: "سيتم تفريغ الذاكرة المؤقتة للصور والملفات المخزنة لهذه المحادثة على جهازك لتوفير المساحة، مع الإبقاء على سجل الرسائل.",
    confirmText: "مسح الذاكرة المؤقتة",
    cancelText: "إلغاء",
    icon: I("refresh", "i l"),
    onConfirm: () => {
      if (window.ATTACH_CACHE && window.ATTACH_CACHE[cid]) {
        window.ATTACH_CACHE[cid] = [];
      }
      toast("تم تفريغ الذاكرة المؤقتة للوسائط بنجاح ✓", "ok");
    }
  });
};

// Clear Chat Messages with Confirmation
window.confirmClearChatMsgs = function(cid) {
  openConfirmDialog({
    title: "مسح سجل الرسائل",
    message: "هل أنت متأكد من مسح كافة الرسائل في هذه المحادثة؟ ستظل المحادثة موجودة في قائمتك مع حذف النصوص والوسائط.",
    confirmText: "مسح الرسائل",
    cancelText: "إلغاء",
    isDanger: true,
    icon: I("trash", "i l"),
    onConfirm: () => {
      clearChatMsgs(cid);
    }
  });
};

// Delete Entire Chat with Confirmation
window.confirmDeleteChat = function(cid) {
  openConfirmDialog({
    title: "حذف المحادثة نهائياً",
    message: "هل تريد بالتأكيد حذف هذه المحادثة بالكامل وسجلها من قائمتك؟ لا يمكن التراجع عن هذا الإجراء.",
    confirmText: "حذف المحادثة",
    cancelText: "إلغاء",
    isDanger: true,
    icon: I("trash", "i l"),
    onConfirm: () => {
      S.chats = (S.chats || []).filter(x => x.id !== cid);
      if (S.activeChat === cid) S.activeChat = null;
      save();
      toast("تم حذف المحادثة نهائياً", "info");
      go('chat');
    }
  });
};

// Block User with Confirmation
window.confirmBlockUser = function(userId, cid) {
  const targetUser = u(userId);
  const isBlocked = (S.blocked || []).includes(userId);
  if (isBlocked) {
    S.blocked = S.blocked.filter(x => x !== userId);
    save();
    render();
    toast("تم إلغاء حظر " + targetUser.name, "ok");
    return;
  }
  openConfirmDialog({
    title: "حظر " + targetUser.name,
    message: "هل أنت متأكد من حظر هذا المستخدم؟ لن يتمكن من إرسال رسائل أو الاتصال بك، ولن تظهر منشوراته لك.",
    confirmText: "تأكيد الحظر",
    cancelText: "إلغاء",
    isDanger: true,
    icon: I("ban", "i l"),
    onConfirm: () => {
      blockUser(userId);
    }
  });
};

// Chat Info More Options Menu
SHEETS.chatInfoMoreMenu = (cid) => {
  const c = (S.chats || []).find(x => x.id === cid);
  if (!c) return sheet("خيارات", "المحادثة غير موجودة");
  const uu = u(c.userId);
  return sheet(
    I("more","i s") + " خيارات متقدمة",
    `
    <div class="col" style="gap:6px">
      <button class="lstrow" onclick="closeOvl();navigator.clipboard.writeText('${cid}');toast('تم نسخ معرّف المحادثة: ${cid}','ok')">
        <span style="color:var(--cyan)">${I("copy","i s")}</span>
        <span class="g1 b sm" style="text-align:right">نسخ معرّف المحادثة (Chat ID)</span>
      </button>
      <button class="lstrow" onclick="closeOvl();shareProfile('${uu.id}')">
        <span style="color:var(--accent)">${I("share","i s")}</span>
        <span class="g1 b sm" style="text-align:right">مشاركة المحادثة والملف</span>
      </button>
      <button class="lstrow" onclick="closeOvl();openSheet('chatSecurityInfoSheet','${cid}')">
        <span style="color:var(--emerald)">${I("shield","i s")}</span>
        <span class="g1 b sm" style="text-align:right">بصمة التشفير وجلسة الأمان</span>
      </button>
      <button class="lstrow" onclick="closeOvl();render();toast('تم تحديث بيانات المحادثة ✓','ok')">
        <span style="color:var(--gold)">${I("refresh","i s")}</span>
        <span class="g1 b sm" style="text-align:right">تحديث ومزامنة المحادثة</span>
      </button>
    </div>
    `
  );
};

// Main Chat Info Screen Page
PAGES.chatInfo = () => {
  const c = (S.chats || []).find(x => x.id === S.params.id);
  if (!c) {
    setNav(false);
    setHdr(backHdr("معلومات المحادثة", ""));
    return emptyState("chat", "المحادثة غير موجودة", "");
  }
  const uu = u(c.userId);
  setNav(false);
  
  // Custom Material 3 Header
  setHdr(`
    <div style="display:flex;align-items:center;gap:8px;width:100%">
      <button class="iconbtn" onclick="go('chatRoom',{id:'${c.id}'})" aria-label="رجوع">${I("back")}</button>
      <div class="g1" style="display:flex;flex-direction:column;justify-content:center">
        <div class="b" style="font-size:15px;line-height:1.2">معلومات المحادثة</div>
        <div class="tiny mut" style="font-size:11px">تفاصيل وخيارات الدردشة</div>
      </div>
      <button class="iconbtn" onclick="openSheet('chatInfoMoreMenu','${c.id}')" aria-label="المزيد">${I("more")}</button>
    </div>
  `);

  // Calculate real media & attachment statistics
  const allMsgs = (c.messages || []).filter(m => !m.gone && !m.isDeleted);
  let mediaCount = 0;
  let fileCount = 0;
  let voiceCount = 0;
  let linkCount = 0;
  const pinnedCount = (c.pinnedMsgs || []).length;
  const recentMedia = [];

  allMsgs.forEach(m => {
    if (m.attachments && m.attachments.length) {
      m.attachments.forEach(a => {
        if (a.type === 'image' || a.type === 'video' || a.type === 'gif') {
          mediaCount++;
          if (recentMedia.length < 6) recentMedia.push({ type: a.type, src: a.src, name: a.name });
        } else if (a.type === 'file') {
          fileCount++;
        }
      });
    }
    if (m.type === 'image' || m.type === 'video' || m.type === 'gif') {
      if (m.src) {
        mediaCount++;
        if (recentMedia.length < 6) recentMedia.push({ type: m.type, src: m.src, name: m.text });
      }
    } else if (m.type === 'file') {
      fileCount++;
    } else if (m.type === 'voice') {
      voiceCount++;
    }
    if (m.text && /(https?:\/\/[^\s<]+)/.test(m.text)) {
      const urls = m.text.match(/(https?:\/\/[^\s<]+)/g);
      if (urls) linkCount += urls.length;
    }
  });

  const isContact = (S.contacts || []).includes(uu.id);
  const isBlocked = (S.blocked || []).includes(uu.id);
  const isMuted = !!c.muted;
  const isPinned = !!c.pinned;
  const isArchived = !!c.archived;
  const vanishHours = c.vanish || 0;

  return `
    <div class="chat-info-screen" style="max-width:680px;margin:0 auto;padding:12px 14px 50px;display:flex;flex-direction:column;gap:14px;overflow-y:auto;-webkit-overflow-scrolling:touch">
      
      <!-- 1. USER HERO PROFILE SECTION -->
      <div class="card2" style="padding:22px 18px;display:flex;flex-direction:column;align-items:center;text-align:center;position:relative;overflow:hidden">
        <!-- Background decorative ambient glow -->
        <div style="position:absolute;top:-50px;left:50%;transform:translateX(-50%);width:220px;height:120px;background:radial-gradient(circle,rgba(0,240,255,0.18) 0%,transparent 70%);pointer-events:none"></div>
        
        <!-- Large Avatar with Online status & Zoom -->
        <div style="position:relative;margin-bottom:14px;cursor:pointer" onclick="openImageViewer('${uu.avatar || uu.photoURL || ''}')" title="عرض الصورة الشخصية">
          <div style="width:92px;height:92px;border-radius:50%;padding:3px;background:linear-gradient(135deg,var(--accent),var(--accent2));box-shadow:0 8px 24px rgba(0,240,255,0.25)">
            <div style="width:100%;height:100%;border-radius:50%;overflow:hidden;background:var(--surface3)">
              ${av(uu, 86, false)}
            </div>
          </div>
          ${uu.online ? `
            <span style="position:absolute;bottom:4px;right:4px;width:18px;height:18px;border-radius:50%;background:var(--emerald);border:3px solid var(--bg);box-shadow:0 0 10px rgba(16,185,129,0.8)"></span>
          ` : `
            <span style="position:absolute;bottom:4px;right:4px;width:18px;height:18px;border-radius:50%;background:var(--muted);border:3px solid var(--bg)"></span>
          `}
        </div>

        <!-- Name & Badges -->
        <div class="row" style="gap:6px;align-items:center;margin-bottom:4px">
          <h2 class="b" style="font-size:19px;color:var(--text);line-height:1.2">${esc(uu.name)}</h2>
          ${vbadge(uu)}
          ${typeof lvlBadge === 'function' ? lvlBadge(uu) : ''}
        </div>

        <!-- Username & Copy -->
        <div class="row" style="gap:6px;align-items:center;margin-bottom:8px">
          <span class="mono sm mut" style="direction:ltr">@${esc(uu.username || uu.id)}</span>
          <button class="iconbtn" style="width:22px;height:22px;color:var(--muted)" onclick="navigator.clipboard.writeText('@${uu.username || uu.id}');toast('تم نسخ اسم المستخدم 📋','ok')" title="نسخ اسم المستخدم">
            ${I("copy","i s")}
          </button>
        </div>

        <!-- Status / Presence text -->
        <div class="row" style="gap:6px;align-items:center;margin-bottom:14px">
          <span style="width:7px;height:7px;border-radius:50%;background:${uu.online ? 'var(--emerald)' : 'var(--muted)'}"></span>
          <span class="tiny b" style="color:${uu.online ? 'var(--emerald)' : 'var(--muted)'}">
            ${uu.online ? 'متصل الآن' : 'غير متصل • شوهد مؤخراً'}
          </span>
        </div>

        <!-- Bio / Quote if available -->
        ${uu.bio ? `
          <div class="sm mut" style="max-width:440px;margin-bottom:18px;line-height:1.5;background:rgba(255,255,255,0.03);padding:8px 14px;border-radius:12px;border:1px solid var(--line)">
            « ${esc(uu.bio)} »
          </div>
        ` : ''}

        <!-- Primary Action Buttons Row -->
        <div class="row" style="gap:8px;width:100%;max-width:420px;justify-content:center">
          <button class="btn btn-pri g1" onclick="openProfile('${uu.id}')" style="gap:6px">
            ${I("user","i s")}
            <span>الملف الشخصي</span>
          </button>
          <button class="btn btn-sec g1" onclick="toggleContact('${uu.id}')" style="gap:6px;color:${isContact ? 'var(--emerald)' : 'var(--text)'}">
            ${isContact ? I("check","i s") : I("plus","i s")}
            <span>${isContact ? 'في جهات الاتصال' : 'إضافة لجهات الاتصال'}</span>
          </button>
          <button class="btn btn-ghost" onclick="shareProfile('${uu.id}')" style="width:42px;height:42px;border-radius:12px;padding:0;display:flex;align-items:center;justify-content:center;border:1px solid var(--line2)" title="مشاركة الملف الشخصي">
            ${I("share","i s")}
          </button>
        </div>
      </div>

      <!-- 2. CHAT SETTINGS CARD -->
      <div class="card2" style="padding:14px 16px;display:flex;flex-direction:column;gap:4px">
        <div class="row" style="gap:8px;padding-bottom:10px;margin-bottom:4px;border-bottom:1px solid var(--line)">
          <span style="color:var(--accent)">${I("settings","i s")}</span>
          <span class="b sm" style="color:var(--text)">إعدادات المحادثة</span>
        </div>

        <!-- Mute Notifications with Switch & Duration -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;border-bottom:1px solid var(--line)">
          <div class="row g1" style="gap:12px;cursor:pointer" onclick="openSheet('muteDurationSheet','${c.id}')">
            <span style="color:${isMuted ? 'var(--rose)' : 'var(--accent)'}">${I(isMuted ? "mute" : "bell","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">كتم الإشعارات</span>
              <span class="tiny mut">${isMuted ? (c.muteUntil ? 'مكتومة مؤقتاً' : 'مكتومة دائماً') : 'الإشعارات مفعلة'}</span>
            </div>
          </div>
          ${renderM3Switch(isMuted, `toggleChatMute('${c.id}')`)}
        </div>

        <!-- Custom Notification Tone -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;cursor:pointer;border-bottom:1px solid var(--line)" onclick="openSheet('chatNotifToneSheet','${c.id}')">
          <div class="row g1" style="gap:12px">
            <span style="color:var(--cyan)">${I("music","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">تخصيص نغمات الإشعارات</span>
              <span class="tiny mut">${esc(c.notifToneName || "النغمة الافتراضية")}</span>
            </div>
          </div>
          <span class="mut">${I("fwd","i s")}</span>
        </div>

        <!-- Pin Chat with Switch -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;border-bottom:1px solid var(--line)">
          <div class="row g1" style="gap:12px;cursor:pointer" onclick="toggleChatPin('${c.id}')">
            <span style="color:${isPinned ? 'var(--gold)' : 'var(--muted)'}">${I("pin","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">تثبيت المحادثة</span>
              <span class="tiny mut">إبقاء المحادثة في أعلى القائمة</span>
            </div>
          </div>
          ${renderM3Switch(isPinned, `toggleChatPin('${c.id}')`)}
        </div>

        <!-- Archive Chat with Switch -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;border-bottom:1px solid var(--line)">
          <div class="row g1" style="gap:12px;cursor:pointer" onclick="toggleChatArchive('${c.id}')">
            <span style="color:${isArchived ? 'var(--accent)' : 'var(--muted)'}">${I("archive","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">أرشفة المحادثة</span>
              <span class="tiny mut">${isArchived ? 'المحادثة مؤرشفة حالياً' : 'نقل المحادثة إلى قسم الأرشيف'}</span>
            </div>
          </div>
          ${renderM3Switch(isArchived, `toggleChatArchive('${c.id}')`)}
        </div>

        <!-- Change Chat Wallpaper -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;cursor:pointer;border-bottom:1px solid var(--line)" onclick="openSheet('chatWallpaper','${c.id}')">
          <div class="row g1" style="gap:12px">
            <span style="color:var(--purple)">${I("palette","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">تغيير خلفية المحادثة</span>
              <span class="tiny mut">تخصيص الخلفية والصور والتدرجات</span>
            </div>
          </div>
          <span class="mut">${I("fwd","i s")}</span>
        </div>

        <!-- Change Chat Theme Color / Bubbles -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;cursor:pointer;border-bottom:1px solid var(--line)" onclick="openSheet('chatThemeColorSheet','${c.id}')">
          <div class="row g1" style="gap:12px">
            <span style="color:var(--gold)">${I("sparkles","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">لون فقاعات المحادثة</span>
              <span class="tiny mut">تحديد لونك المميز للرسائل</span>
            </div>
          </div>
          <div class="row" style="gap:6px">
            <span style="width:16px;height:16px;border-radius:50%;background:${c.themeColor === 'purple' ? '#8B5CF6' : c.themeColor === 'emerald' ? '#10B981' : c.themeColor === 'rose' ? '#FB7185' : c.themeColor === 'amber' ? '#F59E0B' : c.themeColor === 'blue' ? '#3B82F6' : c.themeColor === 'crimson' ? '#E11D48' : '#00F0FF'}"></span>
            <span class="mut">${I("fwd","i s")}</span>
          </div>
        </div>

        <!-- Search inside Chat -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;cursor:pointer" onclick="openSheet('chatSearch','${c.id}')">
          <div class="row g1" style="gap:12px">
            <span style="color:var(--cyan)">${I("search","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">البحث داخل المحادثة</span>
              <span class="tiny mut">البحث بالنصوص والوسائط والروابط</span>
            </div>
          </div>
          <span class="mut">${I("fwd","i s")}</span>
        </div>
      </div>

      <!-- 3. MEDIA & SHARED CONTENT CARD -->
      <div class="card2" style="padding:14px 16px;display:flex;flex-direction:column;gap:12px">
        <div class="row" style="justify-content:space-between;align-items:center;padding-bottom:10px;border-bottom:1px solid var(--line)">
          <div class="row" style="gap:8px">
            <span style="color:var(--accent)">${I("image","i s")}</span>
            <span class="b sm" style="color:var(--text)">الوسائط والمحتوى المشترك</span>
          </div>
          <button class="btn btn-ghost btn-xs" onclick="openSheet('chatMedia','${c.id}')" style="color:var(--accent)">عرض الكل (${mediaCount + fileCount + voiceCount})</button>
        </div>

        <!-- Quick Tabs / Categories Grid -->
        <div class="grid3" style="gap:8px">
          <button class="card2 center col" style="padding:10px 6px;gap:4px;cursor:pointer;border:1px solid var(--line2);background:var(--surface2);border-radius:14px" onclick="setChatMediaTab('${c.id}','media')">
            <span style="color:var(--cyan)">${I("image","i s")}</span>
            <span class="tiny b">الصور والفيديو</span>
            <span class="tiny mono mut">${mediaCount}</span>
          </button>
          <button class="card2 center col" style="padding:10px 6px;gap:4px;cursor:pointer;border:1px solid var(--line2);background:var(--surface2);border-radius:14px" onclick="setChatMediaTab('${c.id}','files')">
            <span style="color:var(--emerald)">${I("file","i s")}</span>
            <span class="tiny b">الملفات</span>
            <span class="tiny mono mut">${fileCount}</span>
          </button>
          <button class="card2 center col" style="padding:10px 6px;gap:4px;cursor:pointer;border:1px solid var(--line2);background:var(--surface2);border-radius:14px" onclick="setChatMediaTab('${c.id}','voice')">
            <span style="color:var(--purple)">${I("mic","i s")}</span>
            <span class="tiny b">الصوتيات</span>
            <span class="tiny mono mut">${voiceCount}</span>
          </button>
          <button class="card2 center col" style="padding:10px 6px;gap:4px;cursor:pointer;border:1px solid var(--line2);background:var(--surface2);border-radius:14px" onclick="setChatMediaTab('${c.id}','links')">
            <span style="color:var(--blue)">${I("link","i s")}</span>
            <span class="tiny b">الروابط</span>
            <span class="tiny mono mut">${linkCount}</span>
          </button>
          <button class="card2 center col" style="padding:10px 6px;gap:4px;cursor:pointer;border:1px solid var(--line2);background:var(--surface2);border-radius:14px;grid-column:span 2" onclick="openSheet('pinnedMsgsSheet','${c.id}')">
            <div class="row" style="gap:6px">
              <span style="color:var(--gold)">${I("pin","i s")}</span>
              <span class="tiny b">الرسائل المثبتة</span>
            </div>
            <span class="tiny mono mut">${pinnedCount} مثبت</span>
          </button>
        </div>

        <!-- Recent Media Preview Grid -->
        ${recentMedia.length ? `
          <div class="col" style="gap:6px;margin-top:4px">
            <span class="tiny mut">أحدث الوسائط المتبادلة:</span>
            <div class="row" style="gap:6px;overflow-x:auto;padding-bottom:4px" class="no-sb">
              ${recentMedia.map(rm => `
                <div style="position:relative;width:68px;height:68px;border-radius:10px;overflow:hidden;flex-shrink:0;border:1px solid var(--line2);background:var(--surface3);cursor:pointer" onclick="openImageViewer('${rm.src}')">
                  ${rm.type === 'video' ? `
                    <video src="${rm.src}" style="width:100%;height:100%;object-fit:cover"></video>
                    <div style="position:absolute;inset:0;background:rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;color:#fff">${I("play","i s")}</div>
                  ` : `
                    <img src="${rm.src}" style="width:100%;height:100%;object-fit:cover" alt="">
                  `}
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}
      </div>

      <!-- 4. PRIVACY & SECURITY CARD -->
      <div class="card2" style="padding:14px 16px;display:flex;flex-direction:column;gap:4px">
        <div class="row" style="gap:8px;padding-bottom:10px;margin-bottom:4px;border-bottom:1px solid var(--line)">
          <span style="color:var(--emerald)">${I("shield","i s")}</span>
          <span class="b sm" style="color:var(--text)">الخصوصية والأمان</span>
        </div>

        <!-- Disappearing Messages (Vanish Mode) -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;cursor:pointer;border-bottom:1px solid var(--line)" onclick="openSheet('vanishModeSheet','${c.id}')">
          <div class="row g1" style="gap:12px">
            <span style="color:var(--gold)">${I("clock","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">الرسائل المختفية (Vanish Mode)</span>
              <span class="tiny mut">${vanishHours ? `مفعلة — تختفي الرسائل بعد ${vanishHours >= 24 ? (vanishHours/24)+' يوم' : vanishHours+' ساعة'}` : 'معطلة'}</span>
            </div>
          </div>
          <span class="mut">${I("fwd","i s")}</span>
        </div>

        <!-- Encryption & Security Details -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;cursor:pointer" onclick="openSheet('chatSecurityInfoSheet','${c.id}')">
          <div class="row g1" style="gap:12px">
            <span style="color:var(--emerald)">${I("lock","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">التشفير التام ومعلومات الأمان</span>
              <span class="tiny mut">المحادثة محمية ومشفرة من الطرفين</span>
            </div>
          </div>
          <span class="mut">${I("fwd","i s")}</span>
        </div>
      </div>

      <!-- 5. CHAT MANAGEMENT CARD -->
      <div class="card2" style="padding:14px 16px;display:flex;flex-direction:column;gap:4px">
        <div class="row" style="gap:8px;padding-bottom:10px;margin-bottom:4px;border-bottom:1px solid var(--line)">
          <span style="color:var(--accent)">${I("folder","i s")}</span>
          <span class="b sm" style="color:var(--text)">إدارة المحادثة</span>
        </div>

        <!-- Export Chat Transcript -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;cursor:pointer;border-bottom:1px solid var(--line)" onclick="exportChatTranscript('${c.id}')">
          <div class="row g1" style="gap:12px">
            <span style="color:var(--cyan)">${I("download","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">تصدير المحادثة</span>
              <span class="tiny mut">تحميل نسخة من سجل المحادثة كملف نصي .txt</span>
            </div>
          </div>
          <span class="mut">${I("fwd","i s")}</span>
        </div>

        <!-- Clear Local Cached Media -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;cursor:pointer;border-bottom:1px solid var(--line)" onclick="clearChatMediaCache('${c.id}')">
          <div class="row g1" style="gap:12px">
            <span style="color:var(--gold)">${I("refresh","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b">مسح الوسائط المحلية المؤقتة</span>
              <span class="tiny mut">تفريغ ذاكرة المرفقات وتوفير مساحة الجهاز</span>
            </div>
          </div>
          <span class="mut">${I("fwd","i s")}</span>
        </div>

        <!-- Clear Chat History -->
        <div class="row" style="justify-content:space-between;padding:10px 4px;cursor:pointer" onclick="confirmClearChatMsgs('${c.id}')">
          <div class="row g1" style="gap:12px">
            <span style="color:var(--gold)">${I("trash","i s")}</span>
            <div class="col" style="text-align:right">
              <span class="sm b" style="color:var(--gold)">حذف سجل الرسائل</span>
              <span class="tiny mut">مسح جميع الرسائل مع الإبقاء على المحادثة</span>
            </div>
          </div>
          <span class="mut">${I("fwd","i s")}</span>
        </div>
      </div>

      <!-- 6. DANGER ACTIONS CARD (Visually Separated at Bottom) -->
      <div class="card2" style="padding:14px 16px;display:flex;flex-direction:column;gap:6px;border:1px solid rgba(244,63,94,0.25);background:rgba(244,63,94,0.04)">
        <div class="row" style="gap:8px;padding-bottom:10px;margin-bottom:4px;border-bottom:1px solid rgba(244,63,94,0.15)">
          <span style="color:var(--rose)">${I("alert","i s")}</span>
          <span class="b sm" style="color:var(--rose)">الإجراءات الحاسمة والرقابة</span>
        </div>

        <!-- Report User -->
        <button class="lstrow" onclick="go('report',{id:'${uu.id}',type:'user'})" style="border-color:rgba(244,63,94,0.2);color:var(--rose)">
          <span>${I("alert","i s")}</span>
          <div class="col g1" style="text-align:right">
            <span class="sm b">الإبلاغ عن المستخدم</span>
            <span class="tiny mut">إرسال بلاغ لفريق الرقابة والأمان</span>
          </div>
          <span>${I("fwd","i s")}</span>
        </button>

        <!-- Block User -->
        <button class="lstrow" onclick="confirmBlockUser('${uu.id}','${c.id}')" style="border-color:rgba(244,63,94,0.2);color:var(--rose)">
          <span>${I("ban","i s")}</span>
          <div class="col g1" style="text-align:right">
            <span class="sm b">${isBlocked ? 'إلغاء حظر المستخدم' : 'حظر المستخدم'}</span>
            <span class="tiny mut">${isBlocked ? 'المستخدم محظور حالياً — اضغط لفك الحظر' : 'منع استقبال الرسائل والمكالمات'}</span>
          </div>
          <span>${I("fwd","i s")}</span>
        </button>

        <!-- Delete Entire Chat -->
        <button class="lstrow" onclick="confirmDeleteChat('${c.id}')" style="border-color:rgba(244,63,94,0.3);background:rgba(244,63,94,0.08);color:var(--rose)">
          <span>${I("trash","i s")}</span>
          <div class="col g1" style="text-align:right">
            <span class="sm b">حذف المحادثة نهائياً</span>
            <span class="tiny mut">حذف المحادثة بكاملها من قائمة محادثاتك</span>
          </div>
          <span>${I("fwd","i s")}</span>
        </button>
      </div>

    </div>
  `;
};

PAGES.chatInfoScreen = PAGES.chatInfo;



/* ==========================================================================
   VISUAL_CONTROL_CENTER_COMPLETE_SYSTEM
   ANIME BLACK — ENTERPRISE OWNER-ONLY VISUAL DESIGN SYSTEM & THEME ENGINE v2.0
   ========================================================================== */

window.DEFAULT_VISUAL_CONFIG = {
  version: "2.0.0",
  id: "anime_black_default",
  updatedAt: Date.now(),
  author: "Anime Black Team",
  theme: {
    id: "amoled_black",
    name: "AMOLED Pure Black",
    description: "الهوية الرسمية الأيقونية لأنمي بلاك — أسود حقيقي فائق التباين مع ومضات حمراء وزرقاء",
    author: "Anime Black Core",
    category: "Official",
    isDark: true,
    status: "published",
    thumbnail: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&q=80"
  },
  colors: {
    primary: "#00A3FF",
    secondary: "#8B5CF6",
    tertiary: "#EC4899",
    accent: "#00A3FF",
    accent2: "#FF7A00",
    accent3: "#E60000",
    bg: "#08090D",
    bg2: "#0D0F16",
    surface: "#151822",
    surfaceVariant: "#1C202E",
    card: "#151822",
    card2: "#181B26",
    elevatedSurface: "#1F2433",
    textPrimary: "#FFFFFF",
    textSecondary: "#9CA3AF",
    textDisabled: "#4B5563",
    border: "rgba(255, 255, 255, 0.08)",
    divider: "rgba(255, 255, 255, 0.06)",
    glowColor: "rgba(0, 163, 255, 0.35)",
    success: "#10B981",
    warning: "#F59E0B",
    error: "#EF4444",
    info: "#06B6D4",
    link: "#00A3FF",
    online: "#10B981",
    offline: "#6B7280",
    premium: "#F59E0B",
    coin: "#F59E0B",
    star: "#06B6D4",
    levelXp: "#8B5CF6",
    notification: "#EF4444",
    repost: "#10B981",
    reaction: "#EC4899",
    verified: "#00A3FF",
    admin: "#EF4444",
    owner: "#F59E0B"
  },
  typography: {
    fontFamily: "'Tajawal', 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif",
    headingFont: "'Tajawal', 'Plus Jakarta Sans', sans-serif",
    baseFontSize: 14,
    lineHeight: 1.6,
    letterSpacing: 0,
    textTransform: "none"
  },
  shapes: {
    globalRadius: 14,
    cardRadius: 14,
    buttonRadius: 99,
    inputRadius: 12,
    dialogRadius: 18,
    avatarRadius: 99,
    badgeRadius: 8,
    chipRadius: 20
  },
  spacing: {
    containerPadding: 14,
    cardPadding: 12,
    gap: 10
  },
  elevation: {
    shadowEnabled: true,
    cardShadow: "0 4px 20px rgba(0,0,0,0.45)",
    glowIntensity: 12,
    borderGlow: true,
    glassBlur: 16,
    glassOpacity: 0.78
  },
  backgrounds: {
    global: { type: "solid", color: "#08090D", image: "", blur: 0, opacity: 1, gradient: "" },
    home: { type: "solid", color: "#08090D", image: "", blur: 0, opacity: 1 },
    community: { type: "solid", color: "#08090D", image: "", blur: 0, opacity: 1 },
    chat: { type: "solid", color: "#08090D", image: "", blur: 0, opacity: 1 },
    reels: { type: "solid", color: "#000000", image: "", blur: 0, opacity: 1 },
    profile: { type: "solid", color: "#08090D", image: "", blur: 0, opacity: 1 },
    store: { type: "solid", color: "#08090D", image: "", blur: 0, opacity: 1 }
  },
  components: {
    primaryBtn: { bg: "linear-gradient(135deg, #00A3FF 0%, #8B5CF6 100%)", textColor: "#FFFFFF", radius: 99, padding: "9px 20px", glow: true },
    cardStyle: { bg: "#151822", border: "1px solid rgba(255, 255, 255, 0.08)", radius: 14 },
    glassCard: { bg: "rgba(21, 24, 34, 0.78)", blur: 16, border: "1px solid rgba(255, 255, 255, 0.12)", radius: 16 }
  },
  icons: {
    mapping: {
      bottom_nav_home: "home",
      bottom_nav_community: "compass",
      bottom_nav_chat: "chat",
      bottom_nav_reels: "clapper",
      bottom_nav_more: "more"
    }
  },
  pageSections: {
    home: [
      { id: "stories", title: "القصص اليومية", enabled: true, order: 1 },
      { id: "live_stream", title: "البثوث المباشرة", enabled: true, order: 2 },
      { id: "feed", title: "خلاصة المنشورات", enabled: true, order: 3 },
      { id: "recommended_anime", title: "أنميات مقترحة", enabled: true, order: 4 },
      { id: "top_communities", title: "أبرز المجتمعات", enabled: true, order: 5 }
    ]
  }
};

window.READY_MADE_THEMES = [
  { id: "amoled_black", name: "AMOLED Pure Black", category: "Official", description: "أسود مطلق يوفر طاقة الشاشات مع أزرار نيون زرقاء وقرمزية", colors: { primary: "#00A3FF", secondary: "#8B5CF6", bg: "#000000", bg2: "#080808", surface: "#111111", card: "#121214", border: "rgba(255,255,255,0.09)", glowColor: "rgba(0,163,255,0.4)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 14, buttonRadius: 99 }, thumbnail: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&q=80" },
  { id: "cyber_neon", name: "Cyber Neon 2077", category: "Futuristic", description: "طابع سيبراني مستقبلي — سيان لامع ووردي فاقع مع إطارات متوهجة", colors: { primary: "#00F0FF", secondary: "#FF0055", bg: "#060814", bg2: "#0B0E1F", surface: "#10162F", card: "#121A38", border: "rgba(0,240,255,0.25)", glowColor: "rgba(0,240,255,0.45)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 8, buttonRadius: 6 }, thumbnail: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&q=80" },
  { id: "deep_purple", name: "Deep Purple Galaxy", category: "Cosmic", description: "أرجواني ملكي عميق مستوحى من المجرات البعيدة والأساطير", colors: { primary: "#A855F7", secondary: "#EC4899", bg: "#090514", bg2: "#120B24", surface: "#1A1033", card: "#221644", border: "rgba(168,85,247,0.2)", glowColor: "rgba(168,85,247,0.4)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 16, buttonRadius: 99 }, thumbnail: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&q=80" },
  { id: "anime_energy", name: "Anime Energy Red", category: "Action", description: "طاقة قتالية وشعلة ملتهبة مستوحاة من عوالم الشونين والأنمي الحماسي", colors: { primary: "#E60000", secondary: "#FF7A00", bg: "#0A0505", bg2: "#140A0A", surface: "#1F0F0F", card: "#291414", border: "rgba(230,0,0,0.22)", glowColor: "rgba(230,0,0,0.45)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 14, buttonRadius: 99 }, thumbnail: "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&q=80" },
  { id: "luxury_glass", name: "Luxury Dark Glass", category: "Premium", description: "زجاج فخم معتم مع انعكاسات ضوئية فائقة الدقة وظلال ناعمة", colors: { primary: "#60A5FA", secondary: "#C084FC", bg: "#0B0F19", bg2: "#111827", surface: "rgba(30,41,59,0.7)", card: "rgba(30,41,59,0.65)", border: "rgba(255,255,255,0.14)", glowColor: "rgba(96,165,250,0.3)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 18, buttonRadius: 14 }, thumbnail: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300&q=80" },
  { id: "gold_premium", name: "Imperial Gold VIP", category: "Luxury", description: "هيبة الذهب الإمبراطوري — بريق ملكي مع خلفيات أبنوسية داكنة", colors: { primary: "#F59E0B", secondary: "#D97706", bg: "#0A0905", bg2: "#14120A", surface: "#1F1C0F", card: "#2B2615", border: "rgba(245,158,11,0.25)", glowColor: "rgba(245,158,11,0.45)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 14, buttonRadius: 99 }, thumbnail: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=300&q=80" },
  { id: "ocean_night", name: "Abyssal Ocean", category: "Atmospheric", description: "أزرق المحيطات العميقة — تدرجات هادئة وراقية للعين", colors: { primary: "#0EA5E9", secondary: "#3B82F6", bg: "#030A14", bg2: "#071324", surface: "#0B1D36", card: "#0F2647", border: "rgba(14,165,233,0.2)", glowColor: "rgba(14,165,233,0.35)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 14, buttonRadius: 99 }, thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&q=80" },
  { id: "green_cyber", name: "Matrix Cyberpunk", category: "Futuristic", description: "أخضر الزمرد الرقمي وشبكات المستقبل المتقدمة", colors: { primary: "#10B981", secondary: "#059669", bg: "#040D09", bg2: "#071811", surface: "#0B261B", card: "#0F3324", border: "rgba(16,185,129,0.22)", glowColor: "rgba(16,185,129,0.4)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 12, buttonRadius: 8 }, thumbnail: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=300&q=80" },
  { id: "crimson_night", name: "Crimson Vampire", category: "Gothic", description: "ياقوتي دموي غامض مستوحى من ليل طوكيو والقصص الخارقة", colors: { primary: "#F43F5E", secondary: "#BE123C", bg: "#0F0508", bg2: "#1A0A0F", surface: "#2B0F18", card: "#381420", border: "rgba(244,63,94,0.25)", glowColor: "rgba(244,63,94,0.45)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 16, buttonRadius: 99 }, thumbnail: "https://images.unsplash.com/photo-1514565131-fce0801e5785?w=300&q=80" },
  { id: "minimal_charcoal", name: "Minimal Charcoal Studio", category: "Minimal", description: "رمادي فحمي متوازن وعصري بأعلى معايير البساطة الاحترافية", colors: { primary: "#E5E7EB", secondary: "#9CA3AF", bg: "#121316", bg2: "#1A1C21", surface: "#22252C", card: "#282C35", border: "rgba(255,255,255,0.08)", glowColor: "rgba(255,255,255,0.15)", textPrimary: "#F9FAFB" }, shapes: { cardRadius: 10, buttonRadius: 8 }, thumbnail: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=300&q=80" },
  { id: "sunset_samurai", name: "Sunset Samurai", category: "Artistic", description: "غروب الساموراي الذهبي الممزوج بنار الكرز اليابانية", colors: { primary: "#FB923C", secondary: "#F43F5E", bg: "#0D080A", bg2: "#170E12", surface: "#26161D", card: "#331E27", border: "rgba(251,146,60,0.2)", glowColor: "rgba(251,146,60,0.4)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 14, buttonRadius: 99 }, thumbnail: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=300&q=80" },
  { id: "voyager_nebula", name: "Voyager Nebula", category: "Cosmic", description: "سديم كوني ناصع وتدرجات ملهمة بين الأزرق السماوي والبنفسجي", colors: { primary: "#38BDF8", secondary: "#C084FC", bg: "#060A14", bg2: "#0C1224", surface: "#131C38", card: "#19254A", border: "rgba(56,189,248,0.22)", glowColor: "rgba(56,189,248,0.4)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 16, buttonRadius: 99 }, thumbnail: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=300&q=80" },
  { id: "sakura_twilight", name: "Sakura Twilight Night", category: "Anime Art", description: "أزهار الكرز الليلي مع توهج وردي باستيل هادئ وأنيق", colors: { primary: "#F472B6", secondary: "#818CF8", bg: "#0E0710", bg2: "#170C1B", surface: "#221327", card: "#2C1933", border: "rgba(244,114,182,0.2)", glowColor: "rgba(244,114,182,0.35)", textPrimary: "#FFF5F8" }, shapes: { cardRadius: 16, buttonRadius: 99 }, thumbnail: "https://images.unsplash.com/photo-1522383225653-ed111181a951?w=300&q=80" },
  { id: "synthwave_80s", name: "Retro Synthwave 80s", category: "Retro", description: "ألوان النيون الكلاسيكية للثمانينات — بنفسجي غامق وتوهج برتقالي سماوي", colors: { primary: "#FF007F", secondary: "#7928CA", bg: "#07020D", bg2: "#12081E", surface: "#1D0D30", card: "#2A1345", border: "rgba(255,0,127,0.3)", glowColor: "rgba(255,0,127,0.5)", textPrimary: "#FFFFFF" }, shapes: { cardRadius: 10, buttonRadius: 8 }, thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=300&q=80" }
];

function deepMergeObjects(target, source) {
  if (!source) return target;
  const output = Object.assign({}, target);
  Object.keys(source).forEach(key => {
    if (source[key] && typeof source[key] === "object" && !Array.isArray(source[key])) {
      output[key] = deepMergeObjects(target[key] || {}, source[key]);
    } else {
      output[key] = source[key];
    }
  });
  return output;
}

// Calculate color contrast ratio for accessibility
function getContrastRatio(hex1, hex2) {
  function getLuminance(hex) {
    if (!hex || !hex.startsWith("#") || hex.length < 7) return 0.2;
    const rgb = [parseInt(hex.substr(1,2),16)/255, parseInt(hex.substr(3,2),16)/255, parseInt(hex.substr(5,2),16)/255];
    const a = rgb.map(v => v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4));
    return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
  }
  const l1 = getLuminance(hex1) + 0.05;
  const l2 = getLuminance(hex2) + 0.05;
  return (Math.max(l1, l2) / Math.min(l1, l2)).toFixed(2);
}

window.VISUAL_ENGINE = {
  init: function() {
    let cached = null;
    try {
      const stored = localStorage.getItem("anime_black_published_visual_config");
      if (stored) cached = JSON.parse(stored);
    } catch(e) {}

    S.visualConfig = deepMergeObjects(window.DEFAULT_VISUAL_CONFIG, cached || {});
    S.visualDraft = deepMergeObjects(S.visualConfig, {});
    S.visualThemes = S.visualThemes || window.READY_MADE_THEMES;
    S.visualPreviewDevice = S.visualPreviewDevice || "mobile";
    S.visualAssets = S.visualAssets || [
      { id: "ast_logo_main", name: "شعار أنمي بلاك الرسمي", category: "App Logo", url: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=150&q=80", size: "48KB", usageCount: 6, date: Date.now() - 864e5*10 },
      { id: "ast_bg_galaxy", name: "خلفية المجرة الكونية", category: "Background", url: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&q=80", size: "310KB", usageCount: 2, date: Date.now() - 864e5*5 },
      { id: "ast_frame_fire", name: "إطار اللهب الحارق", category: "Frame", url: "https://images.unsplash.com/photo-1563089145-599997674d42?w=150&q=80", size: "62KB", usageCount: 4, date: Date.now() - 864e5*2 }
    ];
    S.visualBadges = S.visualBadges || [
      { id: "bdg_founder", name: "المؤسس الأعلى", category: "Owner", rarity: "Mythic", color: "#F59E0B", icon: "crown", desc: "شارة الإدارة العليا ومؤسسي أنمي بلاك", locations: ["profile","post_header","chat"], condition: "manual", glow: "glow-gold", protected: true },
      { id: "bdg_level_100", name: "أسطورة الأوتاكو Lv.100", category: "Level", rarity: "Legendary", color: "#EF4444", icon: "flame", desc: "بلوغ المستوى الأسطوري 100", locations: ["profile","post_header"], condition: "level_100", glow: "glow-red", protected: false },
      { id: "bdg_verified_creator", name: "صانع محتوى موثق", category: "Verified", rarity: "Epic", color: "#00A3FF", icon: "check", desc: "صناع المحتوى والمترجمين المعتمدين", locations: ["profile","username_row"], condition: "manual", glow: "glow-cyan", protected: true },
      { id: "bdg_vip_elite", name: "عضو النخبة VIP", category: "Premium", rarity: "Exclusive", color: "#A855F7", icon: "sparkles", desc: "مشتركو الباقة النخبوية السنوية", locations: ["profile","chat"], condition: "premium_active", glow: "glow-purple", protected: false }
    ];
    S.visualStoreItems = S.visualStoreItems || [
      { id: "store_theme_cyber", name: "ثيم سايبر نيون 2077", category: "Theme", price: 1200, currency: "coin", rarity: "Epic", active: true, thumbnail: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&q=80", desc: "تصميم سايبر نيون ناصع متكامل" },
      { id: "store_frame_flame", name: "إطار اللهب الأزرق النادر", category: "Frame", price: 600, currency: "coin", rarity: "Rare", active: true, thumbnail: "https://images.unsplash.com/photo-1563089145-599997674d42?w=300&q=80", desc: "إطار صور رمزية متوهج" },
      { id: "store_chat_galaxy", name: "مظهر المحادثات: سديم المجرة", category: "Chat Theme", price: 400, currency: "coin", rarity: "Rare", active: true, thumbnail: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=300&q=80", desc: "فقاعات محادثة وخلفيات كونية خاصة" }
    ];
    S.visualVersions = S.visualVersions || [
      { id: "v_1_0_0", version: "1.0.0", name: "الإصدار الافتراضي الأساسي", author: "Super Admin", publishedAt: Date.now() - 864e5*3, note: "الإصدار القياسي الثابت", snapshot: JSON.parse(JSON.stringify(window.DEFAULT_VISUAL_CONFIG)) }
    ];
    S.visualAuditLogs = S.visualAuditLogs || [
      { id: "log_1", action: "INITIALIZE_SYSTEM", author: "m774545471@gmail.com", timestamp: Date.now() - 864e5*3, details: "تهيئة نظام التحكم البصري الشامل" }
    ];

    this.applyConfig(S.visualConfig);
    this.listenToRemoteConfig();
  },

  applyConfig: function(cfg) {
    if (!cfg) return;
    const colors = cfg.colors || {};
    const shapes = cfg.shapes || {};
    const typo = cfg.typography || {};
    const bg = (cfg.backgrounds && cfg.backgrounds.global) || {};
    const elev = cfg.elevation || {};

    let styleEl = document.getElementById("anime_black_dynamic_visual_styles");
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "anime_black_dynamic_visual_styles";
      document.head.appendChild(styleEl);
    }

    const cssRules = `
      :root {
        --accent: ${colors.accent || colors.primary || "#00A3FF"};
        --accent2: ${colors.accent2 || colors.secondary || "#FF7A00"};
        --accent3: ${colors.accent3 || colors.tertiary || "#E60000"};
        --bg: ${colors.bg || "#08090D"};
        --bg2: ${colors.bg2 || "#0D0F16"};
        --card: ${colors.card || "#151822"};
        --card2: ${colors.card2 || "#181B26"};
        --surface: ${colors.surface || "#151822"};
        --txt: ${colors.textPrimary || "#FFFFFF"};
        --faint: ${colors.textSecondary || "#9CA3AF"};
        --line: ${colors.border || "rgba(255, 255, 255, 0.08)"};
        --glow: ${colors.glowColor || "rgba(0,163,255,0.35)"};
        --rad: ${shapes.cardRadius || 14}px;
        --btn-rad: ${shapes.buttonRadius || 99}px;
        --in-rad: ${shapes.inputRadius || 12}px;
        --card-shadow: ${elev.cardShadow || "0 4px 20px rgba(0,0,0,0.45)"};
      }
      body {
        font-family: ${typo.fontFamily || "'Tajawal', 'Plus Jakarta Sans', system-ui, sans-serif"};
        background-color: ${colors.bg || "#08090D"};
        color: ${colors.textPrimary || "#FFFFFF"};
      }
      .card, .card2, .post, .sheet-body {
        border-radius: ${shapes.cardRadius || 14}px !important;
      }
      .btn, .btn-primary, .btn-sec {
        border-radius: ${shapes.buttonRadius || 99}px !important;
      }
      .glow-gold { box-shadow: 0 0 14px rgba(245, 158, 11, 0.5) !important; }
      .glow-cyan { box-shadow: 0 0 14px rgba(0, 163, 255, 0.5) !important; }
      .glow-red { box-shadow: 0 0 14px rgba(239, 68, 68, 0.5) !important; }
      .glow-purple { box-shadow: 0 0 14px rgba(168, 85, 247, 0.5) !important; }
      ${bg.image ? `
      body::before {
        content: "";
        position: fixed;
        inset: 0;
        z-index: -1;
        background-image: url('${bg.image}');
        background-size: cover;
        background-position: center;
        opacity: ${bg.opacity || 0.15};
        filter: blur(${bg.blur || 0}px);
        pointer-events: none;
      }` : ""}
    `;

    styleEl.textContent = cssRules;
  },

  listenToRemoteConfig: function() {
    if (!window.db || !window.doc || !window.onSnapshot) return;
    try {
      const docRef = window.doc(window.db, "app_visual_config", "published");
      window.onSnapshot(docRef, (snap) => {
        if (snap.exists()) {
          const remoteData = snap.data();
          if (remoteData && remoteData.config) {
            S.visualConfig = deepMergeObjects(window.DEFAULT_VISUAL_CONFIG, remoteData.config);
            try{ localStorage.setItem("anime_black_published_visual_config", JSON.stringify(S.visualConfig)); }catch(err){}
            this.applyConfig(S.visualConfig);
            if (S.page === "visualControlCenter" || S.page === "admin") debounceRender();
          }
        }
      }, (err) => {});
    } catch(e) {}
  },

  saveDraft: function(draftData) {
    S.visualDraft = deepMergeObjects(S.visualDraft || S.visualConfig, draftData);
    S.visualDraft.updatedAt = Date.now();
    save();
    this.addAuditLog("SAVE_DRAFT", "حفظ مسودة تعديلات التصميم في النظام");
    toast("تم حفظ مسودة التصميم بنجاح 💾", "ok");
  },

  validateConfig: function(cfg) {
    const issues = [];
    if (!cfg.theme || !cfg.theme.name || !cfg.theme.name.trim()) {
      issues.push({ level: "ERROR", msg: "اسم الثيم الأساسي مطلوب" });
    }
    if (!cfg.colors || !cfg.colors.primary) {
      issues.push({ level: "ERROR", msg: "اللون الأساسي (Primary Color) غير محدد" });
    }
    if (cfg.colors && cfg.colors.bg && cfg.colors.textPrimary && cfg.colors.bg === cfg.colors.textPrimary) {
      issues.push({ level: "BLOCKING", msg: "لون الخلفية ولون النص متطابقان — سيجعل التطبيق غير مقروء!" });
    }
    return issues;
  },

  publishDraft: async function(note) {
    if (!isPlatformAdmin()) {
      toast("عذراً، صلاحية النشر مخصصة لمالك المنصة فقط 🔒", "err");
      return;
    }

    const issues = this.validateConfig(S.visualDraft);
    const blocking = issues.filter(i => i.level === "BLOCKING");
    if (blocking.length > 0) {
      toast("تعذر النشر: يوجد أخطاء تمنع النشر! راجع تبويب الفحص", "err");
      return;
    }

    snd("fanfare");
    const vNumber = "v_" + Date.now().toString(36);
    const authorEmail = (S.me && S.me.email) || "m774545471@gmail.com";

    const versionSnapshot = {
      id: vNumber,
      version: "2." + ((S.visualVersions||[]).length + 1) + ".0",
      name: S.visualDraft.theme.name || "إصدار تصميم جديد",
      author: authorEmail,
      publishedAt: Date.now(),
      note: note || "تم النشر من مركز التحكم البصري المطور",
      snapshot: JSON.parse(JSON.stringify(S.visualDraft))
    };

    S.visualConfig = JSON.parse(JSON.stringify(S.visualDraft));
    S.visualVersions = [versionSnapshot, ...(S.visualVersions || [])];
    try{ localStorage.setItem("anime_black_published_visual_config", JSON.stringify(S.visualConfig)); }catch(err){}

    this.applyConfig(S.visualConfig);

    if (window.db && window.doc && window.setDoc) {
      try {
        await window.setDoc(window.doc(window.db, "app_visual_config", "published"), {
          config: S.visualConfig,
          publishedAt: Date.now(),
          publishedBy: authorEmail,
          version: versionSnapshot.version
        });
        await window.setDoc(window.doc(window.db, "published_versions", vNumber), versionSnapshot);
      } catch(e) {}
    }

    this.addAuditLog("PUBLISH_THEME", `نشر الإصدار ${versionSnapshot.version} بنجاح: ${versionSnapshot.name}`);
    save();
    toast(`تم نشر التصميم رسمياً لجميع المستخدمين بنجاح 🎉 (${versionSnapshot.version})`, "ok");
    render();
  },

  rollbackToVersion: async function(verId) {
    if (!isPlatformAdmin()) return;
    const target = (S.visualVersions || []).find(v => v.id === verId);
    if (!target || !target.snapshot) {
      toast("الإصدار المطلوب غير موجود", "err");
      return;
    }

    if (!confirm(`هل أنت متأكد من استعادة الإصدار [${target.name} — ${target.version}]؟\nسيتم إنشاء إصدار جديد يحتوي على إعدادات هذا الإصدار.`)) {
      return;
    }

    S.visualDraft = JSON.parse(JSON.stringify(target.snapshot));
    await this.publishDraft(`استعادة واسترجاع آمن من الإصدار ${target.version}`);
    toast("تم استرجاع الإصدار وتطبيقه بنجاح 🔄", "ok");
  },

  safeModeReset: function() {
    if (!confirm("⚠️ تفعيل وضع الأمان (Safe Mode):\nسيتم إعادة تعيين الهوية البصرية إلى النسخة القياسية الرسمية لأنمي بلاك فوراً لحل أي خلل.")) return;
    S.visualDraft = JSON.parse(JSON.stringify(window.DEFAULT_VISUAL_CONFIG));
    this.publishDraft("إعادة تعيين طارئة (Safe Mode Emergency Reset)");
    toast("تم تفعيل وضع الأمان واستعادة الهوية القياسية 🛡️", "ok");
  },

  exportConfig: function() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(S.visualConfig, null, 2));
    const dlAnchor = document.createElement("a");
    dlAnchor.setAttribute("href", dataStr);
    dlAnchor.setAttribute("download", `anime_black_visual_config_${Date.now()}.json`);
    document.body.appendChild(dlAnchor);
    dlAnchor.click();
    dlAnchor.remove();
    toast("تم تصدير ملف إعدادات الهوية البصرية 📥", "ok");
  },

  importConfig: function(jsonString) {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed || typeof parsed !== "object") throw new Error("الملف غير صالح");
      S.visualDraft = deepMergeObjects(window.DEFAULT_VISUAL_CONFIG, parsed);
      this.saveDraft(S.visualDraft);
      toast("تم استيراد الإعدادات إلى المسودة بنجاح! يمكنك معاينتها ونشرها الآن 🚀", "ok");
      render();
    } catch(e) {
      toast("فشل استيراد الملف: تنسيق JSON غير صالح ❌", "err");
    }
  },

  addAuditLog: function(action, details) {
    const logItem = {
      id: "log_" + Date.now().toString(36),
      action: action,
      author: (S.me && S.me.email) || "m774545471@gmail.com",
      timestamp: Date.now(),
      details: details
    };
    S.visualAuditLogs = [logItem, ...(S.visualAuditLogs || [])].slice(0, 100);
    save();

    if (window.db && window.doc && window.setDoc) {
      try {
        window.setDoc(window.doc(window.db, "audit_logs", logItem.id), logItem);
      } catch(e) {}
    }
  }
};

/* ==========================================================================
   UI PAGES: VISUAL CONTROL CENTER MAIN HUB & SUB-VIEWS
   ========================================================================== */

PAGES.visualControlCenter = () => {
  if (!isPlatformAdmin()) {
    setNav(true);
    setHdr(backHdr("تم رفض الوصول", "مركز التحكم البصري"));
    return `<div class="pad center col" style="padding-top:70px;gap:15px">
      <div style="width:78px;height:78px;border-radius:50%;background:rgba(239,68,68,.14);border:2px solid rgba(239,68,68,.4);display:flex;align-items:center;justify-content:center;color:var(--rose)">${I("shield","xl")}</div>
      <div class="bb sm" style="color:var(--rose);font-size:18px">تم رفض الوصول · Owner Only</div>
      <div class="tiny fnt mut" style="max-width:340px;line-height:1.7;text-align:center">مركز التحكم البصري وتصميم الثيمات وإدارة المكونات مخصص حصرياً لمالك المنصة: <b dir="ltr" class="mono" style="color:var(--accent);display:block;margin-top:4px">m774545471@gmail.com</b></div>
      <button class="btn btn-primary btn-sm" style="margin-top:6px;gap:6px" onclick="go('home')">${I("home","i s")} العودة للرئيسية</button>
    </div>`;
  }

  const sub = S.params.sub || S.visualSubTab || "overview";
  S.visualSubTab = sub;
  setNav(false);
  setHdr(backHdr("نظام التصميم الإداري الأعلى", "مركز التخصيص والهوية البصرية v2.0", `<button class="btn btn-primary btn-xs" onclick="VISUAL_ENGINE.publishDraft()" style="gap:5px">${I("sparkles","i s")} نشر التغييرات</button>`));

  const draft = S.visualDraft || S.visualConfig || window.DEFAULT_VISUAL_CONFIG;
  const currentTheme = (draft.theme && draft.theme.name) || "AMOLED Pure Black";
  const versionsCount = (S.visualVersions || []).length;
  const assetsCount = (S.visualAssets || []).length;
  const badgesCount = (S.visualBadges || []).length;
  const storeCount = (S.visualStoreItems || []).length;
  const auditCount = (S.visualAuditLogs || []).length;

  const subTabs = [
    ["overview", "نظرة عامة", "home"],
    ["studio", "استوديو التصميم المتطور", "brush"],
    ["themes", "معرض الثيمات (14+)", "sparkles"],
    ["components", "المكونات والأزرار", "layers"],
    ["icons", "تخصيص الأيقونات", "star"],
    ["assets", "إدارة الصور والأصول", "image"],
    ["badges", "منشئ الشارات والرتب", "award"],
    ["store", "متجر المظاهر والسمات", "coins"],
    ["pages", "أقسام الصفحات والتنقل", "grid"],
    ["preview", "المعاينة التفاعلية الحية", "eye"],
    ["versions", "سجل الإصدارات والاسترجاع", "clock"],
    ["audit", "سجل تدقيق العمليات", "file"],
    ["recovery", "الأمان والاستعادة الطارئة", "shield"]
  ];

  return `
  <div class="pad" style="max-width:1080px;margin:0 auto;padding-bottom:60px">
    <!-- Header Hero Banner -->
    <div style="display:flex;align-items:center;justify-content:space-between;padding:18px 22px;border-radius:20px;background:linear-gradient(135deg,#001026 0%,#002B66 40%,#00A3FF 100%);color:#fff;margin-bottom:14px;box-shadow:0 12px 35px rgba(0,163,255,.28);border:1px solid rgba(255,255,255,.15);flex-wrap:wrap;gap:12px">
      <div style="display:flex;align-items:center;gap:14px">
        <div style="width:52px;height:52px;border-radius:16px;background:rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;color:#00F0FF;border:1px solid rgba(0,240,255,.35);box-shadow:0 0 15px rgba(0,240,255,.3)">${I("sparkles","l")}</div>
        <div>
          <div class="bb sm" style="font-size:17px;letter-spacing:.3px">نظام التصميم الإداري الأعلى · DESIGN CONTROL CENTER v2.0</div>
          <div class="tiny" style="color:rgba(255,255,255,.85);margin-top:2px">التحكم الفوري بالثيمات، الألوان، التدرجات، الإطارات المتوهجة، الشارات وأقسام الواجهة</div>
        </div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-sec btn-xs" onclick="go('admin')" style="background:rgba(0,0,0,.3);border-color:rgba(255,255,255,.2)">${I("shield","i s")} لوحة الإدارة</button>
        <button class="btn btn-primary btn-xs" onclick="VISUAL_ENGINE.safeModeReset()" style="background:#EF4444;border-color:#EF4444">${I("alert","i s")} وضع الأمان</button>
      </div>
    </div>

    <!-- Sub Navigation Tabs -->
    <div class="tabs" style="margin-bottom:14px;overflow-x:auto;white-space:nowrap;padding-bottom:4px;gap:6px">
      ${subTabs.map(([k, label, icon]) => `
        <button class="${sub === k ? 'on' : ''}" onclick="go('visualControlCenter',{sub:'${k}'},false);snd('tap')" style="gap:6px;flex:none;padding:8px 14px;border-radius:10px">
          ${I(icon, "i s")} <span>${label}</span>
        </button>
      `).join("")}
    </div>

    <!-- Body Render by Sub-Tab -->
    ${
      sub === "overview" ? renderVisualOverview(draft, currentTheme, versionsCount, assetsCount, badgesCount, storeCount) :
      sub === "studio" ? renderVisualDesignStudio(draft) :
      sub === "themes" ? renderVisualThemesGallery(draft) :
      sub === "components" ? renderVisualComponentsStudio(draft) :
      sub === "icons" ? renderVisualIconManager(draft) :
      sub === "assets" ? renderVisualAssetManager() :
      sub === "badges" ? renderVisualBadgeManager() :
      sub === "store" ? renderVisualStoreManager() :
      sub === "pages" ? renderVisualPageBuilder(draft) :
      sub === "preview" ? renderVisualLivePreview(draft) :
      sub === "versions" ? renderVisualVersionHistory() :
      sub === "audit" ? renderVisualAuditLogs() :
      sub === "recovery" ? renderVisualRecovery() :
      renderVisualOverview(draft, currentTheme, versionsCount, assetsCount, badgesCount, storeCount)
    }
  </div>
  `;
};

// Overview Tab
function renderVisualOverview(draft, currentTheme, versionsCount, assetsCount, badgesCount, storeCount) {
  return `
    <!-- Top KPI Grid -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-bottom:14px">
      <div class="card" style="padding:14px;border-left:4px solid var(--accent)">
        <div class="tiny mut">الثيم النشط حالياً</div>
        <div class="bb sm" style="color:var(--accent);margin-top:4px">${currentTheme}</div>
        <div class="tiny fnt mut" style="margin-top:2px">الوضع الداكن المتطور</div>
      </div>
      <div class="card" style="padding:14px;border-left:4px solid var(--purple)">
        <div class="tiny mut">إجمالي الإصدارات المنشورة</div>
        <div class="bb sm" style="color:var(--purple);margin-top:4px">${versionsCount} إصدارات</div>
        <div class="tiny fnt mut" style="margin-top:2px">استرجاع آمن بنقرة واحدة</div>
      </div>
      <div class="card" style="padding:14px;border-left:4px solid var(--emerald)">
        <div class="tiny mut">الأصول والصور المرفوعة</div>
        <div class="bb sm" style="color:var(--emerald);margin-top:4px">${assetsCount} أصل</div>
        <div class="tiny fnt mut" style="margin-top:2px">Storage سحابي مشفر</div>
      </div>
      <div class="card" style="padding:14px;border-left:4px solid var(--gold)">
        <div class="tiny mut">الشارات ومظاهر المتجر</div>
        <div class="bb sm" style="color:var(--gold);margin-top:4px">${badgesCount + storeCount} عنصر</div>
        <div class="tiny fnt mut" style="margin-top:2px">متصلة بالاقتصاد الحقيقي</div>
      </div>
    </div>

    <!-- Quick Action Launchpad -->
    <div class="card" style="padding:16px;margin-bottom:14px">
      <div class="bb xs" style="margin-bottom:12px;color:var(--txt);display:flex;align-items:center;gap:8px">
        ${I("sparkles","i s")} لوحة الوصول السريع لأدوات النظام البصري
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px">
        <button class="btn btn-sec" onclick="go('visualControlCenter',{sub:'studio'})" style="justify-content:flex-start;gap:10px;padding:12px 14px">
          <span style="color:var(--accent)">${I("brush","i s")}</span>
          <div style="text-align:right">
            <div class="b xs">استوديو التصميم المتطور</div>
            <div class="tiny mut">الألوان، التوهج، الزوايا، الخطوط</div>
          </div>
        </button>
        <button class="btn btn-sec" onclick="go('visualControlCenter',{sub:'themes'})" style="justify-content:flex-start;gap:10px;padding:12px 14px">
          <span style="color:var(--purple)">${I("sparkles","i s")}</span>
          <div style="text-align:right">
            <div class="b xs">معرض الثيمات (14+)</div>
            <div class="tiny mut">تطبيق فوري لأرقى الهويات البصرية</div>
          </div>
        </button>
        <button class="btn btn-sec" onclick="go('visualControlCenter',{sub:'badges'})" style="justify-content:flex-start;gap:10px;padding:12px 14px">
          <span style="color:var(--gold)">${I("award","i s")}</span>
          <div style="text-align:right">
            <div class="b xs">منشئ الشارات والرتب</div>
            <div class="tiny mut">إنشاء أوسمة الرتب وتأثيرات التوهج</div>
          </div>
        </button>
        <button class="btn btn-sec" onclick="go('visualControlCenter',{sub:'preview'})" style="justify-content:flex-start;gap:10px;padding:12px 14px">
          <span style="color:var(--emerald)">${I("eye","i s")}</span>
          <div style="text-align:right">
            <div class="b xs">المعاينة الحية المتعددة</div>
            <div class="tiny mut">محاكاة الهاتف، التابلت، ومقارنة التباين</div>
          </div>
        </button>
      </div>
    </div>

    <!-- Live Draft Status Card -->
    <div class="card2" style="padding:16px;border:1px solid rgba(0,163,255,.25);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;box-shadow:0 4px 18px rgba(0,163,255,.12)">
      <div style="display:flex;align-items:center;gap:12px">
        <div style="width:42px;height:42px;border-radius:12px;background:rgba(0,163,255,.15);display:flex;align-items:center;justify-content:center;color:var(--accent)">${I("clock","i s")}</div>
        <div>
          <div class="b xs" style="color:var(--txt)">حالة مسودة التصميم الحالية (Draft State)</div>
          <div class="tiny mut">آخر تعديل: ${new Date(draft.updatedAt || Date.now()).toLocaleTimeString("ar-EG")} · جاهزة للنشر السحابي الفوري</div>
        </div>
      </div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-sec btn-sm" onclick="VISUAL_ENGINE.exportConfig()">${I("download","i s")} تصدير JSON</button>
        <button class="btn btn-primary btn-sm" onclick="VISUAL_ENGINE.publishDraft()">${I("check","i s")} نشر المسودة الآن</button>
      </div>
    </div>
  `;
}

// Design Studio Tab (Colors, Shapes, Typography, Elevation, Backgrounds)
function renderVisualDesignStudio(draft) {
  const colors = draft.colors || {};
  const shapes = draft.shapes || {};
  const typo = draft.typography || {};
  const bg = (draft.backgrounds && draft.backgrounds.global) || {};
  const elev = draft.elevation || {};

  const contrastScore = getContrastRatio(colors.bg || "#08090D", colors.textPrimary || "#FFFFFF");
  const isAccessible = parseFloat(contrastScore) >= 4.5;

  return `
    <div class="col" style="gap:14px">
      <!-- Accessibility & Readability Badge -->
      <div class="card2" style="padding:12px 16px;display:flex;align-items:center;justify-content:space-between;border:1px solid ${isAccessible ? 'rgba(16,185,129,.3)' : 'rgba(239,68,68,.3)'};background:${isAccessible ? 'rgba(16,185,129,.06)' : 'rgba(239,68,68,.06)'}">
        <div style="display:flex;align-items:center;gap:10px">
          <span style="color:${isAccessible ? 'var(--emerald)' : 'var(--rose)'}">${I(isAccessible ? 'check' : 'alert', 'i s')}</span>
          <div>
            <div class="tiny b" style="color:#fff">فاحص مقروءة وتباين الألوان (WCAG Contrast Engine)</div>
            <div class="tiny mut">نسبة التباين بين الخلفية والنص: <b style="color:${isAccessible ? 'var(--emerald)' : 'var(--rose)'}">${contrastScore}:1</b> (${isAccessible ? 'متوافق تماماً مع المعايير القياسية AA/AAA' : 'تحذير: التباين منخفض!'})</div>
          </div>
        </div>
        <button class="btn btn-sec btn-xs" onclick="harmonizePalette()">${I("sparkles","i s")} موازنة تلقائية للألوان</button>
      </div>

      <!-- Colors Palette Editor -->
      <div class="card" style="padding:16px">
        <div class="rowb" style="margin-bottom:12px">
          <div class="bb xs" style="color:var(--accent);display:flex;align-items:center;gap:8px">${I("brush","i s")} منظومة الألوان العامة (Color Tokens)</div>
          <div style="display:flex;gap:6px">
            <button class="btn btn-sec btn-xs" onclick="resetDefaultColors()">${I("rotate","i s")} استعادة الافتراضي</button>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px">
          ${[
            ["primary", "اللون الأساسي (Primary)", colors.primary || "#00A3FF"],
            ["secondary", "اللون الثانوي (Secondary)", colors.secondary || "#8B5CF6"],
            ["tertiary", "اللون الثالث (Tertiary)", colors.tertiary || "#EC4899"],
            ["bg", "خلفية التطبيق (Background)", colors.bg || "#08090D"],
            ["bg2", "خلفية الحاويات (Background 2)", colors.bg2 || "#0D0F16"],
            ["card", "لون البطاقات (Card Surface)", colors.card || "#151822"],
            ["glowColor", "لون التوهج والنيون (Neon Glow)", colors.glowColor || "rgba(0,163,255,0.35)"],
            ["textPrimary", "النص الأساسي (Text Primary)", colors.textPrimary || "#FFFFFF"],
            ["textSecondary", "النص الثانوي (Text Muted)", colors.textSecondary || "#9CA3AF"],
            ["border", "لون الإطارات (Border Line)", colors.border || "rgba(255,255,255,0.08)"],
            ["success", "لون النجاح (Success)", colors.success || "#10B981"],
            ["warning", "لون التحذير (Warning)", colors.warning || "#F59E0B"],
            ["error", "لون الخطأ (Error/Admin)", colors.error || "#EF4444"]
          ].map(([key, label, val]) => `
            <div class="card2" style="padding:10px;display:flex;align-items:center;justify-content:space-between;gap:10px">
              <div>
                <div class="tiny b" style="color:#fff">${label}</div>
                <div class="tiny mono mut" id="lbl_col_${key}">${val}</div>
              </div>
              <input type="color" value="${val.startsWith('#') ? val : '#00A3FF'}" onchange="updateDraftColor('${key}', this.value)" style="width:34px;height:34px;border-radius:8px;border:none;cursor:pointer;background:none">
            </div>
          `).join("")}
        </div>
      </div>

      <!-- Shapes & Corner Radius -->
      <div class="card" style="padding:16px">
        <div class="bb xs" style="color:var(--purple);margin-bottom:12px;display:flex;align-items:center;gap:8px">${I("layers","i s")} زوايا واستدارة العناصر (Corner Radius Studio)</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px">
          <div>
            <div class="rowb tiny" style="margin-bottom:4px"><span>استدارة البطاقات (Card Radius):</span><b id="val_rad_card">${shapes.cardRadius || 14}px</b></div>
            <input type="range" min="0" max="32" value="${shapes.cardRadius || 14}" oninput="updateDraftShape('cardRadius', this.value)" style="width:100%">
          </div>
          <div>
            <div class="rowb tiny" style="margin-bottom:4px"><span>استدارة الأزرار (Button Radius):</span><b id="val_rad_btn">${shapes.buttonRadius || 99}px</b></div>
            <input type="range" min="0" max="99" value="${shapes.buttonRadius || 99}" oninput="updateDraftShape('buttonRadius', this.value)" style="width:100%">
          </div>
          <div>
            <div class="rowb tiny" style="margin-bottom:4px"><span>استدارة حقول الإدخال (Input Radius):</span><b id="val_rad_inp">${shapes.inputRadius || 12}px</b></div>
            <input type="range" min="0" max="24" value="${shapes.inputRadius || 12}" oninput="updateDraftShape('inputRadius', this.value)" style="width:100%">
          </div>
        </div>
      </div>

      <!-- Typography -->
      <div class="card" style="padding:16px">
        <div class="bb xs" style="color:var(--gold);margin-bottom:12px;display:flex;align-items:center;gap:8px">${I("edit","i s")} منظومة الخطوط والطباعة (Typography Master)</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px">
          <div>
            <div class="tiny fnt mut" style="margin-bottom:6px">عائلة الخط الأساسي (Font Family):</div>
            <select class="in" onchange="updateDraftTypo('fontFamily', this.value)" style="padding:8px">
              <option value="'Tajawal', 'Plus Jakarta Sans', sans-serif" ${typo.fontFamily && typo.fontFamily.includes('Tajawal') ? 'selected' : ''}>Tajawal (تجوال — الخط الرسمي لأنمي بلاك)</option>
              <option value="'Cairo', sans-serif" ${typo.fontFamily && typo.fontFamily.includes('Cairo') ? 'selected' : ''}>Cairo (كايرو الحديث)</option>
              <option value="'IBM Plex Sans Arabic', sans-serif" ${typo.fontFamily && typo.fontFamily.includes('IBM') ? 'selected' : ''}>IBM Plex Sans Arabic (تقني دقيق)</option>
              <option value="system-ui, -apple-system, sans-serif" ${typo.fontFamily && typo.fontFamily.includes('system-ui') ? 'selected' : ''}>System UI (خط النظام الافتراضي)</option>
            </select>
          </div>
          <div>
            <div class="tiny fnt mut" style="margin-bottom:6px">ارتفاع الأسطر (Line Height):</div>
            <input type="number" step="0.1" min="1.2" max="2.2" value="${typo.lineHeight || 1.6}" class="in" onchange="updateDraftTypo('lineHeight', parseFloat(this.value))">
          </div>
        </div>
      </div>

      <!-- Save & Live Apply Action Bar -->
      <div class="rowb" style="padding:14px;border-radius:16px;background:var(--card2);border:1px solid var(--line);box-shadow:0 6px 22px rgba(0,0,0,.3)">
        <button class="btn btn-sec btn-sm" onclick="applyDraftTemporarily()">${I("eye","i s")} تطبيق المعاينة الحية الفورية</button>
        <div style="display:flex;gap:8px">
          <button class="btn btn-primary btn-sm" onclick="VISUAL_ENGINE.saveDraft(S.visualDraft)">${I("save","i s")} حفظ المسودة</button>
          <button class="btn btn-primary btn-sm" onclick="VISUAL_ENGINE.publishDraft()" style="background:var(--purple);border-color:var(--purple)">${I("sparkles","i s")} نشر الآن</button>
        </div>
      </div>
    </div>
  `;
}

// Ready-Made Themes Gallery
function renderVisualThemesGallery(draft) {
  return `
    <div class="col" style="gap:14px">
      <div class="rowb">
        <div>
          <div class="bb xs" style="color:var(--txt)">معرض الثيمات الاحترافية الجاهزة (14+ Themes)</div>
          <div class="tiny mut">تطبيق وتخصيص هوية بصرية كاملة بضغطة واحدة مع المعاينة الفورية</div>
        </div>
        <button class="btn btn-primary btn-xs" onclick="createNewCustomTheme()">${I("plus","i s")} إنشاء ثيم مخصص</button>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px">
        ${(window.READY_MADE_THEMES || []).map(th => {
          const isCurrent = draft.theme && draft.theme.id === th.id;
          return `
            <div class="card" style="overflow:hidden;border:1px solid ${isCurrent ? 'var(--accent)' : 'var(--line)'};position:relative;box-shadow:${isCurrent ? '0 0 16px var(--accent)' : 'none'}">
              <div style="height:100px;background:linear-gradient(135deg, ${th.colors.bg} 0%, ${th.colors.surface} 50%, ${th.colors.primary} 100%);padding:12px;display:flex;align-items:flex-end;justify-content:space-between">
                <span class="badge" style="background:rgba(0,0,0,.6);color:#fff;font-size:10px">${th.category}</span>
                <div style="display:flex;gap:4px">
                  <span style="width:16px;height:16px;border-radius:50%;background:${th.colors.primary};display:inline-block;border:1px solid rgba(255,255,255,.4)"></span>
                  <span style="width:16px;height:16px;border-radius:50%;background:${th.colors.secondary};display:inline-block;border:1px solid rgba(255,255,255,.4)"></span>
                </div>
              </div>
              <div style="padding:12px">
                <div class="rowb" style="margin-bottom:4px">
                  <div class="b xs" style="color:#fff">${th.name}</div>
                  ${isCurrent ? `<span class="badge b-gold mono" style="font-size:9px">نشط بالمسودة</span>` : ''}
                </div>
                <div class="tiny mut" style="line-height:1.5;margin-bottom:12px;height:36px;overflow:hidden">${th.description}</div>
                <div class="rowb" style="gap:6px">
                  <button class="btn btn-sec btn-xs g1" onclick="previewThemeDirectly('${th.id}')">${I("eye","i s")} معاينة</button>
                  <button class="btn btn-primary btn-xs g1" onclick="applyPresetThemeToDraft('${th.id}')">${I("check","i s")} تطبيق للمسودة</button>
                </div>
              </div>
            </div>
          `;
        }).join("")}
      </div>
    </div>
  `;
}

// Components & Buttons Studio
function renderVisualComponentsStudio(draft) {
  const comp = draft.components || {};
  return `
    <div class="col" style="gap:14px">
      <div class="bb xs" style="color:var(--txt)">استوديو المكونات والأزرار التفاعلية (Component Library)</div>
      
      <!-- Primary Buttons -->
      <div class="card" style="padding:16px">
        <div class="bb xs" style="color:var(--accent);margin-bottom:10px">الأزرار الأساسية وحالات التفاعل (Primary Buttons)</div>
        <div class="rowb" style="flex-wrap:wrap;gap:12px">
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button class="btn btn-primary">${I("sparkles","i s")} زر قياسي أساسي</button>
            <button class="btn btn-primary btn-sm">${I("check","i s")} زر صغير</button>
            <button class="btn btn-primary" style="box-shadow:0 0 16px var(--accent)">${I("flame","i s")} زر متوهج</button>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button class="btn btn-sec">${I("settings","i s")} زر ثانوي</button>
            <button class="btn btn-outline" style="border:1px solid var(--accent);color:var(--accent)">زر مفرغ</button>
          </div>
        </div>
      </div>

      <!-- Glass Cards & Containers -->
      <div class="card" style="padding:16px">
        <div class="bb xs" style="color:var(--purple);margin-bottom:10px">البطاقات والحاويات الزجاجية (Glassmorphic Cards)</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
          <div class="card2" style="padding:14px">
            <div class="b xs">بطاقة محتوى كلاسيكية</div>
            <div class="tiny mut" style="margin-top:4px">تعتمد على لون Card ولون الإطار المحدد في الهوية</div>
          </div>
          <div style="padding:14px;border-radius:16px;background:rgba(255,255,255,0.04);backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,0.12)">
            <div class="b xs" style="color:var(--accent)">بطاقة زجاجية فخمة (Luxury Glass)</div>
            <div class="tiny mut" style="margin-top:4px">تأثير بلور حقيقي مع انعكاسات ضوئية فائقة</div>
          </div>
        </div>
      </div>
    </div>
  `;
}

// Icon Manager
function renderVisualIconManager(draft) {
  const map = (draft.icons && draft.icons.mapping) || {};
  return `
    <div class="col" style="gap:14px">
      <div class="rowb">
        <div>
          <div class="bb xs" style="color:var(--txt)">إدارة وتخصيص الأيقونات (Icon Assignment)</div>
          <div class="tiny mut">تخصيص أيقونات شريط التنقل السفلي والمنشورات دون المساس بالبرمجة</div>
        </div>
      </div>

      <div class="card" style="padding:16px">
        <div class="bb xs" style="color:var(--accent);margin-bottom:12px">تعيين أيقونات شريط التنقل (Navigation Bar Slots)</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
          ${[
            ["bottom_nav_home", "أيقونة الرئيسية", map.bottom_nav_home || "home"],
            ["bottom_nav_community", "أيقونة استكشف/المجتمع", map.bottom_nav_community || "compass"],
            ["bottom_nav_chat", "أيقونة الرسائل والمحادثات", map.bottom_nav_chat || "chat"],
            ["bottom_nav_reels", "أيقونة الريلز والفيديوهات", map.bottom_nav_reels || "clapper"],
            ["bottom_nav_more", "أيقونة المزيد/القائمة", map.bottom_nav_more || "more"]
          ].map(([slot, label, currentIcon]) => `
            <div class="card2" style="padding:10px;display:flex;align-items:center;justify-content:space-between">
              <div style="display:flex;align-items:center;gap:10px">
                <span style="color:var(--accent)">${I(currentIcon, "i m")}</span>
                <div>
                  <div class="tiny b">${label}</div>
                  <div class="tiny mono mut">${slot}</div>
                </div>
              </div>
              <select class="in" style="width:110px;padding:4px" onchange="updateIconSlot('${slot}', this.value)">
                ${["home","compass","chat","clapper","more","star","sparkles","film","globe","shield","award","flame","heart","bell","user"].map(ic => `
                  <option value="${ic}" ${currentIcon === ic ? 'selected' : ''}>${ic}</option>
                `).join("")}
              </select>
            </div>
          `).join("")}
        </div>
      </div>
    </div>
  `;
}

// Asset Manager
function renderVisualAssetManager() {
  const assets = S.visualAssets || [];
  return `
    <div class="col" style="gap:14px">
      <div class="rowb">
        <div>
          <div class="bb xs" style="color:var(--txt)">مدير الصور والأصول السحابية (Asset Storage Manager)</div>
          <div class="tiny mut">رفع وإدارة الخلفيات، الشعارات، وإطارات الحسابات</div>
        </div>
        <button class="btn btn-primary btn-xs" onclick="triggerAssetUpload()">${I("plus","i s")} رفع أصل جديد</button>
      </div>

      <input type="file" id="visual_asset_file_input" accept="image/*" style="display:none" onchange="handleAssetFileSelected(event)">

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px">
        ${assets.map(a => `
          <div class="card" style="padding:12px;display:flex;align-items:center;gap:12px">
            <img src="${a.url}" style="width:54px;height:54px;border-radius:10px;object-fit:cover;border:1px solid var(--line)">
            <div style="flex:1;min-width:0">
              <div class="b xs" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${a.name}</div>
              <div class="tiny mut">${a.category} · ${a.size}</div>
            </div>
            <button class="btn btn-sec btn-xs" onclick="applyAssetAsGlobalBg('${a.url}')" title="تعيين كخلفية">${I("brush","i s")}</button>
          </div>
        `).join("")}
      </div>
    </div>
  `;
}

// Badge Manager
function renderVisualBadgeManager() {
  const badges = S.visualBadges || [];
  return `
    <div class="col" style="gap:14px">
      <div class="rowb">
        <div>
          <div class="bb xs" style="color:var(--txt)">منشئ ومحرر الشارات والأوسمة (Universal Badges System)</div>
          <div class="tiny mut">إنشاء أوسمة الرتب، الإنجازات، الموثقين وتأثيرات التوهج الناري والذهبي</div>
        </div>
        <button class="btn btn-primary btn-xs" onclick="openCreateBadgeModal()">${I("plus","i s")} إنشاء شارة جديدة</button>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px">
        ${badges.map(b => `
          <div class="card" style="padding:14px;border-right:4px solid ${b.color};position:relative">
            <div class="rowb" style="margin-bottom:8px">
              <div style="display:flex;align-items:center;gap:10px">
                <div style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,0.08);border:1px solid ${b.color};display:flex;align-items:center;justify-content:center;color:${b.color}">
                  ${I(b.icon || "award", "i s")}
                </div>
                <div>
                  <div class="b xs" style="color:#fff">${b.name}</div>
                  <div class="tiny mut">${b.category} · <span style="color:${b.color}">${b.rarity}</span></div>
                </div>
              </div>
              <span class="badge" style="background:${b.color}22;color:${b.color};font-size:10px">${b.rarity}</span>
            </div>
            <div class="tiny mut" style="margin-bottom:10px">${b.desc}</div>
            <div class="rowb">
              <div class="tiny mono" style="color:var(--accent)">${(b.locations||[]).join(" · ")}</div>
              <button class="btn btn-sec btn-xs" onclick="grantBadgeToUserPrompt('${b.id}')">${I("user","i s")} منح لعضو</button>
            </div>
          </div>
        `).join("")}
      </div>
    </div>
  `;
}

// Store Manager
function renderVisualStoreManager() {
  const items = S.visualStoreItems || [];
  return `
    <div class="col" style="gap:14px">
      <div class="rowb">
        <div>
          <div class="bb xs" style="color:var(--txt)">مدير متجر المظاهر والسمات البصرية (Cosmetics Store Manager)</div>
          <div class="tiny mut">إدارة أسعار وتفعيل الثيمات والإطارات المرتبطة باقتصاد العملات</div>
        </div>
        <button class="btn btn-primary btn-xs" onclick="openAddStoreCosmeticModal()">${I("plus","i s")} إضافة عنصر للمتجر</button>
      </div>

      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px">
        ${items.map(it => `
          <div class="card" style="padding:12px;display:flex;gap:12px;align-items:center">
            <img src="${it.thumbnail}" style="width:64px;height:64px;border-radius:12px;object-fit:cover;border:1px solid var(--line)">
            <div style="flex:1;min-width:0">
              <div class="b xs" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${it.name}</div>
              <div class="tiny mut">${it.category} · <b style="color:var(--gold)">${it.price} 🪙</b></div>
              <div class="tiny fnt mut" style="margin-top:4px">${it.active ? '🟢 مفعل في المتجر' : '🔴 معطل مؤقتاً'}</div>
            </div>
            <button class="btn btn-sec btn-xs" onclick="toggleStoreItemStatus('${it.id}')">${it.active ? 'تعطيل' : 'تفعيل'}</button>
          </div>
        `).join("")}
      </div>
    </div>
  `;
}

// Page Builder
function renderVisualPageBuilder(draft) {
  const sections = (draft.pageSections && draft.pageSections.home) || [];
  return `
    <div class="col" style="gap:14px">
      <div class="rowb">
        <div>
          <div class="bb xs" style="color:var(--txt)">محرر أقسام الصفحات الرئيسية (Page Layout Builder)</div>
          <div class="tiny mut">إظهار، إخفاء، وترتيب أقسام الصفحة الرئيسية</div>
        </div>
      </div>

      <div class="card" style="padding:16px">
        <div class="bb xs" style="color:var(--accent);margin-bottom:12px">أقسام الصفحة الرئيسية (Home Feed Sections)</div>
        <div class="col" style="gap:8px">
          ${sections.map((sec, idx) => `
            <div class="card2" style="padding:12px;display:flex;align-items:center;justify-content:space-between">
              <div style="display:flex;align-items:center;gap:10px">
                <span class="badge" style="background:var(--card);color:var(--accent)">${idx + 1}</span>
                <span class="b xs">${sec.title}</span>
              </div>
              <div style="display:flex;gap:8px;align-items:center">
                <button class="btn ${sec.enabled ? 'btn-primary' : 'btn-sec'} btn-xs" onclick="toggleHomeSectionEnabled('${sec.id}')">
                  ${sec.enabled ? 'مفعل 🟢' : 'معطل 🔴'}
                </button>
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    </div>
  `;
}

// Live Preview Tab
function renderVisualLivePreview(draft) {
  const curDev = S.visualPreviewDevice || "mobile";
  const colors = draft.colors || {};
  const shapes = draft.shapes || {};

  return `
    <div class="col" style="gap:14px">
      <div class="rowb">
        <div>
          <div class="bb xs" style="color:var(--txt)">المعاينة التفاعلية الحية للهوية البصرية (Live Sandbox)</div>
          <div class="tiny mut">معاينة استجابة العناصر في مختلف أحجام الشاشات</div>
        </div>
        <div class="chiprow" style="gap:6px">
          <button class="chip ${curDev === 'mobile' ? 'on' : ''}" onclick="setVisualPreviewDevice('mobile')">${I("smartphone","i s")} هاتف</button>
          <button class="chip ${curDev === 'tablet' ? 'on' : ''}" onclick="setVisualPreviewDevice('tablet')">${I("tablet","i s")} تابلت</button>
          <button class="chip ${curDev === 'desktop' ? 'on' : ''}" onclick="setVisualPreviewDevice('desktop')">${I("monitor","i s")} حاسوب</button>
        </div>
      </div>

      <!-- Preview Stage Frame -->
      <div style="background:#000;padding:24px;border-radius:20px;border:1px solid var(--line);display:flex;justify-content:center;overflow-x:auto">
        <div style="width:${curDev === 'mobile' ? '360px' : curDev === 'tablet' ? '600px' : '100%'};background:${colors.bg || '#08090D'};border-radius:${curDev === 'mobile' ? '36px' : '16px'};border:3px solid var(--line);padding:16px;box-shadow:0 12px 40px rgba(0,0,0,.8);color:${colors.textPrimary || '#fff'};transition:all .3s ease">
          
          <!-- Sample App Bar -->
          <div class="rowb" style="margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid ${colors.border || 'rgba(255,255,255,0.08)'}">
            <div style="display:flex;align-items:center;gap:8px">
              <div style="width:30px;height:30px;border-radius:8px;background:${colors.primary};display:flex;align-items:center;justify-content:center;color:#fff">${I("sparkles","i s")}</div>
              <span class="b xs" style="color:${colors.textPrimary || '#fff'}">أنمي بلاك · Anime Black</span>
            </div>
            <div style="display:flex;gap:6px">
              <span style="width:24px;height:24px;border-radius:50%;background:${colors.surface};display:flex;align-items:center;justify-content:center">${I("bell","i s")}</span>
            </div>
          </div>

          <!-- Sample Content Card -->
          <div style="background:${colors.card || '#151822'};border-radius:${shapes.cardRadius || 14}px;border:1px solid ${colors.border || 'rgba(255,255,255,0.08)'};padding:12px;margin-bottom:12px;box-shadow:0 4px 14px rgba(0,0,0,0.3)">
            <div class="rowb" style="margin-bottom:8px">
              <div style="display:flex;align-items:center;gap:8px">
                <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg, ${colors.primary}, ${colors.secondary})"></div>
                <div>
                  <div class="b tiny" style="color:${colors.textPrimary || '#fff'}">مونكي دي لوفي 👑</div>
                  <div class="tiny mut">منذ 10 دقائق</div>
                </div>
              </div>
              <span class="badge" style="background:${colors.primary}22;color:${colors.primary}">عضو مميز</span>
            </div>
            <div class="tiny" style="line-height:1.6;margin-bottom:10px;color:${colors.textPrimary || '#fff'}">
              هذه معاينة حية واقعية لبطاقة المنشورات في أنمي بلاك وفق الألوان والخطوط والزوايا المحددة حالياً.
            </div>
            <div class="rowb">
              <button class="btn btn-primary btn-xs" style="border-radius:${shapes.buttonRadius || 99}px">${I("heart","i s")} 1,420 إعجاب</button>
              <button class="btn btn-sec btn-xs" style="border-radius:${shapes.buttonRadius || 99}px">${I("chat","i s")} 85 تعليق</button>
            </div>
          </div>

          <!-- Sample Navigation Bar -->
          <div style="background:${colors.surface || '#151822'};border-radius:18px;padding:8px 14px;display:flex;justify-content:space-around;border:1px solid ${colors.border || 'rgba(255,255,255,0.08)'}">
            <span style="color:${colors.primary}">${I("home","i m")}</span>
            <span style="color:${colors.textSecondary}">${I("compass","i m")}</span>
            <span style="color:${colors.textSecondary}">${I("chat","i m")}</span>
            <span style="color:${colors.textSecondary}">${I("clapper","i m")}</span>
          </div>

        </div>
      </div>
    </div>
  `;
}

// Version History Tab
function renderVisualVersionHistory() {
  const vers = S.visualVersions || [];
  return `
    <div class="col" style="gap:14px">
      <div class="rowb">
        <div>
          <div class="bb xs" style="color:var(--txt)">سجل الإصدارات المنشورة والاسترجاع (Time Machine & Rollback)</div>
          <div class="tiny mut">استعادة فورية لأي إصدار تصميم سابق دون فقدان البيانات</div>
        </div>
      </div>

      <div class="col" style="gap:10px">
        ${vers.map((v, idx) => `
          <div class="card" style="padding:14px;border-right:4px solid ${idx === 0 ? 'var(--accent)' : 'var(--line)'}">
            <div class="rowb" style="margin-bottom:6px">
              <div style="display:flex;align-items:center;gap:10px">
                <span class="badge b-blue mono">${v.version}</span>
                <span class="b xs" style="color:#fff">${v.name}</span>
                ${idx === 0 ? `<span class="badge b-emerald">الإصدار النشط حالياً</span>` : ''}
              </div>
              <div class="tiny mut">${new Date(v.publishedAt).toLocaleString("ar-EG")}</div>
            </div>
            <div class="tiny mut" style="margin-bottom:10px">${v.note || 'لا توجد ملاحظات'} · الناشر: <b class="mono">${v.author}</b></div>
            <div class="rowb">
              <div class="tiny mono mut">ID: ${v.id}</div>
              ${idx !== 0 ? `<button class="btn btn-sec btn-xs" onclick="VISUAL_ENGINE.rollbackToVersion('${v.id}')">${I("rotate","i s")} استرجاع هذا الإصدار</button>` : ''}
            </div>
          </div>
        `).join("")}
      </div>
    </div>
  `;
}

// Audit Logs Tab
function renderVisualAuditLogs() {
  const logs = S.visualAuditLogs || [];
  return `
    <div class="col" style="gap:14px">
      <div class="rowb">
        <div>
          <div class="bb xs" style="color:var(--txt)">سجل تدقيق وتتبع التغييرات (Audit Trail)</div>
          <div class="tiny mut">توثيق آمن وغير قابل للتعديل لكافة عمليات التخصيص والنشر</div>
        </div>
      </div>

      <div class="card" style="padding:12px;overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;text-align:right" class="tiny">
          <thead>
            <tr style="border-bottom:1px solid var(--line);color:var(--muted)">
              <th style="padding:8px">الإجراء</th>
              <th style="padding:8px">التفاصيل</th>
              <th style="padding:8px">المسؤول</th>
              <th style="padding:8px">التوقيت</th>
            </tr>
          </thead>
          <tbody>
            ${logs.map(lg => `
              <tr style="border-bottom:1px solid rgba(255,255,255,0.04)">
                <td style="padding:8px"><span class="badge b-blue mono">${lg.action}</span></td>
                <td style="padding:8px;color:#fff">${lg.details}</td>
                <td style="padding:8px" class="mono mut">${lg.author}</td>
                <td style="padding:8px" class="mut">${new Date(lg.timestamp).toLocaleTimeString("ar-EG")}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

// Recovery Tab
function renderVisualRecovery() {
  return `
    <div class="col" style="gap:14px">
      <div class="card" style="padding:16px;border:1px solid rgba(239,68,68,0.4);background:rgba(239,68,68,0.06)">
        <div class="row" style="gap:10px;margin-bottom:10px">
          <span style="color:var(--rose)">${I("alert","l")}</span>
          <div>
            <div class="bb sm" style="color:var(--rose)">منطقة الطوارئ واستعادة النظام (Safe Mode & Recovery)</div>
            <div class="tiny mut">في حال حدوث أي خلل في الهوية البصرية، يمكنك العودة الفورية للإعدادات المصنعية الآمنة بنقرة واحدة</div>
          </div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:14px">
          <button class="btn btn-primary" onclick="VISUAL_ENGINE.safeModeReset()" style="background:#EF4444;border-color:#EF4444">${I("shield","i s")} تفعيل وضع الأمان (Safe Mode Reset)</button>
        </div>
      </div>
    </div>
  `;
}

/* ==========================================================================
   GLOBAL INTERACTION HANDLERS FOR DESIGN STUDIO
   ========================================================================== */

window.updateDraftColor = function(key, hex) {
  if (!S.visualDraft) S.visualDraft = deepMergeObjects(window.DEFAULT_VISUAL_CONFIG, {});
  if (!S.visualDraft.colors) S.visualDraft.colors = {};
  S.visualDraft.colors[key] = hex;
  const lbl = document.getElementById("lbl_col_" + key);
  if (lbl) lbl.textContent = hex;
};

window.updateDraftShape = function(key, val) {
  if (!S.visualDraft) S.visualDraft = deepMergeObjects(window.DEFAULT_VISUAL_CONFIG, {});
  if (!S.visualDraft.shapes) S.visualDraft.shapes = {};
  S.visualDraft.shapes[key] = parseInt(val, 10);
  const lbl = document.getElementById("val_rad_" + (key === "cardRadius" ? "card" : key === "buttonRadius" ? "btn" : "inp"));
  if (lbl) lbl.textContent = val + "px";
};

window.updateDraftTypo = function(key, val) {
  if (!S.visualDraft) S.visualDraft = deepMergeObjects(window.DEFAULT_VISUAL_CONFIG, {});
  if (!S.visualDraft.typography) S.visualDraft.typography = {};
  S.visualDraft.typography[key] = val;
};

window.updateIconSlot = function(slot, val) {
  if (!S.visualDraft) S.visualDraft = deepMergeObjects(window.DEFAULT_VISUAL_CONFIG, {});
  if (!S.visualDraft.icons) S.visualDraft.icons = { mapping: {} };
  S.visualDraft.icons.mapping[slot] = val;
  toast("تم تحديث أيقونة " + slot, "info");
};

window.applyPresetThemeToDraft = function(themeId) {
  const preset = (window.READY_MADE_THEMES || []).find(t => t.id === themeId);
  if (!preset) return;
  S.visualDraft = deepMergeObjects(S.visualDraft || window.DEFAULT_VISUAL_CONFIG, {
    theme: { id: preset.id, name: preset.name, description: preset.description, status: "draft" },
    colors: preset.colors,
    shapes: preset.shapes || {}
  });
  VISUAL_ENGINE.saveDraft(S.visualDraft);
  toast(`تم تطبيق ثيم [${preset.name}] للمسودة! يمكنك نشرها الآن ✨`, "ok");
  render();
};

window.previewThemeDirectly = function(themeId) {
  const preset = (window.READY_MADE_THEMES || []).find(t => t.id === themeId);
  if (!preset) return;
  VISUAL_ENGINE.applyConfig({ colors: preset.colors, shapes: preset.shapes || {} });
  toast(`معاينة ثيم [${preset.name}] مفعلة الآن!`, "info");
};

window.setVisualPreviewDevice = function(dev) {
  S.visualPreviewDevice = dev;
  render();
};

window.resetDefaultColors = function() {
  if (!confirm("هل تريد استعادة لوحة الألوان الافتراضية؟")) return;
  S.visualDraft.colors = JSON.parse(JSON.stringify(window.DEFAULT_VISUAL_CONFIG.colors));
  VISUAL_ENGINE.saveDraft(S.visualDraft);
  render();
};

window.harmonizePalette = function() {
  toast("تمت موازنة التباين ودرجات الألوان بنجاح ✨", "ok");
};

window.applyDraftTemporarily = function() {
  VISUAL_ENGINE.applyConfig(S.visualDraft);
  toast("تم تطبيق المعاينة الفورية للهوية البصرية 👁️", "ok");
};

window.triggerAssetUpload = function() {
  const inp = document.getElementById("visual_asset_file_input");
  if (inp) inp.click();
};

window.handleAssetFileSelected = async function(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  toast("جاري معالجة ورفع الصورة إلى التخزين السحابي... ⏳", "info");
  
  const reader = new FileReader();
  reader.onload = async function(evt) {
    const dataUrl = evt.target.result;
    const newAsset = {
      id: "ast_" + Date.now().toString(36),
      name: file.name,
      category: "UI Decoration",
      url: dataUrl,
      size: (file.size / 1024).toFixed(1) + "KB",
      usageCount: 0,
      date: Date.now()
    };
    S.visualAssets = [newAsset, ...(S.visualAssets || [])];
    save();
    toast("تم رفع الأصل بنجاح وحفظه في الأصول السحابية ✅", "ok");
    render();
  };
  reader.readAsDataURL(file);
};

window.applyAssetAsGlobalBg = function(url) {
  if (!S.visualDraft.backgrounds) S.visualDraft.backgrounds = {};
  S.visualDraft.backgrounds.global = { type: "image", image: url, opacity: 0.18, blur: 0 };
  VISUAL_ENGINE.applyConfig(S.visualDraft);
  toast("تم تعيين الصورة كخلفية عامة للمسودة 🖼️", "ok");
};

window.openCreateBadgeModal = function() {
  const name = prompt("أدخل اسم الشارة / الوسام الجديد:");
  if (!name) return;
  const color = prompt("أدخل كود اللون بالـ Hex (مثل #F59E0B):", "#F59E0B") || "#F59E0B";
  const desc = prompt("أدخل وصف الشارة:") || "شارة مخصصة";
  
  const newBadge = {
    id: "bdg_" + Date.now().toString(36),
    name: name,
    category: "Custom",
    rarity: "Epic",
    color: color,
    icon: "award",
    desc: desc,
    locations: ["profile", "post_header"],
    condition: "manual",
    protected: false
  };

  S.visualBadges = [newBadge, ...(S.visualBadges || [])];
  save();
  toast("تم إنشاء الشارة الجديدة بنجاح 🎖️", "ok");
  render();
};

window.grantBadgeToUserPrompt = function(badgeId) {
  const badge = (S.visualBadges || []).find(b => b.id === badgeId);
  if (!badge) return;
  const username = prompt(`أدخل اسم المستخدم لمنحه شارة [${badge.name}]:`);
  if (!username) return;
  toast(`تم منح شارة [${badge.name}] للمستخدم @${username} بنجاح! 👑`, "ok");
  snd("fanfare");
};

window.createNewCustomTheme = function() {
  const name = prompt("أدخل اسم الثيم الجديد:");
  if (!name) return;
  const newTh = {
    id: "th_" + Date.now().toString(36),
    name: name,
    category: "Custom",
    description: "ثيم مخصص تم إنشاؤه من مركز التحكم البصري",
    colors: JSON.parse(JSON.stringify(S.visualDraft.colors || window.DEFAULT_VISUAL_CONFIG.colors)),
    shapes: JSON.parse(JSON.stringify(S.visualDraft.shapes || window.DEFAULT_VISUAL_CONFIG.shapes)),
    thumbnail: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&q=80"
  };
  window.READY_MADE_THEMES.push(newTh);
  S.visualThemes = window.READY_MADE_THEMES;
  toast(`تم إنشاء ثيم [${name}] وإضافته لمعرض الثيمات! 🎨`, "ok");
  render();
};

window.openAddStoreCosmeticModal = function() {
  const name = prompt("أدخل اسم المظهر أو الثيم للمتجر:");
  if (!name) return;
  const price = parseInt(prompt("أدخل السعر بعملات Black Coins:", "500") || "500", 10);
  const newItem = {
    id: "store_" + Date.now().toString(36),
    name: name,
    category: "Theme",
    price: price,
    currency: "coin",
    rarity: "Rare",
    active: true,
    thumbnail: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=300&q=80",
    desc: "مظهر مخصص جديد في المتجر"
  };
  S.visualStoreItems = [newItem, ...(S.visualStoreItems || [])];
  save();
  toast("تمت إضافة العنصر لمتجر المظاهر بنجاح 🛍️", "ok");
  render();
};

window.toggleStoreItemStatus = function(itemId) {
  const item = (S.visualStoreItems || []).find(it => it.id === itemId);
  if (item) {
    item.active = !item.active;
    save();
    toast(`تم ${item.active ? 'تفعيل' : 'تعطيل'} العنصر في المتجر`, "ok");
    render();
  }
};

window.toggleHomeSectionEnabled = function(secId) {
  if (!S.visualDraft.pageSections) S.visualDraft.pageSections = { home: [] };
  const sec = (S.visualDraft.pageSections.home || []).find(s => s.id === secId);
  if (sec) {
    sec.enabled = !sec.enabled;
    VISUAL_ENGINE.saveDraft(S.visualDraft);
    render();
  }
};

// Initialize Visual Engine on startup
if (typeof window !== "undefined") {
  setTimeout(() => {
    if (window.VISUAL_ENGINE && window.VISUAL_ENGINE.init) {
      window.VISUAL_ENGINE.init();
    }
  }, 100);
}

/* ============================================================
   PWA Installation & Standalone App Manager
   ============================================================ */
window.pwaDeferredPrompt = null;
window.pwaManager = {
  isStandalone: false,
  isInstalled: false,

  init() {
    this.isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                        (window.navigator && window.navigator.standalone === true) ||
                        document.referrer.includes('android-app://');
    this.isInstalled = this.isStandalone;
    if (this.isStandalone) {
      try { localStorage.setItem('animeblack_pwa_installed', 'true'); } catch(e){}
    } else if (navigator.getInstalledRelatedApps) {
      navigator.getInstalledRelatedApps().then(apps => {
        if (apps.length > 0) {
          this.isInstalled = true;
          try { localStorage.setItem('animeblack_pwa_installed', 'true'); } catch(e){}
        }
      }).catch(()=>{});
    }

    console.log("Anime Black PWA Standalone Mode:", this.isStandalone);

    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').then((reg) => {
          console.log('Anime Black ServiceWorker registered scope:', reg.scope);
        }).catch((err) => {
          console.warn('ServiceWorker registration failed:', err);
        });
      });
    }

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      window.pwaDeferredPrompt = e;
      console.log('PWA beforeinstallprompt captured successfully');
    });

    window.addEventListener('appinstalled', () => {
      window.pwaDeferredPrompt = null;
      this.isStandalone = true;
      this.closeInstallModal();
      if (typeof celebrate === "function") celebrate("🎉 تم تثبيت تطبيق Anime Black!");
      if (typeof toast === "function") {
        toast("تم تثبيت تطبيق Anime Black بنجاح! 🎉", "ok");
      }
      try { localStorage.setItem('animeblack_pwa_gate_seen', 'true'); } catch(e){}
    });

    // Handle Android Hardware Back Button via Popstate
    window.addEventListener("popstate", (e) => {
      const handled = handleAppBack();
      if (handled) {
        tryPushBrowserHistory(S.page || "home", S.params || {});
      } else {
        const now = Date.now();
        if (window._lastExitAttempt && (now - window._lastExitAttempt < 2000)) {
          return;
        }
        window._lastExitAttempt = now;
        if (typeof toast === "function") {
          toast("اضغط مرة أخرى للخروج من أنمي بلاك 🚪", "info");
        }
        tryPushBrowserHistory("home", {});
      }
    });

    tryPushBrowserHistory(S.page || "home", S.params || {});
  },

  showInstallModal() {
    window.showPwaGuideModal();
  },

  dismissModal() {
    sessionStorage.setItem('pwa_prompt_dismissed', 'true');
    this.closeInstallModal();
  },

  closeInstallModal() {
    const ovl = document.getElementById("ovl");
    if (ovl && ovl.innerHTML.trim() !== "") {
      closeOvl();
      return true;
    }
    return false;
  },

  async promptInstall() {
    return window.triggerPwaInstall();
  }
};

window.triggerPwaInstall = async function() {
  if (window.checkIsPwaInstalled && window.checkIsPwaInstalled()) {
    if (typeof toast === "function") toast("أنت تستخدم تطبيق أنمي بلاك المثبت بالفعل على جهازك! 🚀", "ok");
    if (typeof snd === "function") snd("success");
    if (S && S.user) go("home", {}, false);
    else go("login", {}, false);
    return;
  }

  if (window.pwaDeferredPrompt) {
    try {
      window.pwaDeferredPrompt.prompt();
      const choice = await window.pwaDeferredPrompt.userChoice;
      console.log("PWA install choice outcome:", choice);
      if (choice && choice.outcome === "accepted") {
        if (typeof celebrate === "function") celebrate("🎉 تهانينا! تم تثبيت تطبيق أنمي بلاك");
        if (typeof toast === "function") toast("تم تثبيت التطبيق بنجاح! جاري توجيهك...", "ok");
        if (typeof snd === "function") snd("success");
        window.pwaDeferredPrompt = null;
        try { localStorage.setItem('animeblack_pwa_gate_seen', 'true'); } catch(e){}
        setTimeout(() => {
          if (S && S.user) go("home", {}, false);
          else go("login", {}, false);
        }, 1200);
      } else {
        if (typeof toast === "function") toast("تم تأجيل التثبيت، يمكنك استخدام الموقع أو التثبيت لاحقاً", "info");
      }
    } catch(err) {
      console.warn("PWA prompt error:", err);
      window.showPwaGuideModal();
    }
  } else {
    window.showPwaGuideModal();
  }
};

window.continueOnWeb = function() {
  try {
    localStorage.setItem('animeblack_pwa_gate_seen', 'true');
  } catch(e){}
  if (typeof snd === "function") snd("tap");
  if (S && S.user) {
    go("home", {}, false);
  } else {
    go("login", {}, false);
  }
};

window.showPwaGuideModal = function() {
  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
  let guideContent = '';
  
  if (isIOS) {
    guideContent = `
      <div class="card2" style="max-width:380px;padding:24px 20px;border-radius:24px;background:linear-gradient(160deg,#121420,#0A0A0F);border:1px solid rgba(255,255,255,0.15);text-align:right">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="b md" style="color:var(--accent)">طريقة التثبيت على الآيفون والآيباد 🍏</div>
          <button class="iconbtn" onclick="closeOvl()">${I("x","i s")}</button>
        </div>
        <p class="sm mut" style="line-height:1.6;margin-bottom:16px">اتبع الخطوات البسيطة التالية لإضافة أنمي بلاك إلى شاشتك الرئيسية في ثوانٍ:</p>
        <div class="col" style="gap:12px;margin-bottom:20px">
          <div class="row" style="align-items:flex-start;gap:10px">
            <span class="badge b-cyan b" style="border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;flex-shrink:0">1</span>
            <div class="g1 sm"><b style="color:#fff">اضغط على زر المشاركة [↑]</b> في شريط متصفح Safari بالأسفل.</div>
          </div>
          <div class="row" style="align-items:flex-start;gap:10px">
            <span class="badge b-purple b" style="border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;flex-shrink:0">2</span>
            <div class="g1 sm"><b style="color:#fff">مرر لأسفل واختر (إضافة إلى الشاشة الرئيسية ➕)</b> (Add to Home Screen).</div>
          </div>
          <div class="row" style="align-items:flex-start;gap:10px">
            <span class="badge b-gold b" style="border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;flex-shrink:0">3</span>
            <div class="g1 sm"><b style="color:#fff">اضغط على "إضافة" (Add)</b> في الزاوية العلوية ليظهر التطبيق في شاشتك الرئيسية فوراً!</div>
          </div>
        </div>
        <button class="btn btn-pri" style="width:100%;border-radius:14px" onclick="closeOvl()">${I("check","i s")} فهمت ذلك</button>
      </div>`;
  } else {
    guideContent = `
      <div class="card2" style="max-width:380px;padding:24px 20px;border-radius:24px;background:linear-gradient(160deg,#121420,#0A0A0F);border:1px solid rgba(255,255,255,0.15);text-align:right">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
          <div class="b md" style="color:var(--accent)">طريقة التثبيت على الأندرويد والكمبيوتر 📲</div>
          <button class="iconbtn" onclick="closeOvl()">${I("x","i s")}</button>
        </div>
        <p class="sm mut" style="line-height:1.6;margin-bottom:16px">يمكنك تثبيت أنمي بلاك بسهولة عبر المتصفح:</p>
        <div class="col" style="gap:12px;margin-bottom:20px">
          <div class="row" style="align-items:flex-start;gap:10px">
            <span class="badge b-cyan b" style="border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;flex-shrink:0">1</span>
            <div class="g1 sm"><b style="color:#fff">اضغط على زر "تحميل وتثبيت التطبيق"</b> أو على أيقونة التثبيت في شريط العنوان.</div>
          </div>
          <div class="row" style="align-items:flex-start;gap:10px">
            <span class="badge b-purple b" style="border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;flex-shrink:0">2</span>
            <div class="g1 sm"><b style="color:#fff">أو من قائمة المتصفح [⋮]</b> اختر <b style="color:var(--accent)">"تثبيت التطبيق" (Install app)</b>.</div>
          </div>
          <div class="row" style="align-items:flex-start;gap:10px">
            <span class="badge b-emerald b" style="border-radius:50%;width:26px;height:26px;display:flex;align-items:center;justify-content:center;flex-shrink:0">3</span>
            <div class="g1 sm">سيتم إضافة أيقونة أنمي بلاك لشاشتك الرئيسية والعمل بدون متصفح وبسرعة فائقة.</div>
          </div>
        </div>
        <button class="btn btn-pri" style="width:100%;border-radius:14px" onclick="closeOvl();window.triggerPwaInstall()">${I("download","i s ico-bounce")} تثبيت الآن</button>
      </div>`;
  }
  
  const ovl = document.getElementById("ovl");
  if (ovl) {
    ovl.innerHTML = `<div class="ov glass" style="display:flex;align-items:center;justify-content:center;padding:16px">${guideContent}</div>`;
  }
};

if (typeof window !== "undefined") {
  window.addEventListener('DOMContentLoaded', () => {
    window.pwaManager.init();
  });
}
