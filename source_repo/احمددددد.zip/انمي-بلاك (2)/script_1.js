
/* v7 — كاشف صفوف التمرير الأفقي.
   المشكلة: الصف كان يُقطع بالسكين عند حافة الشاشة فيبدو مكسوراً.
   الحل: وسم كل صف يتجاوز أفقياً بـ.v7edge فيأخذ هامشاً وتلاشياً متدرجاً.
   لا يمس المحتوى ولا الحالة — يضيف/يزيل اسم كلاس فقط. */
(function(){
  try{
    var TAG = "v7edge", timer = null, first = true;
    function scan(){
      try{
        var list = document.querySelectorAll(
          ".chiprow,.stories,.hscroll,.tabs,.segrow,.notesrow,.no-sb,.row,.seg,ul,nav > div");
        for (var i = 0; i < list.length; i++){
          var e = list[i];
          if (e.id === "page" || e.id === "reelbox") continue;
          var cs = getComputedStyle(e);
          var hx = /auto|scroll/.test(cs.overflowX) && e.scrollWidth  > e.clientWidth  + 4;
          var vy = /auto|scroll/.test(cs.overflowY) && e.scrollHeight > e.clientHeight + 4;
          if (hx && !vy) e.classList.add(TAG); else e.classList.remove(TAG);
        }
      }catch(_){}
    }
    function queue(){
      if (first){ first = false; scan(); return; }
      if (timer) clearTimeout(timer);
      timer = setTimeout(scan, 220);
    }
    if (document.readyState === "loading")
      document.addEventListener("DOMContentLoaded", queue);
    else queue();
    window.addEventListener("load", queue);
    window.addEventListener("resize", queue);
    window.addEventListener("orientationchange", queue);
    try{
      new MutationObserver(queue)
        .observe(document.documentElement, {childList:true, subtree:true});
    }catch(_){}
  }catch(_){}
})();
